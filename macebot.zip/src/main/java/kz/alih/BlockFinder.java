package kz.alih;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/** Жүктелген чанктардан берілген блоктарды (руда, ағаш) табады. Чанктарды біртіндеп сканерлейді, кэштейді. */
public final class BlockFinder {
    private final Predicate<BlockState> pred;
    private final Map<Long, List<BlockPos>> cache = new HashMap<>();
    private final Map<Long, Long> at = new HashMap<>();

    public BlockFinder(Predicate<BlockState> pred) { this.pred = pred; }

    public boolean test(BlockState s) { return pred.test(s); }

    public void reset() {
        cache.clear();
        at.clear();
    }

    /** radius — чанк радиусы; budget — бір шақыруда сканерленетін чанк саны. */
    public void scan(MinecraftClient mc, ClientPlayerEntity p, int radius, int budget) {
        long now = System.currentTimeMillis();
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        for (int ring = 0; ring <= radius && budget > 0; ring++) {
            for (int cx = pcx - ring; cx <= pcx + ring && budget > 0; cx++) {
                for (int cz = pcz - ring; cz <= pcz + ring && budget > 0; cz++) {
                    if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) != ring) continue;
                    long key = ChunkPos.toLong(cx, cz);
                    Long last = at.get(key);
                    if (last != null && now - last < 15000) continue;
                    at.put(key, now);
                    budget--;
                    Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (!(ch instanceof WorldChunk wc)) { cache.remove(key); continue; }
                    List<BlockPos> out = new ArrayList<>();
                    ChunkSection[] secs = wc.getSectionArray();
                    int bottom = wc.getBottomY();
                    for (int i = 0; i < secs.length && out.size() < 400; i++) {
                        ChunkSection s = secs[i];
                        if (s == null || s.isEmpty() || !s.hasAny(pred)) continue;
                        int y0 = bottom + i * 16;
                        for (int x = 0; x < 16; x++) {
                            for (int y = 0; y < 16; y++) {
                                for (int z = 0; z < 16; z++) {
                                    if (pred.test(s.getBlockState(x, y, z))) out.add(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z));
                                }
                            }
                        }
                    }
                    if (out.isEmpty()) cache.remove(key); else cache.put(key, out);
                }
            }
        }
        // алыстағы кэшті тазалау
        if (cache.size() > 400) {
            int keep = radius + 3;
            cache.keySet().removeIf(k -> {
                int cx = (int) (k & 0xFFFFFFFFL), cz = (int) (k >>> 32);
                return Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > keep;
            });
        }
    }

    /** Әлі де сол блок болып тұрған барлық белгілі позициялар. */
    public List<BlockPos> all(MinecraftClient mc) {
        List<BlockPos> out = new ArrayList<>();
        for (List<BlockPos> l : cache.values()) {
            for (BlockPos b : l) if (pred.test(mc.world.getBlockState(b))) out.add(b);
        }
        return out;
    }
}
