package kz.alih;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Квадрат спираль іздеу жолы: бастапқы нүктеден басталып, жолақ аралығымен сыртқа қарай айналады.
 * Ұшып бара жатқанда жүктелген чанктарды (сервердің view distance шегінде) сканерлейді.
 * Клиент жүктелмеген чанкті көре алмайды, сондықтан "5000 блок" радиус — осы жолмен жүріп өту шегі.
 */
public final class SearchPath {
    private double ox, oz;        // бастапқы нүкте
    private double wx, wz;        // ағымдағы нысана нүкте
    private int leg;              // қадам нөмірі
    private boolean active, finished;

    public void reset(double x, double z) {
        ox = x; oz = z;
        wx = x; wz = z;
        leg = 0;
        active = true;
        finished = false;
    }

    public boolean active() { return active; }
    public boolean finished() { return finished; }

    /** Спираль бойынша келесі бұрыш нүктесіне өтеді. */
    private void advance(double spacing) {
        // бағыттар: +X, +Z, -X, -Z; ұзындық әр 2 қадамда +1 жолақ
        int len = leg / 2 + 1;
        int dir = leg % 4;
        double d = len * spacing;
        switch (dir) {
            case 0 -> wx += d;
            case 1 -> wz += d;
            case 2 -> wx -= d;
            default -> wz -= d;
        }
        leg++;
    }

    /**
     * Қазіргі нысана нүкте. Ойыншы жақындаса келесісіне ауысады.
     * radius шегінен асса null қайтарады (іздеу аяқталды).
     */
    public Vec3d waypoint(double px, double pz, double spacing, double radius, double arrive) {
        if (!active) reset(px, pz);
        if (finished) return null;
        if (Math.hypot(wx - px, wz - pz) < arrive || leg == 0) advance(spacing);
        if (Math.max(Math.abs(wx - ox), Math.abs(wz - oz)) > radius) {
            finished = true;
            return null;
        }
        return new Vec3d(wx, 0, wz);
    }

    /** MC yaw (градус): +Z = 0°, -X = 90°. */
    public static float yawTo(double fromX, double fromZ, double toX, double toZ) {
        return (float) (MathHelper.atan2(toZ - fromZ, toX - fromX) * 180.0 / Math.PI) - 90f;
    }
}
