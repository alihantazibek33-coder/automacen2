package kz.alih;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;

/** Қауіпсіз қазуға арналған ортақ көмекшілер (АвтоМайн, АвтоАлмазка, Nav). */
public final class Mine {
    private static final List<BlockPos> SPAWNERS = new ArrayList<>();
    private static long lastRefresh;

    private Mine() {}

    // ================================================================ блок тексерулері

    public static boolean lava(MinecraftClient mc, BlockPos p) { return mc.world.getBlockState(p).getFluidState().isIn(FluidTags.LAVA); }

    public static boolean water(MinecraftClient mc, BlockPos p) { return mc.world.getBlockState(p).getFluidState().isIn(FluidTags.WATER); }

    /** Соқтығысу жоқ (ауа, шөп, т.б.) — өтуге болады. */
    public static boolean passable(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return s.getCollisionShape(mc.world, p).isEmpty();
    }

    public static boolean unbreakable(MinecraftClient mc, BlockPos p) {
        BlockState s = mc.world.getBlockState(p);
        return !s.isAir() && s.getFluidState().isEmpty() && s.getHardness(mc.world, p) < 0;
    }

    /**
     * pos блогын қазу қауіпті ме: айналасында лава; су (су басып кетпесін); құм/қиыршық тас (құлап тұншықтырады);
     * жақын жерде спавнер.
     */
    public static boolean unsafe(MinecraftClient mc, BlockPos c, boolean avoidWater, boolean avoidFalling, double spawnerR) {
        if (lava(mc, c)) return true;
        for (Direction d : Direction.values()) {
            BlockPos n = c.offset(d);
            if (lava(mc, n)) return true;
            if (avoidWater && water(mc, n)) return true;
        }
        if (avoidWater && water(mc, c)) return true;
        if (avoidFalling) {
            if (mc.world.getBlockState(c).getBlock() instanceof FallingBlock) return true;
            if (mc.world.getBlockState(c.up()).getBlock() instanceof FallingBlock) return true;
        }
        if (spawnerR > 0 && spawnerNear(c, spawnerR)) return true;
        return unbreakable(mc, c);
    }

    // ================================================================ спавнерлер

    /** Жүктелген чанктардағы спавнерлерді 2 секунд сайын жаңартады. */
    public static void refreshSpawners(MinecraftClient mc, ClientPlayerEntity p) {
        long now = System.currentTimeMillis();
        if (now - lastRefresh < 2000) return;
        lastRefresh = now;
        SPAWNERS.clear();
        int vd = mc.options.getViewDistance().getValue();
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        for (int cx = pcx - vd; cx <= pcx + vd; cx++) {
            for (int cz = pcz - vd; cz <= pcz + vd; cz++) {
                Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (!(ch instanceof WorldChunk wc)) continue;
                for (BlockEntity be : wc.getBlockEntities().values()) {
                    if (be instanceof MobSpawnerBlockEntity) SPAWNERS.add(be.getPos());
                }
            }
        }
    }

    public static boolean spawnerNear(BlockPos pos, double r) {
        double r2 = r * r;
        for (BlockPos s : SPAWNERS) if (s.getSquaredDistance(pos) <= r2) return true;
        return false;
    }

    // ================================================================ қазу

    /** Нысанаға қарап, құралды таңдап қазады. Прицел түскен блоктың орнын қайтарады (түспесе null). */
    public static BlockPos hold(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        Util.aimAt(p, Vec3d.ofCenter(pos));
        if (mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            selectTool(mc, p, mc.world.getBlockState(bhr.getBlockPos()));
            mc.options.attackKey.setPressed(true);
            return bhr.getBlockPos();
        }
        return null;
    }

    /** Блокқа ең жылдам құралды таңдайды (хотбардан); керек кірке инвентарьда болса, хотбарға алады. */
    public static void selectTool(MinecraftClient mc, ClientPlayerEntity p, BlockState s) {
        int best = Util.selected(p);
        float bm = p.getInventory().getStack(best).getMiningSpeedMultiplier(s);
        for (int i = 0; i < 9; i++) {
            float m = p.getInventory().getStack(i).getMiningSpeedMultiplier(s);
            if (m > bm) { bm = m; best = i; }
        }
        Util.select(p, best);
    }

    /** Ең мықты кірке хотбарда тұруын қамтамасыз етеді (кейде крафттан кейін инвентарьда қалады). */
    public static void ensureBestPick(MinecraftClient mc, ClientPlayerEntity p) {
        BlockState stone = Blocks.STONE.getDefaultState();
        ItemStack best = ItemStack.EMPTY;
        float bm = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty() || !s.isIn(ItemTags.PICKAXES)) continue;
            float m = s.getMiningSpeedMultiplier(stone);
            if (m > bm) { bm = m; best = s; }
        }
        if (best.isEmpty()) return;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && s.isOf(best.getItem())) return;      // хотбарда бар
        }
        final ItemStack fb = best;
        Util.grab(mc, p, s -> s == fb);
    }

    // ================================================================ санау

    public static int count(ClientPlayerEntity p, java.util.function.Predicate<ItemStack> f) {
        int n = 0;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) n += s.getCount();
        }
        return n;
    }
}
