package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;

/** ХедВеб+Плита: игроктың аяғына нажимная плита, басына паутина қояды (комбо, UHC). */
public class HeadWebPlate extends Module {
    private final Setting range = num("Қашықтық", 4.5, 2.0, 5.0, 0.5);
    private final Setting interval = num("Аралық (тик)", 40, 10, 120, 5);

    private int phase, cooldown, prevSlot = -1;

    public HeadWebPlate() {
        super("headwebplate", "ХедВеб+Плита", "Аяққа плита, басқа паутина қояды (UHC комбо)");
    }

    @Override
    public void reset() { phase = 0; cooldown = 0; prevSlot = -1; }

    private static boolean isPlate(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath().endsWith("pressure_plate");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (prevSlot >= 0) { Util.select(p, prevSlot); prevSlot = -1; }
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;

        PlayerEntity t = Util.nearestPlayer(mc, p, range.num());
        if (t == null) { phase = 0; return; }
        BlockPos feet = t.getBlockPos();
        int cur = Util.selected(p);

        if (phase == 0) {                                   // плита
            if (!mc.world.getBlockState(feet).isAir()) { phase = 1; return; }
            int slot = Util.grab(mc, p, HeadWebPlate::isPlate);
            if (slot < 0) { phase = 1; return; }
            Util.select(p, slot);
            if (Util.placeBlockAt(mc, p, feet)) {
                phase = 1;
                cooldown = Util.jitter(2, 3);
                if (cur != slot) prevSlot = cur;
            } else {
                Util.select(p, cur);
            }
        } else {                                            // паутина басқа
            BlockPos head = feet.up();
            if (!mc.world.getBlockState(head).isAir()) { phase = 0; cooldown = Util.jitter((int) interval.num(), 8); return; }
            int slot = Util.grab(mc, p, s -> s.isOf(Items.COBWEB));
            if (slot < 0) return;
            Util.select(p, slot);
            if (Util.placeBlockAt(mc, p, head)) {
                phase = 0;
                cooldown = Util.jitter((int) interval.num(), 8);
                if (cur != slot) prevSlot = cur;
            } else {
                Util.select(p, cur);
                phase = 0;
                cooldown = 10;
            }
        }
    }
}
