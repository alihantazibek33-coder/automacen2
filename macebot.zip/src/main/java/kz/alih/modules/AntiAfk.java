package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.Random;

/** АнтиАФК: АФК-ден шығармау үшін жиі-жиі секіріп, айналып қояды. */
public class AntiAfk extends Module {
    private final Random rnd = new Random();
    private int timer = 300;

    public AntiAfk() {
        super("antiafk", "АнтиАФК", "Сервер АФК деп шығармауы үшін ара-тұра секіреді");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.jumpKey.setPressed(false);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        timer--;
        mc.options.jumpKey.setPressed(timer == 0 || timer == -1);
        if (timer <= -2) {
            p.setYaw(p.getYaw() + (rnd.nextBoolean() ? 15f : -15f));
            timer = 400 + rnd.nextInt(400);
        }
    }
}
