package kz.alih.modules;

import kz.alih.HudUtil;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

/** Нысана карточкасы: аты, HP жолағы, қашықтық, броня + нысана айналасында түрлі-түсті контур. */
public class TargetHud extends Module {
    public static TargetHud INSTANCE;

    private final Setting card = bool("Карточка", true);
    private final Setting box = bool("Контур (қорап)", true);
    private final Setting glow = bool("Жарқырау (қабырға арқылы)", true);

    private static Entity lastAttacked;
    private static long lastAttackMs;

    private LivingEntity cur;
    private boolean glowSet;

    public TargetHud() {
        super("targethud", "НысанаКарточка", "Нысана аты, HP, қашықтығы, брондасы және контуры");
        INSTANCE = this;
    }

    @Override
    public boolean defaultEnabled() { return true; }

    /** Біз ұрған нысананы есте сақтайды (Util.attack пен қолмен ұру шақырады). */
    public static void note(Entity e) {
        lastAttacked = e;
        lastAttackMs = System.currentTimeMillis();
    }

    private LivingEntity pick(MinecraftClient mc, ClientPlayerEntity p) {
        UUID id = ElytraMace.currentTarget();
        if (id != null) {
            Entity e = Util.entityById(mc, id);
            if (e instanceof LivingEntity le && le.isAlive()) return le;
        }
        if (lastAttacked instanceof LivingEntity le && le.isAlive() && !le.isRemoved()
                && System.currentTimeMillis() - lastAttackMs < 6000 && le.squaredDistanceTo(p) < 80 * 80) return le;
        return null;
    }

    private void unglow() {
        if (cur != null && glowSet) cur.setGlowing(false);
        glowSet = false;
    }

    @Override
    public void reset() { cur = null; glowSet = false; }

    @Override
    protected void onDisable() { unglow(); cur = null; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        LivingEntity t = pick(mc, p);
        if (t != cur) { unglow(); cur = t; }
        if (cur != null && glow.on()) { cur.setGlowing(true); glowSet = true; }
        else if (glowSet) unglow();
    }

    public static void render(DrawContext ctx) {
        TargetHud h = INSTANCE;
        if (h == null || !h.enabled || h.cur == null || !h.cur.isAlive()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        h.draw(ctx, mc, mc.player, h.cur);
    }

    private static int hpColor(double t) {
        t = Math.max(0, Math.min(1, t));
        return 0xFF000000 | ((int) ((1 - t) * 255) << 16) | ((int) (t * 255) << 8) | 40;
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        TextRenderer tr = mc.textRenderer;
        float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
        int col = hpColor(hp / max);

        if (box.on()) drawBox(ctx, mc, p, t, col);

        if (card.on()) {
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            int w = 132, h = 42;
            int x = sw / 2 + 24, y = sh / 2 + 28;
            ctx.fill(x, y, x + w, y + h, 0xA0000000);
            ctx.fill(x, y, x + 2, y + h, col);
            ctx.drawText(tr, t.getName().getString(), x + 6, y + 4, 0xFFFFFFFF, true);
            // HP жолағы
            int bx = x + 6, by = y + 16, bw = w - 12;
            ctx.fill(bx, by, bx + bw, by + 6, 0xFF303030);
            ctx.fill(bx, by, bx + (int) (bw * Math.min(1f, hp / max)), by + 6, col);
            String hpText = String.format(java.util.Locale.ROOT, "%.1f / %.0f", hp, max);
            ctx.drawText(tr, hpText, bx, by + 9, 0xFFDDDDDD, true);
            String info = String.format(java.util.Locale.ROOT, "%.1f м  |  Броня %d", Math.sqrt(t.squaredDistanceTo(p)), t.getArmor());
            ctx.drawText(tr, info, bx + 62, by + 9, 0xFFAAAAAA, true);
        }
    }

    /** Нысананың 3D қорабын экранға проекциялап, бұрыштық жақшалар салады. */
    private void drawBox(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p, LivingEntity t, int color) {
        HudUtil.Cam cam = HudUtil.cam(mc, p);
        Box b = t.getBoundingBox().offset(HudUtil.smoothOffset(t));
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            Vec3d c = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            double[] s = cam.project(c);
            if (s == null) return;                       // бір бұрыш артта — салмайды
            minX = Math.min(minX, s[0]); maxX = Math.max(maxX, s[0]);
            minY = Math.min(minY, s[1]); maxY = Math.max(maxY, s[1]);
        }
        int x1 = (int) minX - 2, y1 = (int) minY - 2, x2 = (int) maxX + 2, y2 = (int) maxY + 2;
        if (x2 < 0 || y2 < 0 || x1 > cam.w || y1 > cam.h || x2 - x1 > cam.w * 2) return;
        int len = Math.max(4, Math.min(x2 - x1, y2 - y1) / 4);
        int line = HudUtil.withAlpha(color, 80);
        ctx.fill(x1, y1, x2, y1 + 1, line); ctx.fill(x1, y2 - 1, x2, y2, line);
        ctx.fill(x1, y1, x1 + 1, y2, line); ctx.fill(x2 - 1, y1, x2, y2, line);
        // бұрыштық жақшалар (қалың)
        ctx.fill(x1, y1, x1 + len, y1 + 2, color); ctx.fill(x1, y1, x1 + 2, y1 + len, color);
        ctx.fill(x2 - len, y1, x2, y1 + 2, color); ctx.fill(x2 - 2, y1, x2, y1 + len, color);
        ctx.fill(x1, y2 - 2, x1 + len, y2, color); ctx.fill(x1, y2 - len, x1 + 2, y2, color);
        ctx.fill(x2 - len, y2 - 2, x2, y2, color); ctx.fill(x2 - 2, y2 - len, x2, y2, color);
    }
}
