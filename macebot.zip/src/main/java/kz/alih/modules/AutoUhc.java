package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * АвтоУХК: жақын игрокпен өзі PvP жасайды.
 * Крит/комбо, щит (кейде), алтын алма (алдымен қашады), паутина (сирек), лава (қойып тез алады),
 * өрт/паутинада су, қалған сұйықты блокпен жабу, қабырғаға қысу, алыстан лук.
 * Керек заттарды бүкіл инвентарьдан өзі алады.
 */
public class AutoUhc extends Module {
    private final Setting eatHp = num("Алма жеу HP", 10, 4, 18, 1);
    private final Setting bowDist = num("Лук қашықтығы", 9, 6, 30, 1);
    private final Setting lava = bool("Лава", true);
    private final Setting web = bool("Паутина (сирек)", true);
    private final Setting bowS = bool("Лук", true);
    private final Setting shieldS = bool("Щит (кейде)", true);
    private final Setting wallS = bool("Қабырға комбо", true);
    private final Setting waterS = bool("Су (өрт/паутина)", true);
    private final Setting coverS = bool("Блок: жабу/қашу", true);
    private final Setting mobsS = bool("Мобқа да", false);
    private final Setting rodS = bool("Қармақ", true);
    private final Setting pearlS = bool("Перл (қашу)", true);
    private final Setting mlgS = bool("Су: құлағанда (MLG)", true);

    private final Random rnd = new Random();
    private UUID targetId;

    // жалпы күйлер
    private int eatTicks, fleeTicks, hitWait, strafeT, strafeDir = 1, coverCd, frontCd;
    private int webCd, lavaCd, comboLeft, tickN;
    private int rodState, rodT, rodCd, pearlCd, varyT;
    private boolean varySlow;
    private boolean shieldCycle;

    // лава
    private BlockPos lavaPos;
    private int lavaT;

    // су (өрт / паутина)
    private boolean waterPending;
    private int waterT, waterCd, fireTicks;
    private BlockPos waterFeet;

    // қабырға
    private int wallScanT;

    public AutoUhc() {
        super("autouhc", "АвтоУХК", "Өзі PvP жасайды: крит/комбо, щит, алма, паутина, лава, су, блок, қабырға, лук");
    }

    @Override
    protected void onEnable() {
        targetId = null;
        eatTicks = 0; fleeTicks = 0; hitWait = 0; comboLeft = 0;
        webCd = 100; lavaCd = 0; lavaPos = null;
        waterPending = false; waterCd = 0; fireTicks = 0;
        shieldCycle = false;
    }

    @Override
    public void reset() {
        targetId = null; lavaPos = null; waterPending = false; rodState = 0; eatTicks = 0; fleeTicks = 0;
    }

    @Override
    protected void onDisable() {
        releaseKeys(Util.mc());
    }

    private void releaseKeys(MinecraftClient mc) {
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.useKey.setPressed(false);
    }

    private LivingEntity resolveTarget(MinecraftClient mc, ClientPlayerEntity p) {
        if (targetId != null) {
            Entity e = Util.entityById(mc, targetId);
            if (e instanceof LivingEntity le && Util.validTarget(p, e, mobsS.on()) && e.distanceTo(p) < 60) return le;
        }
        LivingEntity n = Util.nearestTarget(mc, p, 40, mobsS.on());
        targetId = n == null ? null : n.getUuid();
        return n;
    }

    /** Алтын алма не golden head (UHC). */
    private static boolean isApple(ItemStack s) {
        return s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.PLAYER_HEAD);
    }

    // ================================================================ негізгі цикл

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        tickN++;
        if (webCd > 0) webCd--;
        if (lavaCd > 0) lavaCd--;
        if (coverCd > 0) coverCd--;
        if (frontCd > 0) frontCd--;
        if (comboLeft > 0) comboLeft--;
        if (rodCd > 0) rodCd--;
        if (pearlCd > 0) pearlCd--;
        releaseKeys(mc);
        if (mc.currentScreen != null) return;

        // 1) өз қауіпсіздігі: өрт / паутина -> су
        if (handleWater(mc, p)) return;

        LivingEntity t = resolveTarget(mc, p);
        if (t == null) return;

        double dist = Util.boxDist(p.getEyePos(), t.getBoundingBox());
        float hp = p.getHealth() + p.getAbsorptionAmount();

        // 2) қойылған лаваны тез алу
        if (handleLava(mc, p)) return;

        // 3) қарсыластың лава/суын блокпен жабу
        if (dist > 4.0 && coverFluids(mc, p, t)) return;

        // 3.5) қармақ: лақтырылса, біраз күтіп қайта тартады
        if (rodState == 1) {
            int rod = Util.grab(mc, p, s -> s.isOf(Items.FISHING_ROD));
            if (rod >= 0) {
                Util.select(p, rod);
                Util.aimNow(p, Util.center(t));
                rodT++;
                if (rodT >= 9) {
                    mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                    rodState = 0;
                    rodCd = 30 + rnd.nextInt(30);
                }
                return;
            }
            rodState = 0;
        }

        // 3.6) перлмен қашу: HP аз, жейтін зат жоқ, қарсылас жақын
        if (pearlS.on() && pearlCd == 0 && hp <= 6 && dist < 7 && !Util.hasInInventory(p, AutoUhc::isApple)) {
            int pearl = Util.grab(mc, p, s -> s.isOf(Items.ENDER_PEARL));
            if (pearl >= 0) {
                double ax = p.getX() - t.getX(), az = p.getZ() - t.getZ();
                double len = Math.max(0.01, Math.hypot(ax, az));
                Util.select(p, pearl);
                Util.aimNow(p, new Vec3d(p.getX() + ax / len * 20, p.getEyeY() + 7, p.getZ() + az / len * 20));
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                pearlCd = 600;
                return;
            }
        }

        // 4) алма: алдымен қашады, содан кейін жейді
        if (hp <= eatHp.num() && Util.hasInInventory(p, AutoUhc::isApple)) {
            Vec3d tc = Util.center(t);
            if (eatTicks == 0 && dist < 7.5 && fleeTicks < 70) {
                fleeTicks++;
                if (fleeTicks % 12 == 0 && dist < 6 && coverFront(mc, p, t)) return;
                Util.aimAt(p, new Vec3d(p.getX() + (p.getX() - t.getX()), p.getEyeY(), p.getZ() + (p.getZ() - t.getZ())));
                mc.options.forwardKey.setPressed(true);
                mc.options.sprintKey.setPressed(true);
                if (p.horizontalCollision && p.isOnGround()) mc.options.jumpKey.setPressed(true);
                return;
            }
            int apple = Util.grab(mc, p, AutoUhc::isApple);
            if (apple >= 0) {
                if (eatTicks % 10 == 5 && dist < 6 && coverFront(mc, p, t)) { eatTicks++; return; }
                Util.select(p, apple);
                Util.aimAt(p, tc);
                mc.options.useKey.setPressed(true);
                eatTicks++;
                if (eatTicks > 45 || (eatTicks > 4 && !p.isUsingItem())) { eatTicks = 0; fleeTicks = 0; }
                return;
            }
        }
        eatTicks = 0;
        if (hp > eatHp.num() + 4) fleeTicks = 0;

        // 5) алыстан лук
        boolean hasArrow = Util.hasInInventory(p, s -> s.isIn(ItemTags.ARROWS));
        if (bowS.on() && hasArrow && dist > bowDist.num() && dist < 45
                && Util.hasInInventory(p, s -> s.isOf(Items.BOW))) {
            int bow = Util.grab(mc, p, s -> s.isOf(Items.BOW));
            if (bow >= 0) {
                Util.select(p, bow);
                Util.aimAt(p, AutoBow.lead(p, t, 3.0));
                mc.options.useKey.setPressed(true);
                if (p.getItemUseTime() >= 20) mc.options.useKey.setPressed(false); // жібереді
                return;
            }
        }

        // 6) қару
        int weapon = Util.grab(mc, p, s -> s.isIn(ItemTags.SWORDS));
        if (weapon < 0) weapon = Util.grab(mc, p, s -> s.isIn(ItemTags.AXES));
        if (weapon < 0) weapon = Util.grab(mc, p, s -> s.isOf(Items.MACE));
        if (weapon >= 0) Util.select(p, weapon);
        Util.aimAt(p, Util.center(t));

        // 7) паутина — сирек және кездейсоқ
        if (web.on() && webCd == 0 && dist >= 2.0 && dist <= 4.2 && rnd.nextInt(100) < 8) {
            BlockPos tp = t.getBlockPos();
            if (mc.world.getBlockState(tp).isAir() && solid(mc, tp.down()) && !Util.ignoredNear(mc, Util.pos(t), 5)) {
                int cw = Util.grab(mc, p, s -> s.isOf(Items.COBWEB));
                if (cw >= 0) {
                    Util.select(p, cw);
                    Util.place(mc, p, tp.down(), Direction.UP);
                    webCd = 200 + rnd.nextInt(200);
                    return;
                }
            }
        }

        // 7.5) қармақ: орташа қашықтықта лақтырып, тартады (комбо/нокбек)
        if (rodS.on() && rodState == 0 && rodCd == 0 && dist >= 3.5 && dist <= 8.5) {
            int rod = Util.grab(mc, p, s -> s.isOf(Items.FISHING_ROD));
            if (rod >= 0) {
                Util.select(p, rod);
                Util.aimNow(p, Util.center(t));
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                rodState = 1;
                rodT = 0;
                return;
            }
        }

        // 8) лава — нысана барар жолға, тез алынады
        if (lava.on() && lavaCd == 0 && lavaPos == null && dist >= 3.5 && dist <= 9) {
            if (placeLava(mc, p, t)) return;
        }

        // 9) қозғалыс (қабырға тактикасымен)
        boolean combo = comboLeft > 0;
        Vec3d wallNearEnemy = wallS.on() ? findWallFrom(mc, Util.pos(t), 4.0) : null;
        boolean pin = wallNearEnemy != null && Util.pos(t).distanceTo(wallNearEnemy) <= 1.7 && dist <= 3.4;
        boolean moved = false;

        if (wallS.on() && dist > 3.0 && wallNearEnemy == null) {
            // нысана қабырғадан алыс: қабырғаға жақын жерге қашып, күтеді (оны өзіне қарай алып кетеді)
            Vec3d mw = findWallFrom(mc, Util.pos(p), 7.0);
            if (mw != null && dist > 5.0) {
                Vec3d dir = flat(Util.pos(p).subtract(mw));
                Vec3d spot = mw.add(dir.multiply(3.0));
                if (Math.hypot(spot.x - p.getX(), spot.z - p.getZ()) > 1.2) {
                    Util.walkTo(mc, p, spot, true);
                }
                moved = true; // жетсе — күтеді
            }
        }
        if (--varyT <= 0) {                          // жылдамдықты өзгертіп отырады
            varyT = 10 + rnd.nextInt(10);
            varySlow = rnd.nextInt(100) < 25;
        }
        if (!moved && dist > 2.8) {
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(!varySlow);
            if (p.horizontalCollision && p.isOnGround()) mc.options.jumpKey.setPressed(true);
        }

        // 10) strafe: қабырға болса — нысана қабырға жаққа тұратындай айналады
        if (dist < 5) {
            if (wallNearEnemy != null) {
                Vec3d w = flat(wallNearEnemy.subtract(Util.pos(t)));
                double yawRad = Math.toRadians(p.getYaw());
                Vec3d right = new Vec3d(-Math.cos(yawRad), 0, -Math.sin(yawRad));
                boolean strafeRight = right.dotProduct(w) < 0;
                mc.options.rightKey.setPressed(strafeRight);
                mc.options.leftKey.setPressed(!strafeRight);
            } else {
                if (--strafeT <= 0) {
                    strafeT = 8 + rnd.nextInt(8);
                    strafeDir = rnd.nextBoolean() ? 1 : -1;
                }
                mc.options.leftKey.setPressed(strafeDir > 0);
                mc.options.rightKey.setPressed(strafeDir < 0);
            }
        }

        // 11) соққы: крит / комбо (криттіксіз) / қабырғаға қысып тез ұру; щит кейде
        float cd = p.getAttackCooldownProgress(0.5f);
        boolean offShield = shieldS.on() && p.getOffHandStack().isOf(Items.SHIELD);
        if (dist <= 3.0) {
            boolean fast = pin || combo;
            float need = pin ? 0.5f : (combo ? 0.6f : 0.95f);
            if (fast) {
                mc.options.forwardKey.setPressed(true);   // спринтпен ұрып итереді
                mc.options.sprintKey.setPressed(true);
            } else {
                mc.options.forwardKey.setPressed(false);
            }
            if (cd >= need) {
                if (!fast && p.isOnGround()) {
                    mc.options.jumpKey.setPressed(true);
                    if (++hitWait > 8) { hit(mc, p, t); }
                } else if (!fast && p.getVelocity().y < 0) {
                    p.setSprinting(false);
                    hit(mc, p, t);
                } else if (fast) {
                    hit(mc, p, t);
                }
            } else if (offShield && shieldCycle && !fast) {
                mc.options.useKey.setPressed(true);
            }
        } else {
            hitWait = 0;
        }
    }

    private void hit(MinecraftClient mc, ClientPlayerEntity p, Entity t) {
        Util.attack(mc, p, t);
        hitWait = 0;
        shieldCycle = rnd.nextInt(100) < 35;                 // щитті әр соққыда емес, кейде
        if (comboLeft == 0 && rnd.nextInt(100) < 25) {       // кейде криттіксіз комбоға алады
            comboLeft = 50 + rnd.nextInt(40);
        }
    }

    // ================================================================ су (өрт / паутина)

    private boolean inWeb(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos feet = p.getBlockPos();
        BlockPos head = BlockPos.ofFloored(p.getX(), p.getEyeY(), p.getZ());
        return mc.world.getBlockState(feet).isOf(Blocks.COBWEB) || mc.world.getBlockState(head).isOf(Blocks.COBWEB);
    }

    private BlockPos ownWater(MinecraftClient mc) {
        if (waterFeet == null) return null;
        BlockPos[] cand = { waterFeet, waterFeet.up(), waterFeet.up(2), waterFeet.down() };
        for (BlockPos c : cand) {
            FluidState fs = mc.world.getBlockState(c).getFluidState();
            if (fs.isIn(FluidTags.WATER) && fs.isStill()) return c;
        }
        return null;
    }

    /** true — осы тик су үшін жұмсалды. */
    private boolean handleWater(MinecraftClient mc, ClientPlayerEntity p) {
        if (waterCd > 0) waterCd--;
        fireTicks = p.isOnFire() ? fireTicks + 1 : 0;
        boolean web = inWeb(mc, p);

        if (waterPending) {
            waterT++;
            BlockPos w = ownWater(mc);
            if (w == null) { waterPending = false; return false; }
            boolean safe = !web && !p.isOnFire();
            if ((waterT >= 5 && safe) || waterT > 40) {
                int b = Util.grab(mc, p, s -> s.isOf(Items.BUCKET));
                if (b >= 0) {
                    Util.select(p, b);
                    Util.aimNow(p, Vec3d.ofCenter(w));
                    mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                    return true;
                }
                waterPending = false;
            }
            return false;
        }

        // құлағанда су (MLG): жерге 3 блоктан аз қалғанда су құяды, кейін қайта алады
        if (mlgS.on() && waterCd == 0 && !p.isOnGround() && p.getVelocity().y < -0.6 && !p.isTouchingWater()) {
            BlockPos base = p.getBlockPos();
            for (int k = 1; k <= 3; k++) {
                BlockPos g = base.down(k);
                if (solid(mc, g)) {
                    int wb = Util.grab(mc, p, s -> s.isOf(Items.WATER_BUCKET));
                    if (wb >= 0) {
                        Util.select(p, wb);
                        p.setPitch(90f);
                        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                        waterPending = true;
                        waterT = 0;
                        waterCd = 60;
                        waterFeet = g.up();
                        return true;
                    }
                    break;
                }
            }
        }

        if (!waterS.on() || waterCd > 0) return false;
        if ((web || fireTicks >= 20) && !p.isTouchingWater()) {
            int wb = Util.grab(mc, p, s -> s.isOf(Items.WATER_BUCKET));
            if (wb < 0) return false;
            Util.select(p, wb);
            p.setPitch(90f);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            waterPending = true;
            waterT = 0;
            waterCd = 80;
            waterFeet = p.getBlockPos();
            return true;
        }
        return false;
    }

    // ================================================================ лава

    private boolean placeLava(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        Vec3d fut = Util.pos(t).add(Util.vel(t).multiply(6));
        BlockPos bp = BlockPos.ofFloored(fut);
        BlockPos sup = bp.down();
        Vec3d bc = Vec3d.ofCenter(bp);
        boolean ok = mc.world.getBlockState(bp).isAir() && solid(mc, sup)
                && p.getEyePos().distanceTo(bc) <= 4.5
                && Math.hypot(bc.x - p.getX(), bc.z - p.getZ()) >= 2.5;
        if (!ok || Util.ignoredNear(mc, bc, 6)) return false;
        int lb = Util.grab(mc, p, s -> s.isOf(Items.LAVA_BUCKET));
        if (lb < 0) return false;
        Util.select(p, lb);
        Util.aimNow(p, Vec3d.ofCenter(sup).add(0, 0.5, 0));
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        lavaPos = bp;
        lavaT = 0;
        lavaCd = 100;
        return true;
    }

    /** Қойылған лаваны тез (~8 тик) қайта алады. true — осы тик лава үшін жұмсалды. */
    private boolean handleLava(MinecraftClient mc, ClientPlayerEntity p) {
        if (lavaPos == null) return false;
        lavaT++;
        BlockState st = mc.world.getBlockState(lavaPos);
        if (!st.getFluidState().isIn(FluidTags.LAVA)) { lavaPos = null; return false; }
        if (lavaT > 80) { lavaPos = null; return false; }
        Vec3d c = Vec3d.ofCenter(lavaPos);
        double d = p.getEyePos().distanceTo(c);
        if (lavaT >= 8 || d < 2.6) {
            int b = Util.grab(mc, p, s -> s.isOf(Items.BUCKET));
            if (b >= 0 && d <= 4.5) {
                Util.select(p, b);
                Util.aimNow(p, c);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                return true;
            }
            lavaPos = null;
        }
        return false;
    }

    // ================================================================ блоктар

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }

    /** Нысана жаққа (алдыңа) блок қояды: қашу/жеу кезінде жауып қалу. */
    private boolean coverFront(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!coverS.on() || frontCd > 0 || !Util.hasBuildBlock(mc, p)) return false;
        Direction d = Direction.getFacing(t.getX() - p.getX(), 0, t.getZ() - p.getZ());
        BlockPos bp = p.getBlockPos().offset(d);
        BlockState st = mc.world.getBlockState(bp);
        BlockPos support = null;
        if ((st.isAir() || st.isReplaceable()) && solid(mc, bp.down())) {
            support = bp.down();
        } else if (solid(mc, bp) && mc.world.getBlockState(bp.up()).isAir()) {
            support = bp;
        }
        if (support == null) return false;
        int blk = Util.grab(mc, p, s -> Util.isBuildBlock(mc.world, s));
        if (blk < 0) return false;
        Util.select(p, blk);
        Util.aimAt(p, Vec3d.ofCenter(support).add(0, 0.5, 0));
        Util.place(mc, p, support, Direction.UP);
        frontCd = 6;
        return true;
    }

    /** Қарсыластың жерде қалған суы/лавасын блокпен жабады. */
    private boolean coverFluids(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!coverS.on() || coverCd > 0 || !Util.hasBuildBlock(mc, p)) return false;
        BlockPos pb = p.getBlockPos();
        BlockPos own = waterPending ? ownWater(mc) : null;
        Vec3d eye = p.getEyePos();
        BlockPos tb = t.getBlockPos();
        for (int dx = -4; dx <= 4; dx++) {
            for (int dy = -2; dy <= 1; dy++) {
                for (int dz = -4; dz <= 4; dz++) {
                    BlockPos pos = pb.add(dx, dy, dz);
                    if (pos.equals(pb) || pos.equals(pb.up())) continue;
                    if (pos.equals(lavaPos) || pos.equals(own)) continue;
                    FluidState fs = mc.world.getBlockState(pos).getFluidState();
                    if (fs.isEmpty() || !fs.isStill()) continue;
                    if (Math.sqrt(pos.getSquaredDistance(tb)) > 7) continue;   // жекпе-жек маңындағы ғана
                    BlockPos sup = pos.down();
                    if (!solid(mc, sup) || !mc.world.getBlockState(pos.up()).isAir()) continue;
                    if (eye.distanceTo(Vec3d.ofCenter(pos)) > 4.5) continue;
                    int blk = Util.grab(mc, p, s -> Util.isBuildBlock(mc.world, s));
                    if (blk < 0) return false;
                    Util.select(p, blk);
                    Util.aimAt(p, Vec3d.ofCenter(sup).add(0, 0.5, 0));
                    Util.place(mc, p, sup, Direction.UP);
                    coverCd = 4;
                    return true;
                }
            }
        }
        return false;
    }

    // ================================================================ қабырға

    private static Vec3d flat(Vec3d v) {
        Vec3d f = new Vec3d(v.x, 0, v.z);
        return f.lengthSquared() < 1.0E-6 ? Vec3d.ZERO : f.normalize();
    }

    /** origin-нен maxR радиуста ең жақын қабырға (бас деңгейіндегі қатты блок) орталығы, жоқ болса null. */
    private Vec3d findWallFrom(MinecraftClient mc, Vec3d origin, double maxR) {
        Vec3d best = null;
        double bd = maxR + 1;
        for (int a = 0; a < 16; a++) {
            double ang = a * Math.PI / 8.0;
            double cx = Math.cos(ang), cz = Math.sin(ang);
            for (double r = 0.8; r <= maxR; r += 0.5) {
                BlockPos bp = BlockPos.ofFloored(origin.x + cx * r, origin.y + 1.0, origin.z + cz * r);
                if (solid(mc, bp)) {
                    if (r < bd) { bd = r; best = Vec3d.ofCenter(bp); }
                    break;
                }
            }
        }
        return best;
    }
}
