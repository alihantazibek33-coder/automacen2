package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** НоФолл: құлағанда зақым алмау үшін серверге "жерде тұрмын" деп хабарлайды. */
public class NoFall extends Module {
    public NoFall() {
        super("nofall", "НоФолл", "Құлағанда зақым алмайды");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!p.isOnGround() && p.getVelocity().y < -0.5 && !p.isGliding()) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }
    }
}
