package kz.alih.modules;

import kz.alih.BlockFinder;
import kz.alih.Crafter;
import kz.alih.Mine;
import kz.alih.Module;
import kz.alih.Nav;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.FurnaceScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

/**
 * АвтоАлмазка: Minecraft-ты нөлден алмаз сетке дейін өзі өтеді.
 * Ағаш (15) → тақтай/верстак/кірке → тас (14 блужник) → тас құрал + пеш → көмір (3) → темір (3) →
 * пеште балқыту → темір кірке → Y -30-ға түсу → алмаз (3) → алмаз кірке → 30 алмаз → қылыш, балта, сет (киеді).
 * Қауіпсіздік: лава/су/құм-қиыршық/спавнер маңын қазбайды, моб келсе қарумен ұрады, құрал блокқа қарай автоматты ауысады.
 */
public class AutoAlmazka extends Module {
    private enum Phase { WOOD, STONE, COAL, IRON, SMELT, DESCEND, DIAMOND1, DIAMOND, FINAL, DONE }

    private enum SK { CRAFT, CRAFT_ALL, PLACE_TABLE, PLACE_FURNACE, OPEN_TABLE, OPEN_FURNACE, SMELT, CLOSE, BREAK_TABLE, BREAK_FURNACE, EQUIP }

    private static final class Step {
        final SK k;
        final Crafter.Recipe r;
        final int n;

        Step(SK k, Crafter.Recipe r, int n) { this.k = k; this.r = r; this.n = n; }
    }

    private static final class TStep {
        final BlockPos dest;
        final List<BlockPos> clear;
        final boolean jump;
        final int dirIdx, mode;
        int t;

        TStep(BlockPos dest, List<BlockPos> clear, boolean jump, int dirIdx, int mode) {
            this.dest = dest; this.clear = clear; this.jump = jump; this.dirIdx = dirIdx; this.mode = mode;
        }
    }

    private static final int[][] D = { { 1, 0 }, { 0, 1 }, { -1, 0 }, { 0, -1 } };
    private static final int HORIZ = 0, DOWN = 1, UP = 2, SHAFT = 3;

    private final Setting logsS = num("Ағаш саны", 15, 4, 40, 1);
    private final Setting diamondsS = num("Алмаз саны (кіркеден кейін)", 30, 10, 60, 1);
    private final Setting deepY = num("Алмаз іздеу тереңдігі (Y)", -30, -58, 0, 2);

    private final Nav nav = new Nav();
    private final Crafter crafter = new Crafter();
    private final BlockFinder logF = new BlockFinder(s -> s.isIn(BlockTags.LOGS));
    private final BlockFinder coalF = new BlockFinder(s -> s.isOf(Blocks.COAL_ORE) || s.isOf(Blocks.DEEPSLATE_COAL_ORE));
    private final BlockFinder ironF = new BlockFinder(s -> s.isOf(Blocks.IRON_ORE) || s.isOf(Blocks.DEEPSLATE_IRON_ORE));
    private final BlockFinder diaF = new BlockFinder(s -> s.isOf(Blocks.DIAMOND_ORE) || s.isOf(Blocks.DEEPSLATE_DIAMOND_ORE));

    private Phase phase = Phase.WOOD;
    private final Set<Long> bad = new HashSet<>();
    private BlockPos target;
    private int ticks, walkT, mineT, collectT, eatTicks, exploreT, planFail, moves, sdir, exploreDir, exploreSteps;
    private int lastProgressTick, lastProgressKey;
    private float surfaceYaw;
    private double bestDist;
    private int dropCd, lavaT, lavaCool, resumeWait;
    private boolean keepResume;
    private static final java.nio.file.Path RESUME =
            net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("alih-almazka.resume");
    private static final Set<Item> JUNK = Set.of(Items.DIRT, Items.GRASS_BLOCK, Items.COARSE_DIRT, Items.GRAVEL, Items.SAND,
            Items.ANDESITE, Items.DIORITE, Items.GRANITE, Items.TUFF, Items.DEEPSLATE, Items.NETHERRACK,
            Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.BONE, Items.GUNPOWDER, Items.ARROW, Items.FLINT,
            Items.WHEAT_SEEDS, Items.POISONOUS_POTATO);
    private BlockPos lastHit;

    // туннель
    private TStep ts;
    private final int[] failMask = new int[4];

    // верстак/пеш жұмысы
    private final List<Step> job = new ArrayList<>();
    private int ji, stepT, placeTries, openTries, smeltState;
    private Phase afterJob;
    private BlockPos tablePos, furnacePos, nichePos;
    private boolean crafting;

    public AutoAlmazka() {
        super("autoalmazka", "АвтоАлмазка", "Ағаштан бастап алмаз сетке дейін өзі өтеді (верстак, пеш, кірке, алмаз)");
    }

    @Override
    public boolean persistEnabled() { return false; }

    // ================================================================ өмірлік цикл

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        ClientPlayerEntity p = mc.player;
        if (p == null) { setEnabled(false); return; }
        bad.clear();
        job.clear();
        target = null;
        ts = null;
        tablePos = furnacePos = nichePos = null;
        crafting = false;
        ticks = walkT = mineT = collectT = eatTicks = exploreT = planFail = moves = exploreSteps = 0;
        lastProgressTick = 0;
        lastProgressKey = -1;
        java.util.Arrays.fill(failMask, 0);
        sdir = (Math.round(p.getYaw() / 90f) + 1) & 3;
        exploreDir = sdir;
        surfaceYaw = p.getYaw();
        nav.reset();
        logF.reset(); coalF.reset(); ironF.reset(); diaF.reset();
        phase = startPhase(p);
        Util.msg("АвтоАлмазка: бастады (кезең: " + phase + ")");
        writeResume();
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.options != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
            mc.options.useKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
        }
        if (mc.player != null && mc.currentScreen != null && !(mc.currentScreen instanceof net.minecraft.client.gui.screen.DeathScreen)) {
            mc.player.closeHandledScreen();
        }
        nav.reset();
        if (!keepResume) deleteResume();
        keepResume = false;
    }

    /** Әлем/сервер ауысқанда (кик, үзіліс) өшеді, бірақ қайта кіргенде жалғастыру белгісі қалады. */
    @Override
    public void reset() {
        if (enabled) { keepResume = true; setEnabled(false); }
    }

    // ================================================================ үзілістен кейін жалғастыру

    private static void writeResume() {
        try { java.nio.file.Files.writeString(RESUME, String.valueOf(System.currentTimeMillis())); } catch (Exception ignored) {}
    }

    private static void deleteResume() {
        try { java.nio.file.Files.deleteIfExists(RESUME); } catch (Exception ignored) {}
    }

    @Override
    public void alwaysTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (enabled || !java.nio.file.Files.exists(RESUME)) { resumeWait = 0; return; }
        if (mc.currentScreen != null || !p.isAlive()) return;
        if (++resumeWait < 100) return;                         // чанктар жүктелгенше күтеді
        resumeWait = 0;
        try {
            long t = Long.parseLong(java.nio.file.Files.readString(RESUME).trim());
            if (System.currentTimeMillis() - t > 600_000L) { deleteResume(); return; }   // 10 минуттан ескі
        } catch (Exception e) { deleteResume(); return; }
        Util.msg("АвтоАлмазка: үзіліс болды, жалғастырады");
        setEnabled(true);
    }

    private void fail(String msg) {
        Util.msg("АвтоАлмазка тоқтады: " + msg);
        setEnabled(false);
    }

    // ================================================================ санақтар

    private static int logs(ClientPlayerEntity p) { return Mine.count(p, s -> s.isIn(ItemTags.LOGS)); }
    private static int planks(ClientPlayerEntity p) { return Mine.count(p, s -> s.isIn(ItemTags.PLANKS)); }
    private static int cobble(ClientPlayerEntity p) { return Mine.count(p, Crafter.COBBLE); }
    private static int of(ClientPlayerEntity p, Item it) { return Mine.count(p, s -> s.isOf(it)); }
    private static boolean has(ClientPlayerEntity p, Item it) { return Util.hasInInventory(p, s -> s.isOf(it)); }

    private Phase startPhase(ClientPlayerEntity p) {
        if (has(p, Items.DIAMOND_CHESTPLATE) && has(p, Items.DIAMOND_SWORD)) return Phase.DONE;
        if (has(p, Items.DIAMOND_PICKAXE)) return of(p, Items.DIAMOND) >= (int) diamondsS.num() ? Phase.FINAL : Phase.DIAMOND;
        if (has(p, Items.IRON_PICKAXE)) return p.getY() <= deepY.num() + 2 ? Phase.DIAMOND1 : Phase.DESCEND;
        if (of(p, Items.RAW_IRON) >= 3) return Phase.SMELT;
        if (has(p, Items.STONE_PICKAXE)) return of(p, Items.COAL) >= 3 ? Phase.IRON : Phase.COAL;
        if (has(p, Items.WOODEN_PICKAXE)) return Phase.STONE;
        return Phase.WOOD;
    }

    private void setPhase(Phase ph) {
        phase = ph;
        bad.clear();
        target = null;
        ts = null;
        mineT = walkT = 0;
        java.util.Arrays.fill(failMask, 0);
        Util.msg("АвтоАлмазка: кезең → " + ph);
    }

    // ================================================================ негізгі цикл

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (ticks % 600 == 0) writeResume();
        if (ticks % 10 == 0) hud(p);
        if (p.getHealth() <= 0 || !p.isAlive()) {
            Util.msg("Өлді! Орны: " + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ());
            p.requestRespawn();
            setEnabled(false);
            return;
        }
        // верстак/пеш экраны тек жұмыс кезінде ашық болады
        if (mc.currentScreen != null && job.isEmpty()) return;

        if (mc.currentScreen == null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
            mc.options.useKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
        }

        nav.avoid = true;
        nav.avoidWater = true;
        nav.avoidFalling = true;
        nav.spawnerR = 14;
        nav.fightMobs = true;
        nav.fallGuard = true;
        nav.fallMin = 8;
        nav.dig = false;
        Mine.refreshSpawners(mc, p);

        if (mc.currentScreen == null && lavaGuard(mc, p)) return;
        if (nav.guard(mc, p, false)) return;
        if (mc.currentScreen == null) {
            if (nav.heal(mc, p, 8)) return;
        }
        if (nav.fightMobs(mc, p)) return;
        if (mc.currentScreen == null && handleEat(mc, p)) return;
        if (mc.currentScreen == null && dropJunk(mc, p)) return;

        // тұрып қалу күзеті
        int key = logs(p) + cobble(p) + of(p, Items.COAL) + of(p, Items.RAW_IRON) + of(p, Items.IRON_INGOT) + of(p, Items.DIAMOND)
                + ji * 3 + phase.ordinal() * 1000 + moves + (int) p.getY();
        if (key != lastProgressKey) { lastProgressKey = key; lastProgressTick = ticks; }
        if (ticks - lastProgressTick > 7000) { fail("ілгерілеу жоқ (тұрып қалды)"); return; }

        if (!job.isEmpty()) { runJob(mc, p); return; }
        if (ticks % 100 == 1 && mc.currentScreen == null) Mine.ensureBestPick(mc, p);
        if (collectT > 0 && collect(mc, p)) return;

        switch (phase) {
            case WOOD -> woodTick(mc, p);
            case STONE -> {
                if (cobble(p) >= 14) startJob(stoneJob(), Phase.COAL);
                else stoneTick(mc, p);
            }
            case COAL -> {
                if (of(p, Items.COAL) >= 3) setPhase(Phase.IRON);
                else oreTick(mc, p, coalF, false);
            }
            case IRON -> {
                if (of(p, Items.RAW_IRON) >= 3) startJob(smeltJob(), Phase.DESCEND);
                else oreTick(mc, p, ironF, false);
            }
            case SMELT -> startJob(smeltJob(), Phase.DESCEND);
            case DESCEND -> {
                if (p.getY() <= deepY.num()) setPhase(Phase.DIAMOND1);
                else digDown(mc, p, (int) deepY.num());
            }
            case DIAMOND1 -> {
                if (of(p, Items.DIAMOND) >= 3) startJob(diamondPickJob(), Phase.DIAMOND);
                else oreTick(mc, p, diaF, true);
            }
            case DIAMOND -> {
                if (of(p, Items.DIAMOND) >= (int) diamondsS.num()) startJob(finalJob(), Phase.DONE);
                else oreTick(mc, p, diaF, true);
            }
            case FINAL -> startJob(finalJob(), Phase.DONE);
            case DONE -> finish(mc);
        }
    }

    private void finish(MinecraftClient mc) {
        Util.msg("Бот Алмазка болды");
        if (mc.inGameHud != null) {
            mc.inGameHud.setTitleTicks(10, 80, 20);
            mc.inGameHud.setTitle(Text.literal("Бот Алмазка болды"));
        }
        setEnabled(false);
    }

    // ================================================================ экрандағы көрсеткіш

    private void hud(ClientPlayerEntity p) {
        String ph = switch (phase) {
            case WOOD -> "Ағаш " + logs(p) + "/" + (int) logsS.num();
            case STONE -> "Тас " + cobble(p) + "/14";
            case COAL -> "Көмір " + of(p, Items.COAL) + "/3";
            case IRON -> "Темір " + of(p, Items.RAW_IRON) + "/3";
            case SMELT -> "Балқыту";
            case DESCEND -> "Түсу → Y " + (int) deepY.num();
            case DIAMOND1, DIAMOND -> "Алмаз " + of(p, Items.DIAMOND) + "/" + (phase == Phase.DIAMOND1 ? 3 : (int) diamondsS.num());
            case FINAL -> "Соңғы крафт";
            case DONE -> "Дайын";
        };
        p.sendMessage(Text.literal("АвтоАлмазка | " + ph + " | Y " + p.getBlockY()), true);
    }

    // ================================================================ лава қорғанысы

    /** Лава жанына ағып келсе — булыжникпен жабады; лавада болса жоғары жүзеді. */
    private boolean lavaGuard(MinecraftClient mc, ClientPlayerEntity p) {
        if (lavaCool > 0) { lavaCool--; return false; }
        if (p.isInLava()) { mc.options.jumpKey.setPressed(true); return true; }
        BlockPos f = p.getBlockPos();
        BlockPos lava = null;
        outer:
        for (int dy = 0; dy <= 1; dy++) {
            for (int[] d : D) {
                BlockPos q = f.add(d[0], dy, d[1]);
                if (Mine.lava(mc, q)) { lava = q; break outer; }
            }
        }
        if (lava == null && Mine.lava(mc, f.up(2))) lava = f.up(2);
        if (lava == null && Mine.lava(mc, f.down())) lava = f.down();
        if (lava == null) { lavaT = 0; return false; }
        if (++lavaT > 40) { lavaT = 0; lavaCool = 100; return false; }      // жаба алмады — әуре болмайды
        int slot = Util.grab(mc, p, Crafter.COBBLE);
        if (slot < 0) return false;
        Util.select(p, slot);
        Util.aimAt(p, Vec3d.ofCenter(lava));
        if (mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK
                && bhr.getBlockPos().offset(bhr.getSide()).equals(lava)) {
            mc.options.useKey.setPressed(true);
        }
        return true;
    }

    // ================================================================ инвентарь толса — қоқыс тастау

    private boolean dropJunk(MinecraftClient mc, ClientPlayerEntity p) {
        if (dropCd > 0) { dropCd--; return false; }
        int free = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isEmpty()) free++;
        if (free > 3) return false;
        int cob = cobble(p);
        for (int i = 0; i < 36; i++) {
            ItemStack st = p.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            boolean junk = JUNK.contains(st.getItem()) || st.isIn(ItemTags.LEAVES) || st.isIn(ItemTags.SAPLINGS)
                    || (st.isOf(Items.COBBLESTONE) && cob - st.getCount() >= 64);     // 64-тен артық булыжник
            if (!junk) continue;
            int slot = i < 9 ? 36 + i : i;
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 1, SlotActionType.THROW, p);
            dropCd = 4;
            return true;
        }
        return false;
    }

    // ================================================================ тамақ

    private static boolean isFood(ItemStack s) {
        if (s.isEmpty() || s.get(DataComponentTypes.FOOD) == null) return false;
        return !s.isOf(Items.GOLDEN_APPLE) && !s.isOf(Items.ENCHANTED_GOLDEN_APPLE) && !s.isOf(Items.ROTTEN_FLESH)
                && !s.isOf(Items.SPIDER_EYE) && !s.isOf(Items.POISONOUS_POTATO) && !s.isOf(Items.PUFFERFISH)
                && !s.isOf(Items.CHORUS_FRUIT) && !s.isOf(Items.SUSPICIOUS_STEW);
    }

    private boolean handleEat(MinecraftClient mc, ClientPlayerEntity p) {
        if (eatTicks == 0 && p.getHungerManager().getFoodLevel() > 14) return false;
        int slot = Util.grab(mc, p, AutoAlmazka::isFood);
        if (slot < 0) { eatTicks = 0; return false; }
        Util.select(p, slot);
        mc.options.useKey.setPressed(true);
        eatTicks++;
        if (eatTicks > 50 || (eatTicks > 4 && !p.isUsingItem())) {
            eatTicks = 0;
            mc.options.useKey.setPressed(false);
        }
        return true;
    }

    // ================================================================ жерге түскен заттарды жинау

    private boolean collect(MinecraftClient mc, ClientPlayerEntity p) {
        collectT--;
        ItemEntity best = null;
        double bd = 64;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie) || !ie.isAlive()) continue;
            double d = ie.squaredDistanceTo(p);
            if (d < bd) { bd = d; best = ie; }
        }
        if (best == null || bd < 1.2) { collectT = Math.max(0, collectT - 4); return false; }
        nav.dig = true;
        nav.walk(mc, p, best.getX(), best.getZ());
        return true;
    }

    // ================================================================ ағаш (бет жағы)

    private void woodTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (logs(p) >= (int) logsS.num()) { startJob(woodJob(), Phase.STONE); return; }
        if (ticks % 6 == 0) logF.scan(mc, p, 6, 3);

        if (target != null && !mc.world.getBlockState(target).isIn(BlockTags.LOGS)) {
            target = null;
            collectT = 35;
            return;
        }
        if (target == null || bad.contains(target.asLong())) {
            target = nearestLog(logF.all(mc), p);
            walkT = mineT = 0;
            bestDist = Double.MAX_VALUE;
            lastHit = null;
        }
        if (target == null) { exploreSurface(mc, p); return; }
        exploreT = 0;

        double dist = p.getEyePos().distanceTo(Vec3d.ofCenter(target));
        if (dist <= 4.2) {
            BlockPos hit = Mine.hold(mc, p, target);
            if (hit != null && !hit.equals(target) && Mine.unsafe(mc, hit, true, false, 0)) { skipTree(target); return; }
            if (hit == null || !hit.equals(lastHit)) { lastHit = hit; mineT = 0; }   // басқа блок (жапырақ) қазылып жатса, таймер жаңарады
            if (++mineT > 150) skipTree(target);                                       // қазылмайды / көрінбейді → келесі ағашқа
        } else {
            nav.dig = true;          // жапырақты қазып өтеді
            nav.walk(mc, p, target.getX() + 0.5, target.getZ() + 0.5);
            if (dist < bestDist - 0.4) { bestDist = dist; walkT = 0; }
            if (++walkT > 80) skipTree(target);                                        // жақындай алмай тұр → ағашты ұмытады
        }
    }

    /** Қолы жетпейтін ағашты (және оның жанындағы бөренелерді) ұмытып, басқасына кетеді. */
    private void skipTree(BlockPos t) {
        MinecraftClient mc = Util.mc();
        bad.add(t.asLong());
        for (BlockPos b : logF.all(mc)) {
            if (Math.abs(b.getX() - t.getX()) <= 2 && Math.abs(b.getZ() - t.getZ()) <= 2) bad.add(b.asLong());
        }
        target = null;
        lastHit = null;
        walkT = mineT = 0;
        bestDist = Double.MAX_VALUE;
    }

    /** Ең жақын жететін бөрене (тым биіктері алынбайды). */
    private BlockPos nearestLog(List<BlockPos> list, ClientPlayerEntity p) {
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos();
        for (BlockPos b : list) {
            if (bad.contains(b.asLong())) continue;
            if (b.getY() > p.getY() + 4 || b.getY() < p.getY() - 6) continue;
            double d = Vec3d.ofCenter(b).squaredDistanceTo(eye);
            if (d < bd) { bd = d; best = b; }
        }
        return best;
    }

    /** Спавнер жанындағы рудаға бармайды (мобтар шығады). */
    private static boolean nearSpawner(BlockPos b) { return Mine.spawnerNear(b, 20); }

    private static int scanR(MinecraftClient mc) {
        return Math.max(4, Math.min(16, mc.options.getViewDistance().getValue()));
    }

    private BlockPos nearest(List<BlockPos> list, ClientPlayerEntity p) {
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos();
        for (BlockPos b : list) {
            if (bad.contains(b.asLong()) || nearSpawner(b)) continue;
            double d = Vec3d.ofCenter(b).squaredDistanceTo(eye);
            if (d < bd) { bd = d; best = b; }
        }
        return best;
    }

    private void exploreSurface(MinecraftClient mc, ClientPlayerEntity p) {
        exploreT++;
        if (exploreT > 3200) { fail("Ағаш табылмады"); return; }
        if (exploreT % 300 == 1) surfaceYaw += 70f + (float) (Math.random() * 60f);
        double rad = Math.toRadians(surfaceYaw);
        nav.dig = false;
        nav.walk(mc, p, p.getX() - Math.sin(rad) * 30, p.getZ() + Math.cos(rad) * 30);
    }

    // ================================================================ руда

    /** Руданы табады: жақын болса қазады, әйтпесе тоннель қазып барады. Руда көрінбесе — горизонтальды зерттейді. */
    private void oreTick(MinecraftClient mc, ClientPlayerEntity p, BlockFinder f, boolean diamond) {
        if (ticks % 4 == 0) f.scan(mc, p, scanR(mc), 6);     // рентген сияқты: жүктелген чанктардың бәрінен руда іздейді

        if (target != null) {
            boolean still = f.test(mc.world.getBlockState(target));
            if (!still || bad.contains(target.asLong())) {
                if (!still) collectT = 45;
                target = null;
                ts = null;
                return;
            }
        }
        if (target == null) {
            target = diamond ? pickDiamond(mc, p, f.all(mc)) : nearest(f.all(mc), p);
            walkT = mineT = 0;
        }
        if (target == null) { explore(mc, p); return; }

        double dist = p.getEyePos().distanceTo(Vec3d.ofCenter(target));
        if (dist <= 4.2) {
            if (Mine.unsafe(mc, target, true, false, 14)) { bad.add(target.asLong()); target = null; return; }
            BlockPos hit = Mine.hold(mc, p, target);
            if (hit != null && !hit.equals(target) && Mine.unsafe(mc, hit, true, true, 14)) { bad.add(target.asLong()); target = null; return; }
            if (++mineT > 320) { bad.add(target.asLong()); target = null; }
        } else {
            tunnelTo(mc, p, target);
            if (++walkT > 2500) { bad.add(target.asLong()); target = null; ts = null; }
        }
    }

    /** Алмаз: жанында ≥3 руда бар кластердің ең жақынын таңдайды; бірақ жақын (≤6) руда болса, соны алдымен бітіреді. */
    private BlockPos pickDiamond(MinecraftClient mc, ClientPlayerEntity p, List<BlockPos> all) {
        List<BlockPos> list = new ArrayList<>();
        for (BlockPos b : all) if (!bad.contains(b.asLong()) && !nearSpawner(b)) list.add(b);
        if (list.isEmpty()) return null;
        Vec3d eye = p.getEyePos();
        BlockPos near = null;
        double nd = Double.MAX_VALUE;
        for (BlockPos b : list) {
            double d = Vec3d.ofCenter(b).squaredDistanceTo(eye);
            if (d < nd) { nd = d; near = b; }
        }
        if (nd <= 36) return near;                    // жақын руданы бітіру
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (BlockPos b : list) {
            int size = 0;
            for (BlockPos o : list) {
                if (Math.abs(o.getX() - b.getX()) <= 3 && Math.abs(o.getY() - b.getY()) <= 3 && Math.abs(o.getZ() - b.getZ()) <= 3) size++;
            }
            if (size < 3) continue;
            double d = Vec3d.ofCenter(b).squaredDistanceTo(eye);
            if (d < bd) { bd = d; best = b; }
        }
        return best != null ? best : near;
    }

    private void explore(MinecraftClient mc, ClientPlayerEntity p) {
        if (exploreSteps > 70) { exploreSteps = 0; exploreDir = (exploreDir + 1) & 3; }
        BlockPos f = p.getBlockPos();
        BlockPos goal = f.add(D[exploreDir][0] * 20, 0, D[exploreDir][1] * 20);
        if (Mine.spawnerNear(goal, 26) || Mine.spawnerNear(f.add(D[exploreDir][0] * 10, 0, D[exploreDir][1] * 10), 26)) {
            exploreDir = (exploreDir + 1) & 3;        // спавнер жаққа қазбайды
            exploreSteps = 0;
            ts = null;
            return;
        }
        tunnelTo(mc, p, goal);
    }

    // ================================================================ тас (булыжник)

    private static boolean stoneAt(MinecraftClient mc, BlockPos b) {
        return mc.world.getBlockState(b).isOf(Blocks.STONE) || mc.world.getBlockState(b).isOf(Blocks.COBBLESTONE);
    }

    /** Тастың ішінде ме: аяқ деңгейіндегі 4 жақтың кемі 3-еуі тас. */
    private boolean inStone(MinecraftClient mc, BlockPos f) {
        int n = 0;
        for (int[] d : D) if (stoneAt(mc, f.add(d[0], 0, d[1]))) n++;
        return n >= 3;
    }

    /** Жан-жағындағы (аяқ және бас деңгейі) қазылмаған тасты табады. */
    private BlockPos nextSide(MinecraftClient mc, BlockPos f) {
        for (int up = 0; up <= 1; up++) {
            for (int[] d : D) {
                BlockPos b = f.add(d[0], up, d[1]);
                if (bad.contains(b.asLong()) || !stoneAt(mc, b)) continue;
                return b;
            }
        }
        return null;
    }

    /** Астыға түзу қазады; тасқа жеткенде тұрған жерінің жан-жағын қазып, булыжник жинайды, сосын тағы бір блок төмендейді. */
    private void stoneTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (ts != null) { tunnelTo(mc, p, p.getBlockPos().down()); return; }
        BlockPos f = p.getBlockPos();
        if (target != null && (!stoneAt(mc, target) || bad.contains(target.asLong()))) { target = null; mineT = 0; }
        if (target == null && inStone(mc, f)) { target = nextSide(mc, f); mineT = 0; }
        if (target != null) {
            if (Mine.unsafe(mc, target, true, true, 14)) { bad.add(target.asLong()); target = null; return; }
            BlockPos hit = Mine.hold(mc, p, target);
            if (hit != null && !hit.equals(target) && Mine.unsafe(mc, hit, true, true, 14)) { bad.add(target.asLong()); target = null; return; }
            if (++mineT > 120) { bad.add(target.asLong()); target = null; }
            return;
        }
        tunnelTo(mc, p, f.down());            // жан-жағы біткен (немесе тас жоқ) → бір блок төмен
    }

    private void digDown(MinecraftClient mc, ClientPlayerEntity p, int y) {
        if (p.getY() <= y + 1) return;
        BlockPos f = p.getBlockPos();
        tunnelTo(mc, p, new BlockPos(f.getX(), y, f.getZ()));
    }

    // ================================================================ тоннель (қауіпсіз қазу)

    private TStep build(int mode, BlockPos f, int i) {
        BlockPos ahead = f.add(D[i][0], 0, D[i][1]);
        List<BlockPos> clear = new ArrayList<>();
        BlockPos dest;
        boolean jump = false;
        switch (mode) {
            case DOWN -> { clear.add(ahead.up()); clear.add(ahead); clear.add(ahead.down()); dest = ahead.down(); }
            case SHAFT -> { clear.add(f.down()); dest = f.down(); }
            case UP -> { clear.add(f.up(2)); clear.add(ahead.up()); clear.add(ahead.up(2)); dest = ahead.up(); jump = true; }
            default -> { clear.add(ahead.up()); clear.add(ahead); dest = ahead; }
        }
        return new TStep(dest, clear, jump, i, mode);
    }

    private boolean safe(MinecraftClient mc, TStep s, BlockPos f) {
        for (BlockPos c : s.clear) {
            if (Mine.passable(mc, c)) {
                if (Mine.lava(mc, c) || Mine.water(mc, c)) return false;
            } else if (Mine.unsafe(mc, c, true, true, 14)) {
                return false;
            }
        }
        if (Mine.unsafe(mc, s.dest, true, false, 0) || Mine.unsafe(mc, s.dest.up(), true, false, 0)) return false;
        if (Mine.passable(mc, s.dest.down())) return false;                  // аяқ астында тірек жоқ (шұңқыр/лава)
        if ((s.mode == SHAFT || s.mode == DOWN) && Mine.passable(mc, s.dest.down(2))) return false;   // астында үңгір/бос жер — құламайды
        if (s.mode == UP && Mine.passable(mc, f.add(D[s.dirIdx][0], 0, D[s.dirIdx][1]))) return false;
        return true;
    }

    private TStep plan(MinecraftClient mc, BlockPos f, BlockPos goal) {
        int dx = goal.getX() - f.getX(), dy = goal.getY() - f.getY(), dz = goal.getZ() - f.getZ();
        double horiz = Math.hypot(dx, dz);
        boolean xdom = Math.abs(dx) >= Math.abs(dz);
        int primary = xdom ? (dx >= 0 ? 0 : 2) : (dz >= 0 ? 1 : 3);
        int secondary = xdom ? (dz == 0 ? -1 : (dz > 0 ? 1 : 3)) : (dx == 0 ? -1 : (dx > 0 ? 0 : 2));
        boolean vertical = dy != 0 && (horiz < 0.5 || Math.abs(dy) > horiz * 0.5);
        int vmode = dy < 0 ? DOWN : UP;

        int[] order = horiz < 0.5
                ? new int[] { sdir, (sdir + 1) & 3, (sdir + 3) & 3, (sdir + 2) & 3 }
                : new int[] { primary, secondary >= 0 ? secondary : (primary + 1) & 3, (primary + 1) & 3, (primary + 3) & 3, (primary + 2) & 3 };
        // нысана төменде болса: алдымен түзу астыға (шахта) — нысананың Y-іне жеткенше, сосын жанына қарай
        int[] modes = dy < 0 ? new int[] { SHAFT, DOWN, HORIZ } : vertical ? new int[] { vmode, HORIZ } : new int[] { HORIZ };

        for (int mode : modes) {
            for (int i : (mode == SHAFT ? new int[] { 0 } : order)) {
                if ((failMask[mode] & (1 << i)) != 0) continue;
                TStep s = build(mode, f, i);
                if (safe(mc, s, f)) {
                    if (horiz < 0.5) sdir = i;
                    return s;
                }
                failMask[mode] |= 1 << i;
            }
        }
        java.util.Arrays.fill(failMask, 0);
        return null;
    }

    private void tunnelTo(MinecraftClient mc, ClientPlayerEntity p, BlockPos goal) {
        if (ts == null) {
            ts = plan(mc, p.getBlockPos(), goal);
            if (ts == null) {
                planFail++;
                if (target != null && planFail > 10) { bad.add(target.asLong()); target = null; planFail = 0; }   // жол жоқ → басқа руда
                else if (planFail > 60) fail("қазатын қауіпсіз жол табылмады");
                return;
            }
            planFail = 0;
        }
        TStep s = ts;
        s.t++;

        // 0) шахта: алдымен блоктың ортасына тұрады (әйтпесе тесікке түспей қалады)
        if (s.mode == SHAFT && !Mine.passable(mc, s.clear.get(0)) && s.t < 70) {
            BlockPos b = p.getBlockPos();
            double cx = b.getX() + 0.5, cz = b.getZ() + 0.5;
            double off = Math.hypot(p.getX() - cx, p.getZ() - cz);
            if (off > 0.15) {
                float cyaw = (float) (MathHelper.atan2(cz - p.getZ(), cx - p.getX()) * 180.0 / Math.PI) - 90f;
                Util.smoothYaw(p, cyaw);
                Util.smoothPitch(p, 0f);
                mc.options.sneakKey.setPressed(true);
                if (Math.abs(MathHelper.wrapDegrees(cyaw - p.getYaw())) < 30f) mc.options.forwardKey.setPressed(true);
                return;
            }
        }

        // 1) жолдағы блоктарды қазу
        for (BlockPos c : s.clear) {
            if (Mine.passable(mc, c)) continue;
            BlockPos hit = Mine.hold(mc, p, c);
            if (hit != null && !hit.equals(c) && !s.clear.contains(hit) && Mine.unsafe(mc, hit, true, true, 14)) {
                failMask[s.mode] |= 1 << s.dirIdx;
                ts = null;
                return;
            }
            if (s.t > 220) { failMask[s.mode] |= 1 << s.dirIdx; ts = null; }
            return;
        }

        // 2) орынға жүру
        Vec3d dc = Vec3d.ofCenter(s.dest);
        boolean arrived;
        if (s.mode == SHAFT) {
            arrived = p.getY() <= s.dest.getY() + 0.25;            // түзу құлайды, жүрмейді
        } else {
            float yaw = (float) (MathHelper.atan2(dc.z - p.getZ(), dc.x - p.getX()) * 180.0 / Math.PI) - 90f;
            Util.smoothYaw(p, yaw);
            Util.smoothPitch(p, 0f);
            if (Math.abs(MathHelper.wrapDegrees(yaw - p.getYaw())) < 30f) mc.options.forwardKey.setPressed(true);
            if (s.jump && p.isOnGround()) mc.options.jumpKey.setPressed(true);
            arrived = p.getBlockPos().equals(s.dest)
                    || (Math.abs(p.getX() - dc.x) < 0.4 && Math.abs(p.getZ() - dc.z) < 0.4 && Math.abs(p.getY() - s.dest.getY()) < 1.1);
        }
        if (arrived) {
            ts = null;
            moves++;
            exploreSteps++;
            java.util.Arrays.fill(failMask, 0);
        } else if (s.t > 160) {
            failMask[s.mode] |= 1 << s.dirIdx;
            ts = null;
        }
    }

    // ================================================================ верстак / пеш жұмысы

    private static Step st(SK k) { return new Step(k, null, 0); }
    private static Step st(SK k, Crafter.Recipe r, int n) { return new Step(k, r, n); }

    private List<Step> woodJob() {
        return new ArrayList<>(List.of(
                st(SK.CRAFT_ALL, Crafter.PLANKS, -1),
                st(SK.CRAFT, Crafter.TABLE, 1),
                st(SK.PLACE_TABLE), st(SK.OPEN_TABLE),
                st(SK.CRAFT, Crafter.WOOD_PICK, 1),
                st(SK.CLOSE), st(SK.BREAK_TABLE)));
    }

    private List<Step> stoneJob() {
        return new ArrayList<>(List.of(
                st(SK.PLACE_TABLE), st(SK.OPEN_TABLE),
                st(SK.CRAFT, Crafter.STONE_PICK, 1),
                st(SK.CRAFT, Crafter.STONE_AXE, 1),
                st(SK.CRAFT, Crafter.FURNACE, 1),
                st(SK.CLOSE), st(SK.BREAK_TABLE)));
    }

    private List<Step> smeltJob() {
        return new ArrayList<>(List.of(
                st(SK.PLACE_TABLE), st(SK.PLACE_FURNACE),
                st(SK.OPEN_FURNACE), st(SK.SMELT), st(SK.CLOSE),
                st(SK.OPEN_TABLE), st(SK.CRAFT, Crafter.IRON_PICK, 1), st(SK.CLOSE),
                st(SK.BREAK_FURNACE), st(SK.BREAK_TABLE)));
    }

    private List<Step> diamondPickJob() {
        return new ArrayList<>(List.of(
                st(SK.PLACE_TABLE), st(SK.OPEN_TABLE),
                st(SK.CRAFT, Crafter.DIAMOND_PICK, 1),
                st(SK.CLOSE), st(SK.BREAK_TABLE)));
    }

    private List<Step> finalJob() {
        return new ArrayList<>(List.of(
                st(SK.PLACE_TABLE), st(SK.OPEN_TABLE),
                st(SK.CRAFT, Crafter.DIAMOND_SWORD, 1),
                st(SK.CRAFT, Crafter.DIAMOND_AXE, 1),
                st(SK.CRAFT, Crafter.DIAMOND_HELMET, 1),
                st(SK.CRAFT, Crafter.DIAMOND_CHEST, 1),
                st(SK.CRAFT, Crafter.DIAMOND_LEGS, 1),
                st(SK.CRAFT, Crafter.DIAMOND_BOOTS, 1),
                st(SK.CLOSE), st(SK.EQUIP), st(SK.BREAK_TABLE)));
    }

    private void startJob(List<Step> steps, Phase after) {
        job.clear();
        job.addAll(steps);
        ji = 0;
        stepT = 0;
        afterJob = after;
        tablePos = furnacePos = nichePos = null;
        crafting = false;
        placeTries = openTries = smeltState = 0;
        target = null;
        ts = null;
        Util.msg("АвтоАлмазка: верстак жұмысы (" + phase + ")");
    }

    private void next() {
        ji++;
        stepT = 0;
        crafting = false;
        placeTries = 0;
        openTries = 0;
        smeltState = 0;
    }

    private void endJob(MinecraftClient mc, ClientPlayerEntity p) {
        job.clear();
        tablePos = furnacePos = nichePos = null;
        if (mc.currentScreen != null) p.closeHandledScreen();
        Mine.ensureBestPick(mc, p);
        Phase a = afterJob;
        if (a == Phase.DONE) { phase = Phase.DONE; return; }
        setPhase(a);
    }

    private void runJob(MinecraftClient mc, ClientPlayerEntity p) {
        if (ji >= job.size()) { endJob(mc, p); return; }
        Step s = job.get(ji);
        stepT++;
        switch (s.k) {
            case CRAFT, CRAFT_ALL -> craftStep(mc, p, s);
            case PLACE_TABLE -> placeStep(mc, p, true);
            case PLACE_FURNACE -> placeStep(mc, p, false);
            case OPEN_TABLE -> openStep(mc, p, true);
            case OPEN_FURNACE -> openStep(mc, p, false);
            case SMELT -> smeltStep(mc, p);
            case CLOSE -> {
                if (mc.currentScreen != null) p.closeHandledScreen();
                if (stepT > 2) next();
            }
            case BREAK_TABLE -> breakStep(mc, p, true);
            case BREAK_FURNACE -> breakStep(mc, p, false);
            case EQUIP -> equipStep(mc, p);
        }
    }

    private void craftStep(MinecraftClient mc, ClientPlayerEntity p, Step s) {
        if (!crafting) {
            // таяқша керек болса, алдымен өзі жасайды
            if (s.k == SK.CRAFT) {
                int needS = s.r.stickCells();
                if (needS > 0 && of(p, Items.STICK) < needS) {
                    job.add(ji, st(SK.CRAFT, Crafter.STICKS, (needS + 3) / 4 + 1));
                    return;
                }
            }
            boolean ok = crafter.start(mc, p, s.r, s.n < 0 ? 64 : s.n);
            if (!ok) {
                if (s.k == SK.CRAFT_ALL) { next(); return; }
                if (s.r == Crafter.STICKS && logs(p) > 0) {
                    job.add(ji, st(SK.CRAFT_ALL, Crafter.PLANKS, -1));
                    return;
                }
                fail("крафт жасалмады: " + crafter.error());
                return;
            }
            crafting = true;
            return;
        }
        Crafter.Status status = crafter.tick(mc, p);
        if (status == Crafter.Status.DONE) {
            if (s.k == SK.CRAFT_ALL) { crafting = false; return; }      // тағы бар ма деп қайталайды
            next();
        } else if (status == Crafter.Status.FAILED) {
            fail("крафт қатесі: " + crafter.error());
        }
    }

    private BlockPos findSpot(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos f = p.getBlockPos();
        for (int i = 0; i < 4; i++) {
            BlockPos c = f.add(D[i][0], 0, D[i][1]);
            if (c.equals(tablePos) || c.equals(furnacePos)) continue;
            net.minecraft.block.BlockState s = mc.world.getBlockState(c);
            if (!(s.isAir() || s.isReplaceable()) || !s.getFluidState().isEmpty()) continue;
            if (Mine.passable(mc, c.down())) continue;
            if (Mine.water(mc, c.down()) || Mine.lava(mc, c.down())) continue;
            return c;
        }
        return null;
    }

    /** Бос орын жоқ болса, қабырғадан ұяшық қазады. */
    private void digNiche(MinecraftClient mc, ClientPlayerEntity p) {
        if (nichePos == null) {
            BlockPos f = p.getBlockPos();
            for (int i = 0; i < 4 && nichePos == null; i++) {
                BlockPos n = f.add(D[i][0], 0, D[i][1]);
                if (Mine.passable(mc, n) || Mine.unsafe(mc, n, true, true, 14)) continue;
                if (Mine.passable(mc, n.down())) continue;
                nichePos = n;
            }
            if (nichePos == null) { fail("верстак қоятын орын жоқ"); return; }
        }
        if (Mine.passable(mc, nichePos)) { nichePos = null; return; }
        Mine.hold(mc, p, nichePos);
    }

    private void placeStep(MinecraftClient mc, ClientPlayerEntity p, boolean table) {
        Item item = table ? Items.CRAFTING_TABLE : Items.FURNACE;
        net.minecraft.block.Block blk = table ? Blocks.CRAFTING_TABLE : Blocks.FURNACE;
        BlockPos cur = table ? tablePos : furnacePos;

        if (cur != null) {                                               // қойылғанын күту
            if (mc.world.getBlockState(cur).isOf(blk)) { next(); return; }
            if (stepT > 40) { if (table) tablePos = null; else furnacePos = null; }
            return;
        }
        if (mc.currentScreen != null) { p.closeHandledScreen(); return; }

        int slot = Util.grab(mc, p, s -> s.isOf(item));
        if (slot < 0) {
            if (!table) { fail("пеш жоқ (тас жетпеді?)"); return; }
            if (planks(p) >= 4) job.add(ji, st(SK.CRAFT, Crafter.TABLE, 1));
            else if (logs(p) > 0) { job.add(ji, st(SK.CRAFT, Crafter.TABLE, 1)); job.add(ji, st(SK.CRAFT_ALL, Crafter.PLANKS, -1)); }
            else fail("верстак жасайтын ағаш жоқ");
            return;
        }
        if (++placeTries > 120) { fail("верстак қоятын орын табылмады"); return; }

        BlockPos spot = findSpot(mc, p);
        if (spot == null) { digNiche(mc, p); return; }
        Util.select(p, slot);
        Util.place(mc, p, spot.down(), Direction.UP);
        if (table) tablePos = spot; else furnacePos = spot;
        stepT = 0;
    }

    private void openBlock(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        Vec3d c = Vec3d.ofCenter(pos);
        Vec3d eye = p.getEyePos();
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Vec3d hit = c.add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        Util.aimNow(p, c);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, side, pos, false));
        p.swingHand(Hand.MAIN_HAND);
    }

    private void openStep(MinecraftClient mc, ClientPlayerEntity p, boolean table) {
        BlockPos bp = table ? tablePos : furnacePos;
        if (bp == null) { fail("верстак/пеш орны жоғалды"); return; }
        ScreenHandler h = p.currentScreenHandler;
        boolean open = table ? h instanceof CraftingScreenHandler : h instanceof FurnaceScreenHandler;
        if (open) { next(); return; }
        if (mc.currentScreen != null) { p.closeHandledScreen(); return; }
        if (stepT % 6 == 1) {
            openBlock(mc, p, bp);
            if (++openTries > 8) fail("верстак/пеш ашылмады");
        }
    }

    private static int findSlot(ScreenHandler h, int from, Predicate<ItemStack> f) {
        for (int i = from; i < h.slots.size(); i++) {
            ItemStack s = h.getSlot(i).getStack();
            if (!s.isEmpty() && f.test(s)) return i;
        }
        return -1;
    }

    private void click(MinecraftClient mc, ClientPlayerEntity p, ScreenHandler h, int slot, int button, SlotActionType t) {
        mc.interactionManager.clickSlot(h.syncId, slot, button, t, p);
    }

    private void smeltStep(MinecraftClient mc, ClientPlayerEntity p) {
        if (!(p.currentScreenHandler instanceof FurnaceScreenHandler h)) { fail("пеш экраны жабылды"); return; }
        switch (smeltState) {
            case 0 -> {
                int raw = findSlot(h, 3, s -> s.isOf(Items.RAW_IRON));
                if (raw < 0) { fail("шикі темір жоқ"); return; }
                click(mc, p, h, raw, 0, SlotActionType.PICKUP);
                for (int i = 0; i < 3; i++) click(mc, p, h, 0, 1, SlotActionType.PICKUP);
                click(mc, p, h, raw, 0, SlotActionType.PICKUP);

                int fuelN = 1;
                int fuel = findSlot(h, 3, s -> s.isOf(Items.COAL));
                if (fuel < 0) { fuelN = 2; fuel = findSlot(h, 3, s -> s.isIn(ItemTags.PLANKS)); }
                if (fuel < 0) { fail("пешке отын жоқ"); return; }
                click(mc, p, h, fuel, 0, SlotActionType.PICKUP);
                for (int i = 0; i < fuelN; i++) click(mc, p, h, 1, 1, SlotActionType.PICKUP);
                click(mc, p, h, fuel, 0, SlotActionType.PICKUP);
                smeltState = 1;
                stepT = 0;
            }
            case 1 -> {
                ItemStack out = h.getSlot(2).getStack();
                if (!out.isEmpty() && out.getCount() >= 3) {
                    click(mc, p, h, 2, 0, SlotActionType.QUICK_MOVE);
                    smeltState = 2;
                    stepT = 0;
                } else if (stepT > 2600) {
                    fail("пеш темірді пісірмеді");
                }
            }
            default -> { if (stepT > 6) next(); }
        }
    }

    private void breakStep(MinecraftClient mc, ClientPlayerEntity p, boolean table) {
        BlockPos bp = table ? tablePos : furnacePos;
        if (bp == null || mc.world.getBlockState(bp).isAir()) { collectT = 40; next(); return; }
        if (mc.currentScreen != null) { p.closeHandledScreen(); return; }
        Mine.hold(mc, p, bp);
        if (stepT > 400) next();
    }

    private void equipStep(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) { p.closeHandledScreen(); return; }
        if (stepT == 1) {
            ScreenHandler h = p.playerScreenHandler;
            for (int i = 9; i <= 44; i++) {
                ItemStack s = h.getSlot(i).getStack();
                if (s.isOf(Items.DIAMOND_HELMET) || s.isOf(Items.DIAMOND_CHESTPLATE)
                        || s.isOf(Items.DIAMOND_LEGGINGS) || s.isOf(Items.DIAMOND_BOOTS)) {
                    click(mc, p, h, i, 0, SlotActionType.QUICK_MOVE);
                }
            }
        }
        if (stepT > 8) next();
    }
}
