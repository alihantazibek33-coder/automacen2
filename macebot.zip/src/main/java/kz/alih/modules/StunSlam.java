package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.Vec3d;

/** СтанСлэм: қылыш қолда болғанда, щит ұстаған игрокты балтамен соғып, бірден қылышқа ауысып ұрады (UHC). */
public class StunSlam extends Module {
    private final Setting range = num("Қашықтық", 3.2, 2.0, 4.5, 0.1);
    private final Setting cone = num("Конус (°)", 40, 10, 90, 5);

    private int cooldown, switchBack = -1, backSlot = -1;
    private Entity pending;

    public StunSlam() {
        super("stunslam", "СтанСлэм", "Щитті балтамен бұзып, бірден қылышпен ұрады (UHC)");
    }

    @Override
    public void reset() { cooldown = 0; switchBack = -1; backSlot = -1; pending = null; }

    private PlayerEntity findBlocking(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.targetedEntity instanceof PlayerEntity t && Util.validPlayer(p, t) && t.isBlocking()
                && Util.boxDist(p.getEyePos(), t.getBoundingBox()) <= range.num()) return t;
        PlayerEntity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PlayerEntity t) || !Util.validPlayer(p, t) || !t.isBlocking()) continue;
            double d = Util.boxDist(p.getEyePos(), t.getBoundingBox());
            if (d > range.num()) continue;
            Vec3d c = Util.center(t);
            if (Util.angleTo(p, c) > cone.num() / 2.0) continue;
            if (d < bd) { bd = d; best = t; }
        }
        return best;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (cooldown > 0) cooldown--;
        if (mc.currentScreen != null) return;

        // 2-қадам: қылышқа қайта ауысып ұру
        if (switchBack >= 0) {
            if (--switchBack < 0) {
                if (backSlot >= 0) Util.select(p, backSlot);
                if (pending instanceof LivingEntity le && le.isAlive()
                        && Util.boxDist(p.getEyePos(), le.getBoundingBox()) <= range.num() + 0.5) {
                    Util.attack(mc, p, pending);
                }
                pending = null;
                backSlot = -1;
                cooldown = Util.jitter(12, 8);
            }
            return;
        }
        if (cooldown > 0) return;

        // тек қолда қылыш (не мейс) болғанда
        boolean holdingWeapon = p.getMainHandStack().isIn(ItemTags.SWORDS) || p.getMainHandStack().isOf(Items.MACE);
        if (!holdingWeapon) return;
        if (p.getAttackCooldownProgress(0.5f) < 0.9f) return;

        PlayerEntity t = findBlocking(mc, p);
        if (t == null) return;
        int axe = Util.findHotbar(p, s -> s.isIn(ItemTags.AXES));
        if (axe < 0) return;

        backSlot = Util.selected(p);
        Util.select(p, axe);
        Util.attack(mc, p, t);
        pending = t;
        switchBack = 1;
    }
}
