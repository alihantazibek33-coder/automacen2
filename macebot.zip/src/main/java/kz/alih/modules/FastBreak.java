package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/**
 * FastBreak: блокты қазғанда әр тикте қосымша прогресс қосады және блоктар арасындағы кідірісті азайтады.
 * Көп серверде тым жылдам қазу (≈ ×1.4-тен жоғары) блокты кері қайтарады.
 */
public class FastBreak extends Module {
    private final Setting mult = num("Жылдамдық ×", 1.5, 1.0, 5.0, 0.25);
    private double acc;

    public FastBreak() {
        super("fastbreak", "FastBreak", "Блокты жылдам қазады (кідіріссіз, үдетілген)");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null || !mc.options.attackKey.isPressed() || p.isCreative()) { acc = 0; return; }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        acc += mult.num() - 1.0;
        // қосымша шақыру: прогресс қосады және блоктар арасындағы кідірісті азайтады
        int extra = (int) acc;
        acc -= extra;
        for (int i = 0; i < extra; i++) {
            mc.interactionManager.updateBlockBreakingProgress(hit.getBlockPos(), hit.getSide());
        }
    }
}
