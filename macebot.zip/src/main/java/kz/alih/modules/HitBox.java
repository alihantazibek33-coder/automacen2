package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/**
 * ХитБокс: нысананың хитбоксын үлкейтеді (10 блокқа дейін). Прицел хитбокс ішінде болса, нысана ұрылады.
 * Екі жол: (1) EntityMixin — ванилла прицелі үшін (1 блокқа дейін), (2) assist() — үлкен өлшем үшін;
 * assist ұрудың алдында (MinecraftClientMixin) және әр тик соңында (модульдер үшін) шақырылады.
 * Ескерту: сервер ұруды нақты хитбоксқа дейінгі қашықтықпен тексереді (ванилла ~4 блок), сондықтан алыстан ұру үшін Рич те керек.
 */
public class HitBox extends Module {
    public static HitBox INSTANCE;

    private final Setting size = num("Үлкейту (блок)", 0.5, 0.5, 10.0, 0.5);
    private final Setting playersOnly = bool("Тек игрок", true);

    public HitBox() {
        super("hitbox", "ХитБокс", "Нысананың хитбоксын 10 блокқа дейін үлкейтеді (прицелге оңай түседі)");
        INSTANCE = this;
    }

    /** EntityMixin шақырады: ванилла прицелі үшін қосымша хитбокс (блок). 0 — өзгеріссіз. */
    public static float marginFor(Entity e) {
        HitBox h = INSTANCE;
        if (h == null || !h.enabled) return 0f;
        if (!(e instanceof LivingEntity) || e == MinecraftClient.getInstance().player) return 0f;
        if (h.playersOnly.on() && !(e instanceof PlayerEntity)) return 0f;
        if (Util.isIgnored(e)) return 0f;
        // ванилла прицелі 1 блоктан үлкенін іздемейді; қалғанын assist() жасайды
        return (float) Math.min(h.size.num(), 1.0);
    }

    /**
     * Прицел ешкімді көрмесе, үлкейтілген хитбоксқа түсетін ең жақын нысананы прицел нысанасы етеді.
     * Нақты хитбоксқа дейінгі қашықтық ұру қашықтығынан (Рич) аспауы керек.
     */
    public void assist(MinecraftClient mc) {
        if (!enabled || mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (mc.crosshairTarget instanceof EntityHitResult) return;

        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        double reach = p.getEntityInteractionRange();
        double grow = size.num();
        Vec3d end = eye.add(look.multiply(reach + grow));

        double blockDist = Double.MAX_VALUE;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            blockDist = mc.crosshairTarget.getPos().distanceTo(eye);
        }

        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == p || !e.isAlive()) continue;
            if (e instanceof PlayerEntity pl && pl.isSpectator()) continue;
            if (playersOnly.on() && !(e instanceof PlayerEntity)) continue;
            if (Util.isIgnored(e)) continue;

            Box real = e.getBoundingBox();
            double rd = Util.boxDist(eye, real);
            if (rd > reach) continue;                       // сервер нақты хитбоксқа дейін санайды

            Box big = real.expand(grow);
            double hitDist;
            if (big.contains(eye)) {
                hitDist = 0.0;                              // үлкен хитбокстың ішінде тұрмыз
            } else {
                Optional<Vec3d> hit = big.raycast(eye, end);
                if (hit.isEmpty()) continue;
                hitDist = hit.get().distanceTo(eye);
            }
            if (hitDist >= blockDist) continue;             // алдында блок тұр
            if (rd < bd) { bd = rd; best = e; }
        }
        if (best == null) return;

        Box rb = best.getBoundingBox();
        Vec3d at = new Vec3d(
                MathHelper.clamp(eye.x, rb.minX, rb.maxX),
                MathHelper.clamp(eye.y, rb.minY, rb.maxY),
                MathHelper.clamp(eye.z, rb.minZ, rb.maxZ));
        mc.targetedEntity = best;
        mc.crosshairTarget = new EntityHitResult(best, at);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // әрекет assist() және EntityMixin ішінде
    }
}
