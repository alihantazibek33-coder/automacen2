package kz.alih.modules;

import kz.alih.AlihClient;
import kz.alih.HudUtil;
import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** HUD: watermark (FPS, ping, координат) және қосулы модульдердің анимациялы түрлі-түсті тізімі. */
public class Hud extends Module {
    public static Hud INSTANCE;

    private final Setting watermark = bool("Watermark", true);
    private final Setting list = bool("Модуль тізімі", true);

    private final Map<Module, Float> anim = new HashMap<>();

    public Hud() {
        super("hud", "HUD", "Watermark және қосулы модульдер тізімі (анимациямен)");
        INSTANCE = this;
    }

    @Override
    public boolean defaultEnabled() { return true; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {}

    public static void render(DrawContext ctx) {
        Hud h = INSTANCE;
        if (h == null || !h.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        h.draw(ctx, mc, mc.player);
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p) {
        TextRenderer tr = mc.textRenderer;
        double time = System.currentTimeMillis() / 4000.0;

        if (watermark.on()) {
            int ping = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry pe = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (pe != null) ping = pe.getLatency();
            }
            String brand = "AlihClient";
            String info = " | " + mc.getCurrentFps() + " FPS | " + ping + " ms | "
                    + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ();
            int w = tr.getWidth(brand) + tr.getWidth(info) + 8;
            ctx.fill(2, 2, 2 + w, 14, 0x90000000);
            ctx.fill(2, 2, 2 + w, 3, HudUtil.hsv(time, 0.6, 1.0));
            int x = 6;
            for (int i = 0; i < brand.length(); i++) {
                String ch = String.valueOf(brand.charAt(i));
                ctx.drawText(tr, ch, x, 5, HudUtil.hsv(time + i * 0.04, 0.6, 1.0), true);
                x += tr.getWidth(ch);
            }
            ctx.drawText(tr, info, x, 5, 0xFFDDDDDD, true);
        }

        if (!list.on()) return;

        // анимация: қосылғанда оңнан сырғып кіреді, өшкенде кетеді
        for (Module m : AlihClient.MODULES) {
            if (m == this) continue;
            float a = anim.getOrDefault(m, 0f);
            float target = m.enabled ? 1f : 0f;
            a += (target - a) * 0.18f;
            if (Math.abs(target - a) < 0.01f) a = target;
            if (a <= 0f) anim.remove(m); else anim.put(m, a);
        }
        List<Module> rows = new ArrayList<>(anim.keySet());
        rows.sort((m1, m2) -> tr.getWidth(m2.name) - tr.getWidth(m1.name));

        int sw = mc.getWindow().getScaledWidth();
        int y = 3;
        int idx = 0;
        for (Module m : rows) {
            float a = anim.get(m);
            int w = tr.getWidth(m.name) + 8;
            int x = sw - 2 - w + (int) ((1f - a) * (w + 6));
            int alpha = (int) (255 * a);
            int col = HudUtil.hsv(time + idx * 0.05, 0.55, 1.0);
            ctx.fill(x, y, x + w, y + 11, HudUtil.withAlpha(0x000000, (int) (140 * a)));
            ctx.fill(x + w - 2, y, x + w, y + 11, HudUtil.withAlpha(col, alpha));
            ctx.drawText(tr, m.name, x + 3, y + 2, HudUtil.withAlpha(col, alpha), true);
            y += (int) (11 * Math.min(1f, a * 1.5f));
            idx++;
        }
    }
}
