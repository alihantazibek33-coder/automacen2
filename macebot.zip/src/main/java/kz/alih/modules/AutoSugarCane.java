package kz.alih.modules;

import kz.alih.Mine;
import kz.alih.Module;
import kz.alih.Nav;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/**
 * АвтоТростник: жақын жердегі қант қамысын жинайды, бірақ тек 3 блокқа өскенін:
 * ең астыңғы блокты қалдырады (қайта өсуі үшін), үстіндегі 2 блокты алады.
 * Екінші блокты сындырса, үшіншісі өздігінен түсіп кетеді.
 */
public class AutoSugarCane extends Module {
    public static AutoSugarCane INSTANCE;

    private final Setting radius = num("Радиус (блок)", 16, 6, 48, 2);
    private final Setting pickup = bool("Заттарды жинау", true);

    private final Nav nav = new Nav();
    private final Set<Long> bad = new HashSet<>();
    private BlockPos target;                       // сындырылатын блок: ең астыңғының үсті (2-ші)
    private int ticks, scanCd, walkT, mineT, collectT, collectWalk, idleMsg;
    private double bestDist;

    public AutoSugarCane() {
        super("autocane", "АвтоТростник", "3 биік қамыстың үстіңгі 2 блогын жинап, астыңғысын қалдырады");
        INSTANCE = this;
    }

    private void clear() {
        target = null;
        bad.clear();
        ticks = scanCd = walkT = mineT = collectT = collectWalk = idleMsg = 0;
        bestDist = Double.MAX_VALUE;
    }

    @Override
    protected void onEnable() {
        clear();
        nav.reset();
        Util.msg("АвтоТростник: бастады (тек 3 биік қамыс, астыңғы блок қалады)");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
        }
        nav.reset();
    }

    @Override
    public void reset() {
        if (enabled) clear();
    }

    private static boolean cane(MinecraftClient mc, BlockPos b) {
        return mc.world.getBlockState(b).isOf(Blocks.SUGAR_CANE);
    }

    /** b — қамыстың 2-ші блогы ма: астында тек 1 қамыс (түбі), үстінде тағы қамыс бар. */
    private static boolean ripe(MinecraftClient mc, BlockPos second) {
        return cane(mc, second) && cane(mc, second.down()) && !cane(mc, second.down(2)) && cane(mc, second.up());
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        mc.options.attackKey.setPressed(false);
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        if (mc.currentScreen != null) return;

        nav.dig = false;                 // жолды қазбайды (ферманы бұзбау үшін)
        nav.avoid = true;
        nav.avoidWater = true;
        if (nav.guard(mc, p, false)) return;

        if (collectT > 0 && pickup.on() && collect(mc, p)) return;

        if (target != null && !ripe(mc, target)) {      // жиналып қойған / өзгерген
            if (!cane(mc, target)) collectT = 60;       // бұзылды → түскен заттарды жинайды
            target = null;
        }
        if (target == null) {
            if (--scanCd > 0) return;
            scanCd = 20;
            target = findTarget(mc, p);
            walkT = mineT = 0;
            bestDist = Double.MAX_VALUE;
            if (target == null) {
                if (++idleMsg % 30 == 1) Util.msg("АвтоТростник: 3 биік қамыс жоқ, өсуін күтеді");
                return;
            }
            idleMsg = 0;
        }

        Vec3d center = Vec3d.ofCenter(target);
        double dist = p.getEyePos().distanceTo(center);
        if (dist <= 3.8) {
            mineTarget(mc, p);
        } else {
            nav.walk(mc, p, center.x, center.z);
            if (dist < bestDist - 0.4) { bestDist = dist; walkT = 0; }
            if (++walkT > 100) { bad.add(target.asLong()); target = null; }   // жете алмады → келесіге
        }
    }

    private void mineTarget(MinecraftClient mc, ClientPlayerEntity p) {
        // нысаналау нүктесі: ортасы, сосын қыр-жақтары (араға басқа қамыс түссе)
        double[][] o = { {0, 0, 0}, {0, 0.3, 0}, {0, -0.3, 0}, {0.35, 0, 0}, {-0.35, 0, 0}, {0, 0, 0.35}, {0, 0, -0.35} };
        double[] d = o[(mineT / 6) % o.length];
        Vec3d aim = Vec3d.ofCenter(target).add(d[0], d[1], d[2]);
        Util.aimAt(p, aim);

        HitResult hr = p.raycast(4.8, 1.0f, false);
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK && bhr.getBlockPos().equals(target)) {
            // ТЕК сол блокты ұрады: түбін (астыңғысын) ешқашан сындырмайды
            mc.options.attackKey.setPressed(true);
        }
        if (++mineT > 80) { bad.add(target.asLong()); target = null; }
    }

    private BlockPos findTarget(MinecraftClient mc, ClientPlayerEntity p) {
        int r = (int) radius.num();
        BlockPos c = p.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -4; dy <= 5; dy++) {
                    m.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (!cane(mc, m)) continue;
                    BlockPos second = m.toImmutable();
                    if (bad.contains(second.asLong()) || !ripe(mc, second)) continue;
                    double dd = second.getSquaredDistance(c);
                    if (dd < bd) { bd = dd; best = second; }
                }
            }
        }
        return best;
    }

    /** Түскен қамыс заттарын жинайды. */
    private boolean collect(MinecraftClient mc, ClientPlayerEntity p) {
        collectT--;
        ItemEntity best = null;
        double bd = 100;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie) || !ie.isAlive() || !ie.getStack().isOf(Items.SUGAR_CANE)) continue;
            double d = ie.squaredDistanceTo(p);
            if (d < bd) { bd = d; best = ie; }
        }
        if (best == null || bd < 1.2) { collectT = Math.max(0, collectT - 5); collectWalk = 0; return false; }
        if (++collectWalk > 120) { collectT = 0; collectWalk = 0; return false; }    // жете алмады
        nav.walk(mc, p, best.getX(), best.getZ());
        return true;
    }
}
