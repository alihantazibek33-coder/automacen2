package kz.alih.modules;

import kz.alih.Mine;
import kz.alih.Module;
import kz.alih.Nav;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/**
 * Бур: қарап тұрған бағытыңа түзу тоннель қазады (3×3, 8×8 немесе 10×10).
 * Биіктігі қолың жететін 6 блокпен шектелген (8×8 және 10×10 үшін), ені толық.
 * Лава, су, спавнер, астында бос орын немесе инвентарь толса өзі тоқтайды.
 */
public class Drill extends Module {
    public static Drill INSTANCE;

    private final Setting size = mode("Өлшем", 0, "3×3", "8×8", "10×10");
    private final Setting length = num("Ұзындық (блок)", 64, 8, 512, 8);

    private final Nav nav = new Nav();
    private final Set<Long> skip = new HashSet<>();

    private BlockPos origin;
    private Direction dir, right;
    private int width, height, rMin, rMax;
    private BlockPos lastBest;
    private int mineT, ticks;

    public Drill() {
        super("drill", "Бур", "Түзу тоннель қазады: 3×3, 8×8, 10×10 (лава/су/спавнер алдында тоқтайды)");
        INSTANCE = this;
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) { setEnabled(false); return; }
        width = switch (size.mode()) { case 1 -> 8; case 2 -> 10; default -> 3; };
        height = Math.min(width, 6);                 // қол жететін биіктік
        rMin = -((width - 1) / 2);
        rMax = width / 2;
        dir = p.getHorizontalFacing();
        right = dir.rotateYClockwise();
        origin = p.getBlockPos();
        skip.clear();
        lastBest = null;
        mineT = ticks = 0;
        nav.reset();
        Util.msg("Бур: " + width + "×" + height + ", ұзындығы " + (int) length.num() + " блок, бағыты " + dir.asString());
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
        }
        nav.reset();
    }

    @Override
    public void reset() {
        if (enabled) setEnabled(false);
    }

    private void stop(String why) {
        Util.msg("Бур тоқтады: " + why);
        setEnabled(false);
    }

    private boolean inVolume(BlockPos b) {
        int rx = b.getX() - origin.getX(), rz = b.getZ() - origin.getZ();
        int k = rx * dir.getOffsetX() + rz * dir.getOffsetZ();
        int r = rx * right.getOffsetX() + rz * right.getOffsetZ();
        int h = b.getY() - origin.getY();
        return k >= 0 && k < (int) length.num() && r >= rMin && r <= rMax && h >= 0 && h < height;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        mc.options.attackKey.setPressed(false);
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        if (mc.currentScreen != null) return;

        nav.dig = false;
        nav.avoid = true;
        nav.avoidWater = true;
        if (nav.guard(mc, p, false)) return;

        int free = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isEmpty()) free++;
        if (free < 1) { stop("инвентарь толды"); return; }

        int len = (int) length.num();
        double s = (p.getX() - (origin.getX() + 0.5)) * dir.getOffsetX() + (p.getZ() - (origin.getZ() + 0.5)) * dir.getOffsetZ();
        int kp = Math.max(0, (int) Math.floor(s + 0.5));
        if (kp >= len) { stop("ұзындыққа жетті"); return; }

        // келесі қазылатын блок: алдымен ең жақын қабат (k), сосын төменгі қатар (h), сосын ойыншыға жақыны
        BlockPos best = null;
        long bestKey = Long.MAX_VALUE;
        for (int k = kp; k <= kp + 3 && k < len; k++) {
            for (int r = rMin; r <= rMax; r++) {
                for (int h = 0; h < height; h++) {
                    BlockPos b = origin.offset(dir, k).offset(right, r).up(h);
                    if (skip.contains(b.asLong())) continue;
                    if (Mine.lava(mc, b) || Mine.water(mc, b)) { stop("лава немесе су табылды"); return; }
                    if (Mine.passable(mc, b)) continue;
                    if (Mine.unbreakable(mc, b)) { skip.add(b.asLong()); continue; }
                    if (Mine.unsafe(mc, b, true, false, 14)) { stop("қауіпті жер (лава/су/спавнер жақын)"); return; }
                    double lat = Math.abs((b.getX() + 0.5 - p.getX()) * right.getOffsetX() + (b.getZ() + 0.5 - p.getZ()) * right.getOffsetZ());
                    long key = k * 1_000_000L + h * 10_000L + (long) (lat * 100);
                    if (key < bestKey) { bestKey = key; best = b; }
                }
            }
        }

        if (best == null) {
            // алдағы қабаттар таза → 2 блок алға жүреді; алдымен астында тірек бар ма тексереді
            BlockPos floor = origin.offset(dir, Math.min(len - 1, kp + 2)).down();
            if (Mine.passable(mc, floor) || Mine.lava(mc, floor) || Mine.water(mc, floor)) { stop("алдында еден жоқ (бос орын/лава/су)"); return; }
            Vec3d c = Vec3d.ofCenter(origin.offset(dir, Math.min(len - 1, kp + 2)));
            nav.walk(mc, p, c.x, c.z);
            return;
        }

        Vec3d center = Vec3d.ofCenter(best);
        if (p.getEyePos().distanceTo(center) > 4.3) {
            nav.walk(mc, p, center.x, center.z);          // қолы жетпесе, жақындайды
            return;
        }

        if (!best.equals(lastBest)) { lastBest = best; mineT = 0; }
        Util.aimAt(p, center);
        HitResult hr = p.raycast(4.8, 1.0f, false);
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK && inVolume(bhr.getBlockPos())) {
            BlockState st = mc.world.getBlockState(bhr.getBlockPos());
            Mine.selectTool(mc, p, st);
            mc.options.attackKey.setPressed(true);                // тек тоннель көлемінің ішіндегі блокты ұрады
        } else {
            skip.add(best.asLong());                               // көлемнен тыс блок түсті — өткізеді
        }
        if (++mineT > 160) { skip.add(best.asLong()); mineT = 0; }
    }
}
