package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * XRay (жарқыл): таңдалған блоктарды (руда, сундук, обсидиан...) қабырға арқылы түсті жарқылмен көрсетеді (экранға салынады).
 * Блоктарды өзгертпейді, экранға 3D→2D жобалап сызады. Қосымша блок: .alih xray add <блок_id>.
 */
public class XRay extends Module {
    public static XRay INSTANCE;
    /** Қолмен қосылған блоктар (id path, мысалы diamond_block). */
    public static final Set<String> CUSTOM = new LinkedHashSet<>();

    private final Setting ores = bool("Руда (бәрі)", true);
    private final Setting storage = bool("Сақтау блоктары (сундук, бочка, шалкер)", true);
    private final Setting obsidian = bool("Обсидиан / якорь", true);
    private final Setting spawner = bool("Спавнер", true);
    private final Setting range = num("Қашықтық (блок)", 100, 20, 200, 20);
    private final Setting maxBoxes = num("Макс. контур саны", 150, 30, 400, 10);
    private final Setting light = bool("Жарық (night vision)", false);

    private Set<Block> targets = new HashSet<>();
    private final Map<Long, List<BlockPos>> cache = new HashMap<>();
    private final Map<Long, Integer> scannedAt = new HashMap<>();
    private final Map<Block, Integer> colors = new HashMap<>();
    private List<BlockPos> visible = new ArrayList<>();
    private List<Integer> visibleColors = new ArrayList<>();
    private String lastSig = "";
    private int ticks;
    private boolean lightAdded;

    public XRay() {
        super("xray", "XRay", "Таңдаған блоктарды қабырға арқылы жарқыратып көрсетеді (200 блокқа дейін)");
        INSTANCE = this;
    }

    public static boolean addCustom(String raw) {
        String id = raw.toLowerCase().replace("minecraft:", "").trim();
        if (!Registries.BLOCK.containsId(Identifier.ofVanilla(id))) return false;
        CUSTOM.add(id);
        return true;
    }

    private String signature() {
        return ores.on() + "|" + storage.on() + "|" + obsidian.on() + "|" + spawner.on() + "|" + CUSTOM;
    }

    private void rebuild() {
        Set<Block> out = new HashSet<>();
        colors.clear();
        for (Block b : Registries.BLOCK) {
            String id = Registries.BLOCK.getId(b).getPath();
            boolean take = false;
            int color = 0xFFFFFFFF;
            if (ores.on() && (id.endsWith("_ore") || id.equals("ancient_debris"))) {
                take = true;
                if (id.contains("diamond")) color = 0xFF3DE4FF;
                else if (id.contains("emerald")) color = 0xFF3DFF6B;
                else if (id.contains("gold")) color = 0xFFFFD83D;
                else if (id.contains("iron")) color = 0xFFE0B090;
                else if (id.contains("coal")) color = 0xFF9A9A9A;
                else if (id.contains("redstone")) color = 0xFFFF3B3B;
                else if (id.contains("lapis")) color = 0xFF3B6BFF;
                else if (id.contains("copper")) color = 0xFFFF9A4D;
                else if (id.contains("debris")) color = 0xFFB05A3A;
                else color = 0xFFFFFFFF;
            }
            if (storage.on() && (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel")
                    || id.equals("ender_chest") || id.endsWith("shulker_box"))) { take = true; color = 0xFFFFC857; }
            if (obsidian.on() && (id.equals("obsidian") || id.equals("crying_obsidian") || id.equals("respawn_anchor"))) {
                take = true; color = 0xFFB04DFF;
            }
            if (spawner.on() && (id.equals("spawner") || id.equals("trial_spawner"))) { take = true; color = 0xFFFF2D2D; }
            if (CUSTOM.contains(id)) { take = true; color = 0xFFFFFFFF; }
            if (take) { out.add(b); colors.put(b, color); }
        }
        targets = out;
        cache.clear();
        scannedAt.clear();
        lastSig = signature();
    }

    @Override
    protected void onEnable() { rebuild(); }

    @Override
    protected void onDisable() {
        cache.clear();
        scannedAt.clear();
        visible = new ArrayList<>();
        visibleColors = new ArrayList<>();
        MinecraftClient mc = Util.mc();
        if (mc.player != null && lightAdded) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        lightAdded = false;
    }

    @Override
    public void reset() {
        cache.clear();
        scannedAt.clear();
        visible = new ArrayList<>();
        visibleColors = new ArrayList<>();
    }

    // ================================================================ скан

    private void scanChunk(MinecraftClient mc, int cx, int cz) {
        long key = ChunkPos.toLong(cx, cz);
        scannedAt.put(key, ticks);
        Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (!(ch instanceof WorldChunk wc)) { cache.remove(key); return; }
        List<BlockPos> out = new ArrayList<>();
        ChunkSection[] secs = wc.getSectionArray();
        int bottom = wc.getBottomY();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || s.isEmpty()) continue;
            if (!s.hasAny(st -> targets.contains(st.getBlock()))) continue;
            int y0 = bottom + i * 16;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (targets.contains(s.getBlockState(x, y, z).getBlock())) {
                            out.add(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z));
                        }
                    }
                }
            }
        }
        cache.put(key, out);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (!signature().equals(lastSig)) rebuild();

        int r = (int) Math.ceil(range.num() / 16.0);
        int pcx = p.getBlockPos().getX() >> 4, pcz = p.getBlockPos().getZ() >> 4;

        // жақын чанктардан бастап, әр тикте ең көбі 8 чанк (қайта скан — 200 тикте бір)
        int budget = 8;
        for (int ring = 0; ring <= r && budget > 0; ring++) {
            for (int cx = pcx - ring; cx <= pcx + ring && budget > 0; cx++) {
                for (int cz = pcz - ring; cz <= pcz + ring && budget > 0; cz++) {
                    if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) != ring) continue;
                    Integer last = scannedAt.get(ChunkPos.toLong(cx, cz));
                    if (last == null || ticks - last > 200) {
                        scanChunk(mc, cx, cz);
                        budget--;
                    }
                }
            }
        }

        if (ticks % 10 == 0) refreshVisible(mc, p);

        if (light.on()) {
            boolean has = p.hasStatusEffect(StatusEffects.NIGHT_VISION);
            if (!has || (lightAdded && ticks % 100 == 1)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
                lightAdded = true;
            }
        }

        // алыстап кеткен чанктардың кэшін тазалау (ұзақ ұшқанда жад толмасын)
        if (ticks % 200 == 0) {
            final int keep = r + 2;
            cache.keySet().removeIf(k -> chunkFar(k, pcx, pcz, keep));
            scannedAt.keySet().removeIf(k -> chunkFar(k, pcx, pcz, keep));
        }
    }

    private static boolean chunkFar(long key, int pcx, int pcz, int keep) {
        int cx = (int) (key & 0xFFFFFFFFL), cz = (int) (key >>> 32);
        return Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > keep;
    }

    private record Cand(double d, BlockPos pos) {}

    private void refreshVisible(MinecraftClient mc, ClientPlayerEntity p) {
        double r2 = range.num() * range.num();
        Vec3d eye = p.getEyePos();
        int max = (int) maxBoxes.num();
        // ең жақын max блокты ғана алады (бүкіл тізімді сұрыптамай, heap арқылы)
        java.util.PriorityQueue<Cand> heap = new java.util.PriorityQueue<>((a, b) -> Double.compare(b.d(), a.d()));
        for (List<BlockPos> l : cache.values()) {
            for (BlockPos b : l) {
                double dx = b.getX() + 0.5 - eye.x, dy = b.getY() + 0.5 - eye.y, dz = b.getZ() + 0.5 - eye.z;
                double d = dx * dx + dy * dy + dz * dz;
                if (d > r2) continue;
                if (heap.size() < max) heap.add(new Cand(d, b));
                else if (d < heap.peek().d()) { heap.poll(); heap.add(new Cand(d, b)); }
            }
        }
        List<Cand> sorted = new ArrayList<>(heap);
        sorted.sort(java.util.Comparator.comparingDouble(Cand::d));
        List<BlockPos> vis = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        for (Cand c : sorted) {
            Block blk = mc.world.getBlockState(c.pos()).getBlock();      // әлі сол блок па (қазылып кетпеген бе)
            if (!targets.contains(blk)) continue;
            vis.add(c.pos());
            cols.add(colors.getOrDefault(blk, 0xFFFFFFFF));
        }
        visible = vis;
        visibleColors = cols;
    }

    // ================================================================ жарқыл (HUD): блоктың өз пішіні

    // кадр ішінде қолданылатын камера параметрлері
    private Vec3d cEye, cR, cU, cF;
    private int cW, cH;
    private double cTan, cAspect;
    private static int rowBudget;

    private static final int[][] FACES = {
            { 0, 2, 6, 4 },   // X0 (x = min)
            { 1, 3, 7, 5 },   // X1 (x = max)
            { 0, 1, 5, 4 },   // Y0 (төбе емес, асты)
            { 2, 3, 7, 6 },   // Y1 (төбесі)
            { 0, 1, 3, 2 },   // Z0
            { 4, 5, 7, 6 }    // Z1
    };
    private static final double[] SHADE = { 0.78, 0.78, 0.50, 1.00, 0.62, 0.62 };

    public static void renderHud(DrawContext ctx) {
        XRay x = INSTANCE;
        if (x == null || !x.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        x.draw(ctx, mc, mc.player);
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p) {
        List<BlockPos> list = visible;
        if (list.isEmpty()) return;

        cEye = p.getEyePos();
        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        double cy = Math.cos(yr), sy = Math.sin(yr), cp = Math.cos(pr), sp = Math.sin(pr);
        cF = new Vec3d(-sy * cp, -sp, cy * cp);
        cR = new Vec3d(-cy, 0, -sy);
        cU = cR.crossProduct(cF);
        cW = mc.getWindow().getScaledWidth();
        cH = mc.getWindow().getScaledHeight();
        cTan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        cAspect = (double) cW / cH;
        rowBudget = 3500;   // бір кадрда толтырылатын жол саны (әлсіз телефонда FPS түспесін)

        for (int n = 0; n < list.size() && rowBudget > 0; n++) {
            BlockPos b = list.get(n);
            int rgb = visibleColors.get(n) & 0xFFFFFF;

            double ex = cEye.x - b.getX(), ey = cEye.y - b.getY(), ez = cEye.z - b.getZ();
            int fx = ex < 0 ? 0 : (ex > 1 ? 1 : -1);
            int fy = ey < 0 ? 0 : (ey > 1 ? 1 : -1);
            int fz = ez < 0 ? 0 : (ez > 1 ? 1 : -1);
            if (fx < 0 && fy < 0 && fz < 0) continue;                       // камера блоктың ішінде

            double dx = b.getX() + 0.5 - cEye.x, dy = b.getY() + 0.5 - cEye.y, dz = b.getZ() + 0.5 - cEye.z;
            if (dx * cF.x + dy * cF.y + dz * cF.z < -2.0) continue;          // артымызда
            double d2 = dx * dx + dy * dy + dz * dz;

            // сыртқы жұмсақ жарқыл (жақын блоктарға ғана), содан кейін блоктың өзі
            if (d2 < 3600 && rowBudget > 1800) {
                cube(ctx, b, 0.20, 0x12, rgb, fx, fy, fz);
                cube(ctx, b, 0.10, 0x26, rgb, fx, fy, fz);
            }
            cube(ctx, b, 0.0, 0x90, rgb, fx, fy, fz);
        }
    }

    /** Блоктың көрінетін (камераға қараған) жақтарын әртүрлі реңкпен толтырады: 3D куб сияқты. */
    private void cube(DrawContext ctx, BlockPos b, double e, int alpha, int rgb, int fx, int fy, int fz) {
        double[][] c = new double[8][3];
        for (int i = 0; i < 8; i++) {
            double wx = b.getX() + ((i & 1) != 0 ? 1 + e : -e);
            double wy = b.getY() + ((i & 2) != 0 ? 1 + e : -e);
            double wz = b.getZ() + ((i & 4) != 0 ? 1 + e : -e);
            double dx = wx - cEye.x, dy = wy - cEye.y, dz = wz - cEye.z;
            c[i][0] = dx * cR.x + dy * cR.y + dz * cR.z;
            c[i][1] = dx * cU.x + dy * cU.y + dz * cU.z;
            c[i][2] = dx * cF.x + dy * cF.y + dz * cF.z;
        }
        if (fx == 0) face(ctx, c, 0, alpha, rgb);
        if (fx == 1) face(ctx, c, 1, alpha, rgb);
        if (fy == 0) face(ctx, c, 2, alpha, rgb);
        if (fy == 1) face(ctx, c, 3, alpha, rgb);
        if (fz == 0) face(ctx, c, 4, alpha, rgb);
        if (fz == 1) face(ctx, c, 5, alpha, rgb);
    }

    private void face(DrawContext ctx, double[][] c, int faceIdx, int alpha, int rgb) {
        if (rowBudget <= 0) return;
        final double near = 0.1;
        int[] idx = FACES[faceIdx];

        // камера жазықтығына (z = near) қию: Sutherland–Hodgman
        double[][] out = new double[6][];
        int n = 0;
        for (int k = 0; k < 4; k++) {
            double[] a = c[idx[k]], b = c[idx[(k + 1) % 4]];
            boolean ia = a[2] >= near, ib = b[2] >= near;
            if (ia) out[n++] = a;
            if (ia != ib) {
                double t = (near - a[2]) / (b[2] - a[2]);
                out[n++] = new double[] { a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, near };
            }
        }
        if (n < 3) return;

        double[] xs = new double[n], ys = new double[n];
        for (int k = 0; k < n; k++) {
            xs[k] = ((out[k][0] / out[k][2]) / (cTan * cAspect) * 0.5 + 0.5) * cW;
            ys[k] = (0.5 - (out[k][1] / out[k][2]) / cTan * 0.5) * cH;
        }

        double sh = SHADE[faceIdx];
        int r = (int) (((rgb >> 16) & 0xFF) * sh), g = (int) (((rgb >> 8) & 0xFF) * sh), bl = (int) ((rgb & 0xFF) * sh);
        fillPoly(ctx, xs, ys, n, (alpha << 24) | (r << 16) | (g << 8) | bl);
    }

    /** Дөңес көпбұрышты қатар-қатармен толтырады. Өте кішкентай (алыс) блок үшін нүкте салады. */
    private static void fillPoly(DrawContext ctx, double[] xs, double[] ys, int n, int color) {
        double minX = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            minX = Math.min(minX, xs[i]); maxX = Math.max(maxX, xs[i]);
            minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]);
        }
        if (maxX < 0 || minX > 4000 || maxY < 0 || minY > 4000) return;

        if (maxY - minY < 2.0 && maxX - minX < 2.0) {
            int cx = (int) ((minX + maxX) / 2), cy = (int) ((minY + maxY) / 2);
            ctx.fill(cx - 1, cy - 1, cx + 2, cy + 2, color);
            rowBudget -= 3;
            return;
        }
        int w = MinecraftClient.getInstance().getWindow().getScaledWidth();
        int h = MinecraftClient.getInstance().getWindow().getScaledHeight();
        int y0 = Math.max(0, (int) Math.floor(minY)), y1 = Math.min(h - 1, (int) Math.ceil(maxY));
        for (int y = y0; y <= y1 && rowBudget > 0; y++) {
            double yc = y + 0.5, lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double ya = ys[i], yb = ys[j];
                if ((yc < Math.min(ya, yb)) || (yc > Math.max(ya, yb)) || ya == yb) continue;
                double x = xs[i] + (yc - ya) / (yb - ya) * (xs[j] - xs[i]);
                if (x < lo) lo = x;
                if (x > hi) hi = x;
            }
            if (lo > hi) continue;
            int xa = Math.max(0, (int) Math.floor(lo)), xb = Math.min(w, (int) Math.ceil(hi));
            if (xb > xa) ctx.fill(xa, y, xb, y + 1, color);
            rowBudget--;
        }
    }
}
