package kz.alih.modules;

import kz.alih.Mine;
import kz.alih.MineRegion;
import kz.alih.Module;
import kz.alih.Nav;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоМайн: алдындағы блокты өзі қазып, тоннель салып жүреді. Ең дұрыс құралды өзі таңдайды.
 * "Тек руда" режимінде жақындағы рудаға бұрылып, соны қазады. Лава көрінсе тоқтайды.
 */
public class AutoMine extends Module {
    private final Setting mode = mode("Режим", 0, "Алға (тоннель)", "Жақын руда + тоннель");
    private final Setting walk = bool("Алға жүру", true);
    private final Setting tool = bool("Құралды өзі таңдау", true);
    private final Setting oreRadius = num("Руда іздеу радиусы", 5, 2, 8, 1);

    public AutoMine() {
        super("automine", "АвтоМайн", "Алдыңдағы блокты өзі қазып, тоннель салып жүреді (руда режимі бар)");
    }

    // ================================================================ аймақ режимі (.alih minepos 1 / 2)

    private final Nav nav = new Nav();
    private final java.util.Set<BlockPos> frontier = new java.util.HashSet<>();
    private final java.util.Set<Long> ignored = new java.util.HashSet<>();
    private BlockPos rtarget;
    private int scanY, scanIdx, walkT, mineT, collectT, rticks;
    private boolean scanDone, unloadedWarned, regionMode;

    @Override
    protected void onEnable() {
        regionMode = MineRegion.complete();
        if (!regionMode) return;
        long vol = MineRegion.volume();
        if (vol > 3_000_000L) {
            Util.msg("Аймақ тым үлкен (" + vol + " блок). Кішірек қой");
            setEnabled(false);
            return;
        }
        frontier.clear();
        ignored.clear();
        rtarget = null;
        scanY = MineRegion.maxY();
        scanIdx = 0;
        scanDone = false;
        unloadedWarned = false;
        walkT = mineT = collectT = rticks = 0;
        nav.reset();
        Util.msg("АвтоМайн: аймақты қазады (" + vol + " блок). Жете алмайтын блокты өткізіп жібереді");
    }

    private static boolean isMineBlock(MinecraftClient mc, BlockPos b) {
        net.minecraft.block.BlockState st = mc.world.getBlockState(b);
        if (st.isAir() || !st.getFluidState().isEmpty()) return false;
        return st.getHardness(mc.world, b) >= 0;
    }

    private static boolean exposed(MinecraftClient mc, BlockPos b) {
        for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values()) {
            BlockPos n = b.offset(d);
            if (!mc.world.getBlockState(n).isSolidBlock(mc.world, n)) return true;
        }
        return false;
    }

    /** Бастапқы аймақты қабат-қабатпен сканерлейді: ашық (ауамен шектесетін) блоктарды frontier-ге қосады. */
    private void scanStep(MinecraftClient mc) {
        if (scanDone) return;
        int w = MineRegion.maxX() - MineRegion.minX() + 1, d = MineRegion.maxZ() - MineRegion.minZ() + 1;
        int budget = 6000;
        while (budget-- > 0) {
            if (scanIdx >= w * d) {
                scanIdx = 0;
                if (--scanY < MineRegion.minY()) { scanDone = true; return; }
                continue;
            }
            int x = MineRegion.minX() + scanIdx % w, z = MineRegion.minZ() + scanIdx / w;
            scanIdx++;
            if (!mc.world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) {
                if (!unloadedWarned) { unloadedWarned = true; Util.msg("Аймақтың бір бөлігі жүктелмеген (алыс). Жақындағанда қазылады"); }
                continue;
            }
            BlockPos b = new BlockPos(x, scanY, z);
            if (isMineBlock(mc, b) && exposed(mc, b)) frontier.add(b);
        }
    }

    private void regionTick(MinecraftClient mc, ClientPlayerEntity p) {
        rticks++;
        mc.options.attackKey.setPressed(false);
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);

        nav.dig = false;
        nav.avoid = true;
        nav.avoidWater = true;
        nav.avoidFalling = false;
        nav.fightMobs = true;
        nav.fallGuard = true;
        nav.fallMin = 8;
        Mine.refreshSpawners(mc, p);

        if (nav.guard(mc, p, false)) return;
        if (nav.fightMobs(mc, p)) return;
        scanStep(mc);

        // жерге түскен заттарды жинау
        if (collectT > 0) {
            collectT--;
            net.minecraft.entity.ItemEntity best = null;
            double bd = 49;
            for (net.minecraft.entity.Entity e : mc.world.getEntities()) {
                if (!(e instanceof net.minecraft.entity.ItemEntity ie) || !ie.isAlive()) continue;
                double dd = ie.squaredDistanceTo(p);
                if (dd < bd && MineRegion.contains(ie.getBlockPos().add(0, 0, 0)) || dd < 4) {
                    if (dd < bd) { bd = dd; best = ie; }
                }
            }
            if (best != null && bd > 1.0) {
                nav.walk(mc, p, best.getX(), best.getZ());
                return;
            }
        }

        // мақсатты тексеру
        if (rtarget != null) {
            if (!isMineBlock(mc, rtarget) || ignored.contains(rtarget.asLong())) finishTarget(mc);
        }
        // мақсат таңдау
        if (rtarget == null) {
            double bs = Double.MAX_VALUE;
            BlockPos best = null;
            Vec3d eye = p.getEyePos();
            for (BlockPos b : frontier) {
                if (ignored.contains(b.asLong())) continue;
                double s = Vec3d.ofCenter(b).squaredDistanceTo(eye) + (MineRegion.maxY() - b.getY()) * 3.0;
                if (s < bs) { bs = s; best = b; }
            }
            if (best == null) {
                if (scanDone) {
                    Util.msg("АвтоМайн: аймақ тазаланды (жете алмағаны: " + ignored.size() + ")");
                    setEnabled(false);
                }
                return;
            }
            rtarget = best;
            walkT = 0;
            mineT = 0;
        }

        BlockPos t = rtarget;
        if (Mine.unsafe(mc, t, true, false, 0)) { ignored.add(t.asLong()); finishTarget(mc); return; }

        double dist = p.getEyePos().distanceTo(Vec3d.ofCenter(t));
        if (dist <= 4.2) {
            BlockPos hit = Mine.hold(mc, p, t);
            if (hit != null && !hit.equals(t)) {
                // жолда басқа блок тұр: аймақ ішінде болса оны қазады, әйтпесе жете алмайды
                if (!MineRegion.contains(hit) || Mine.unsafe(mc, hit, true, false, 0)) { ignored.add(t.asLong()); finishTarget(mc); return; }
            }
            if (++mineT > 260) { ignored.add(t.asLong()); finishTarget(mc); }
        } else {
            if (++walkT > 320) { ignored.add(t.asLong()); finishTarget(mc); return; }
            nav.walk(mc, p, t.getX() + 0.5, t.getZ() + 0.5);
        }
    }

    /** Мақсатты аяқтау: қазылған блокты тізімнен алып, көршілерін ашық деп қосады. */
    private void finishTarget(MinecraftClient mc) {
        BlockPos t = rtarget;
        rtarget = null;
        if (t == null) return;
        if (!isMineBlock(mc, t)) {
            frontier.remove(t);
            for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values()) {
                BlockPos n = t.offset(d);
                if (MineRegion.contains(n) && isMineBlock(mc, n)) frontier.add(n);
            }
            collectT = 25;
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.options != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
        }
        nav.reset();
    }

    private static boolean isOre(BlockState st) {
        String id = Registries.BLOCK.getId(st.getBlock()).getPath();
        return id.endsWith("_ore") || id.equals("ancient_debris");
    }

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }

    private boolean lava(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).getFluidState().isIn(FluidTags.LAVA);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (regionMode && MineRegion.complete()) {
            if (mc.currentScreen == null) regionTick(mc, p);
            return;
        }
        if (mc.currentScreen != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            return;
        }

        double rad = Math.toRadians(p.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        BlockPos feet = p.getBlockPos();
        BlockPos aheadFeet = BlockPos.ofFloored(p.getX() + fx * 1.0, p.getY(), p.getZ() + fz * 1.0);
        BlockPos aheadHead = aheadFeet.up();
        BlockPos aheadFeet2 = BlockPos.ofFloored(p.getX() + fx * 2.0, p.getY(), p.getZ() + fz * 2.0);

        // лава қауіпі: алда немесе астында лава болса тоқтайды
        if (lava(mc, aheadFeet) || lava(mc, aheadHead) || lava(mc, aheadFeet2) || lava(mc, aheadFeet2.up())
                || lava(mc, feet.down()) || lava(mc, aheadFeet.down())) {
            Util.msg("Лава көрінді. АвтоМайн тоқтатылды");
            setEnabled(false);
            return;
        }

        // бағыт: руда режимінде жақындағы рудаға, әйтпесе тоннель блогына
        Vec3d aim = null;
        if (mode.mode() == 1) {
            int r = (int) oreRadius.num();
            double bd = Double.MAX_VALUE;
            BlockPos best = null;
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        BlockPos pos = feet.add(dx, dy, dz);
                        if (!isOre(mc.world.getBlockState(pos))) continue;
                        double d = Vec3d.ofCenter(pos).squaredDistanceTo(p.getEyePos());
                        if (d < bd) { bd = d; best = pos; }
                    }
                }
            }
            if (best != null) aim = Vec3d.ofCenter(best);
        }
        if (aim == null) {
            if (solid(mc, aheadHead)) aim = Vec3d.ofCenter(aheadHead);
            else if (solid(mc, aheadFeet)) aim = Vec3d.ofCenter(aheadFeet);
        }

        if (aim != null) {
            Util.aimAt(p, aim);
            mc.options.forwardKey.setPressed(false);
            // құралды таңдау (қазылатын блокқа қарай ең жылдам)
            HitResult hr = mc.crosshairTarget;
            if (tool.on() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
                BlockState st = mc.world.getBlockState(bhr.getBlockPos());
                int best = Util.selected(p);
                float bm = p.getInventory().getStack(best).getMiningSpeedMultiplier(st);
                for (int i = 0; i < 9; i++) {
                    float m = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
                    if (m > bm) { bm = m; best = i; }
                }
                Util.select(p, best);
            }
            mc.options.attackKey.setPressed(hr != null && hr.getType() == HitResult.Type.BLOCK);
        } else {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(walk.on());
            // алдында 1 блок көтерілу керек болса секіреді
            mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
        }
    }
}
