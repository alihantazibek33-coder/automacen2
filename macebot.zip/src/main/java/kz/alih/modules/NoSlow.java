package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * NoSlow: зат қолданғанда (тамақ, қалқан, садақ, арбалет) жылдамдық баяуламайды.
 * Қозғалыс есептелгенде ойын "зат қолданып жатыр" дегенді көрмейді (LivingEntityMixin + ClientPlayerEntityMixin).
 */
public class NoSlow extends Module {
    public static NoSlow INSTANCE;
    /** Тек ClientPlayerEntity.tickMovement ішінде true. */
    public static boolean inMove;

    public NoSlow() {
        super("noslow", "NoSlow", "Тамақ жегенде, қалқан/садақ ұстағанда баяулама");
        INSTANCE = this;
    }

    public static boolean active() {
        NoSlow n = INSTANCE;
        return n != null && n.enabled;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
    }
}
