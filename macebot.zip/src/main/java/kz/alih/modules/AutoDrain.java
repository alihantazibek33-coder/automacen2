package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** АвтоДрейн: басқа игрок жанына қойған суды шелекпен қайта алып қояды. Өз суыңа тимейді (UHC). */
public class AutoDrain extends Module {
    private final Setting nearPlayer = num("Игрокқа дейін (блок)", 4.0, 2.0, 8.0, 0.5);
    private final Setting protect = num("Өз суыңды қорғау (блок)", 2.5, 1.0, 5.0, 0.5);

    private int cooldown, prevSlot = -1;

    public AutoDrain() {
        super("autodrain", "АвтоДрейн", "Қарсылас қойған суды шелекпен алып қояды (UHC)");
    }

    @Override
    public void reset() { cooldown = 0; prevSlot = -1; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (prevSlot >= 0) { Util.select(p, prevSlot); prevSlot = -1; return; }
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;
        if (!Util.hasInInventory(p, s -> s.isOf(Items.BUCKET))) return;

        Vec3d eye = p.getEyePos();
        BlockPos pb = p.getBlockPos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -5; dx <= 5; dx++) {
            for (int dy = -4; dy <= 3; dy++) {
                for (int dz = -5; dz <= 5; dz++) {
                    BlockPos pos = pb.add(dx, dy, dz);
                    FluidState fs = mc.world.getBlockState(pos).getFluidState();
                    if (fs.isEmpty() || !fs.isStill() || !fs.isIn(FluidTags.WATER)) continue;
                    Vec3d c = Vec3d.ofCenter(pos);
                    if (eye.distanceTo(c) > 4.5) continue;
                    if (Util.pos(p).distanceTo(c) < protect.num()) continue;       // өз суың
                    double dp = nearestOtherPlayer(mc, p, c);
                    if (dp > nearPlayer.num()) continue;
                    if (dp < bd) { bd = dp; best = pos; }
                }
            }
        }
        if (best == null) return;

        int slot = Util.grab(mc, p, s -> s.isOf(Items.BUCKET));
        if (slot < 0) return;
        int cur = Util.selected(p);
        Util.select(p, slot);
        Util.aimNow(p, Vec3d.ofCenter(best));
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        if (cur != slot) prevSlot = cur;
        cooldown = Util.jitter(6, 6);
    }

    private static double nearestOtherPlayer(MinecraftClient mc, ClientPlayerEntity p, Vec3d c) {
        double best = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Util.validPlayer(p, e)) continue;
            double d = Util.pos(e).distanceTo(c);
            if (d < best) best = d;
        }
        return best;
    }
}
