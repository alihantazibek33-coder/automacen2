package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Waypoints: координатты сақтап, экранда бағытын (атымен және қашықтығымен) көрсетеді.
 * Команда: .alih wp add <ат> [x y z] | .alih wp del <ат> | .alih wp list | .alih wp clear
 * Өлген орын (DeathMarker) да осы жүйеде сақталады.
 */
public class Waypoints extends Module {
    public static Waypoints INSTANCE;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("alihclient-waypoints.txt");

    private static final class Wp {
        String ctx, name;
        int x, y, z;
        boolean death;
    }

    private static final List<Wp> LIST = new ArrayList<>();
    private static boolean loaded;

    private final Setting maxDist = num("Көрсету қашықтығы (0 = шексіз)", 0, 0, 5000, 100);

    public Waypoints() {
        super("waypoints", "Waypoints", "Сақталған нүктелердің бағытын экранда көрсетеді (.alih wp add <ат>)");
        INSTANCE = this;
    }

    @Override
    public boolean defaultEnabled() { return true; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // сурет renderHud ішінде
    }

    // ================================================================ сақтау

    /** Сервер + өлшем: нүктелер әр әлемге жеке. */
    private static String ctx(MinecraftClient mc) {
        String server = mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "single";
        String dim = mc.world != null ? mc.world.getRegistryKey().getValue().toString() : "?";
        return server + "@" + dim;
    }

    private static void load() {
        if (loaded) return;
        loaded = true;
        try {
            if (!Files.exists(FILE)) return;
            for (String line : Files.readAllLines(FILE)) {
                String[] a = line.split(";");
                if (a.length < 6) continue;
                Wp w = new Wp();
                w.ctx = a[0];
                w.name = a[1];
                w.x = Integer.parseInt(a[2]);
                w.y = Integer.parseInt(a[3]);
                w.z = Integer.parseInt(a[4]);
                w.death = a[5].equals("1");
                LIST.add(w);
            }
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    private static void save() {
        List<String> lines = new ArrayList<>();
        for (Wp w : LIST) {
            lines.add(w.ctx + ";" + w.name + ";" + w.x + ";" + w.y + ";" + w.z + ";" + (w.death ? "1" : "0"));
        }
        try {
            Files.write(FILE, lines);
        } catch (IOException ignored) {
        }
    }

    public static void add(MinecraftClient mc, String name, BlockPos pos, boolean death) {
        load();
        String c = ctx(mc);
        name = name.replace(";", ",");
        if (death) LIST.removeIf(w -> w.death && w.ctx.equals(c));       // соңғы өлген орын ғана
        else LIST.removeIf(w -> !w.death && w.ctx.equals(c) && w.name.equalsIgnoreCase(name));
        Wp w = new Wp();
        w.ctx = c; w.name = name; w.x = pos.getX(); w.y = pos.getY(); w.z = pos.getZ(); w.death = death;
        LIST.add(w);
        save();
    }

    /** .alih wp ... командасы. a[0] = ".alih", a[1] = "wp". */
    public static void command(MinecraftClient mc, String[] a) {
        load();
        String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
        String c = ctx(mc);
        switch (sub) {
            case "add" -> {
                if (a.length < 4) { Util.msg(".alih wp add <ат> [x y z]"); return; }
                BlockPos pos = mc.player.getBlockPos();
                if (a.length >= 7) {
                    try {
                        pos = new BlockPos(Integer.parseInt(a[4]), Integer.parseInt(a[5]), Integer.parseInt(a[6]));
                    } catch (NumberFormatException e) {
                        Util.msg("Координат сан болуы керек");
                        return;
                    }
                }
                add(mc, a[3], pos, false);
                Util.msg("Waypoint қосылды: " + a[3] + " " + pos.getX() + " " + pos.getY() + " " + pos.getZ());
            }
            case "del" -> {
                if (a.length < 4) { Util.msg(".alih wp del <ат>"); return; }
                boolean removed = LIST.removeIf(w -> w.ctx.equals(c) && w.name.equalsIgnoreCase(a[3]));
                save();
                Util.msg(removed ? "Өшірілді: " + a[3] : "Мұндай нүкте жоқ: " + a[3]);
            }
            case "clear" -> {
                LIST.removeIf(w -> w.ctx.equals(c));
                save();
                Util.msg("Осы әлемдегі нүктелер өшірілді");
            }
            default -> {
                int n = 0;
                for (Wp w : LIST) {
                    if (!w.ctx.equals(c)) continue;
                    n++;
                    Util.msg((w.death ? "[өлген] " : "") + w.name + ": " + w.x + " " + w.y + " " + w.z);
                }
                if (n == 0) Util.msg("Нүкте жоқ. .alih wp add <ат>");
            }
        }
    }

    // ================================================================ экранға салу

    public static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        Waypoints wm = INSTANCE;
        DeathMarker dm = DeathMarker.INSTANCE;
        boolean showWp = wm != null && wm.enabled;
        boolean showDeath = dm != null && dm.enabled;
        if (!showWp && !showDeath) return;
        load();

        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        double cy = Math.cos(yr), sy = Math.sin(yr), cp = Math.cos(pr), sp = Math.sin(pr);
        Vec3d f = new Vec3d(-sy * cp, -sp, cy * cp);
        Vec3d r = new Vec3d(-cy, 0, -sy);
        Vec3d u = r.crossProduct(f);
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0), aspect = (double) w / h;
        double max = wm != null ? wm.maxDist.num() : 0;
        String c = ctx(mc);

        for (Wp wp : LIST) {
            if (!wp.ctx.equals(c)) continue;
            if (wp.death ? !showDeath : !showWp) continue;
            Vec3d pt = new Vec3d(wp.x + 0.5, wp.y + 0.5, wp.z + 0.5);
            double dist = pt.distanceTo(eye);
            if (max > 0 && dist > max) continue;

            double dx = pt.x - eye.x, dy = pt.y - eye.y, dz = pt.z - eye.z;
            double cz = dx * f.x + dy * f.y + dz * f.z;
            double cxr = dx * r.x + dy * r.y + dz * r.z;
            double cyu = dx * u.x + dy * u.y + dz * u.z;
            double sx, syy;
            boolean front = cz > 0.1;
            if (front) {
                sx = ((cxr / cz) / (tan * aspect) * 0.5 + 0.5) * w;
                syy = (0.5 - (cyu / cz) / tan * 0.5) * h;
            } else {
                // артымызда: бұрылу бағытына қарай экран шетіне қояды
                double len = Math.max(1e-6, Math.hypot(cxr, cyu));
                sx = w / 2.0 + cxr / len * w;
                syy = h / 2.0 - cyu / len * h;
            }
            boolean off = !front || sx < 6 || sx > w - 6 || syy < 12 || syy > h - 12;
            sx = Math.max(8, Math.min(w - 8, sx));
            syy = Math.max(14, Math.min(h - 14, syy));

            int col = wp.death ? 0xFFFF5C5C : 0xFFFFC857;
            int ix = (int) sx, iy = (int) syy;
            ctx.fill(ix - 3, iy - 3, ix + 4, iy + 4, 0xFF000000);
            ctx.fill(ix - 2, iy - 2, ix + 3, iy + 3, col);
            String label = wp.name + " " + (int) dist + "m" + (off ? " >" : "");
            int tw = mc.textRenderer.getWidth(label);
            int tx = Math.max(2, Math.min(w - tw - 2, ix - tw / 2));
            ctx.drawTextWithShadow(mc.textRenderer, label, tx, iy + 6, col);
        }
    }
}
