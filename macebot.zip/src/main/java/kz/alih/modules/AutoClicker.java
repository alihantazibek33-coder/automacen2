package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

/** AutoClicker: ЛКМ басып тұрсаң, прицелдегі нысананы автоматты түрде ұрады. */
public class AutoClicker extends Module {
    private final Setting mode = mode("Режим", 0, "Cooldown (1.9+)", "CPS (1.8)");
    private final Setting cps = num("CPS", 10, 1, 20, 1);
    private double acc;

    public AutoClicker() {
        super("autoclicker", "AutoClicker", "ЛКМ басып ұстағанда нысананы автоматты ұрады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) { acc = 0; return; }
        if (!(mc.crosshairTarget instanceof EntityHitResult ehr)) return;
        Entity e = ehr.getEntity();
        if (!e.isAlive() || Util.isIgnored(e)) return;

        if (mode.mode() == 0) {
            if (p.getAttackCooldownProgress(0.5f) >= 0.95f) hit(mc, p, e);
        } else {
            acc += cps.num() / 20.0;
            while (acc >= 1.0) {
                hit(mc, p, e);
                acc -= 1.0;
            }
        }
    }

    private static void hit(MinecraftClient mc, ClientPlayerEntity p, Entity e) {
        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
    }
}
