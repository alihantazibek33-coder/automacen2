package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;

/** DeathMarker: өлген жеріңді автоматты түрде сақтап, экранда қызыл белгімен көрсетеді (Waypoints жүйесімен). */
public class DeathMarker extends Module {
    public static DeathMarker INSTANCE;
    private boolean dead;

    public DeathMarker() {
        super("deathmarker", "DeathMarker", "Өлген жеріңді сақтап, экранда көрсетеді");
        INSTANCE = this;
    }

    @Override
    public boolean defaultEnabled() { return true; }

    @Override
    public void alwaysTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!enabled) return;
        boolean d = p.getHealth() <= 0 || !p.isAlive();
        if (d && !dead) {
            dead = true;
            BlockPos pos = p.getBlockPos();
            Waypoints.add(mc, "Өлген орын", pos, true);
            Util.msg("Өлген орын сақталды: " + pos.getX() + " " + pos.getY() + " " + pos.getZ());
        } else if (!d) {
            dead = false;
        }
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
    }
}
