package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Велосити: соққы тигенде кері ұшуды азайтады. */
public class Velocity extends Module {
    private final Setting horizontal = num("Горизонталь %", 20, 0, 100, 10);
    private final Setting vertical = num("Вертикаль %", 100, 0, 100, 10);

    public Velocity() {
        super("velocity", "Велосити", "Соққыдан кері ұшуды азайтады (anti-knockback)");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (p.hurtTime < 8) return;
        Vec3d v = p.getVelocity();
        double h = horizontal.num() / 100.0, vy = vertical.num() / 100.0;
        p.setVelocity(v.x * h, v.y * vy, v.z * h);
    }
}
