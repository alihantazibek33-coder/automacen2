package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;

/** АвтоБроня: бос броня слотына инвентарьдағы ең жақсы броняны өзі киеді. */
public class AutoArmor extends Module {
    private int cooldown;

    public AutoArmor() {
        super("autoarmor", "АвтоБроня", "Бос броня слотын инвентарьдағы ең жақсы броняға толтырады");
    }

    private static int rank(ItemStack s) {
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        if (id.startsWith("netherite_")) return 6;
        if (id.startsWith("diamond_")) return 5;
        if (id.startsWith("iron_")) return 4;
        if (id.startsWith("chainmail_")) return 3;
        if (id.startsWith("golden_")) return 2;
        if (id.startsWith("leather_")) return 1;
        return 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;

        EquipmentSlot[] slots = { EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
        for (EquipmentSlot slot : slots) {
            if (!p.getEquippedStack(slot).isEmpty()) continue;
            int best = -1, bestRank = 0;
            for (int i = 9; i < 36; i++) { // хотбардағы (мысалы, элитра ауыстыруға арналған) бронаға тимейді
                ItemStack s = p.getInventory().getStack(i);
                if (s.isEmpty() || p.getPreferredEquipmentSlot(s) != slot) continue;
                int r = rank(s);
                if (r > bestRank) { bestRank = r; best = i; }
            }
            if (best >= 0) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, best, 0, SlotActionType.QUICK_MOVE, p);
                cooldown = 5;
                return;
            }
        }
    }
}
