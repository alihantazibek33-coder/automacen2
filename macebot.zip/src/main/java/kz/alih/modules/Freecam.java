package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Freecam: камера денеден бөлініп, еркін ұшады; дене тұрған жерінде қалады (сервер қозғалысты көрмейді).
 * W/A/S/D — қозғалыс, Space — жоғары, Shift — төмен, Ctrl (sprint) — жылдам.
 * Қосулы кезде ұру мен салу өшірулі (сервер камерадан ұруды қабылдамайды).
 * Бұрылу ойыншының бұрышымен жүреді, сондықтан денең де сол жаққа бұрылады.
 */
public class Freecam extends Module {
    public static Freecam INSTANCE;

    private final Setting speed = num("Жылдамдық (блок/сек)", 12, 2, 60, 2);

    private ArmorStandEntity cam;
    private double cx, cy, cz;       // камераның көз позициясы
    private long lastNanos;

    public Freecam() {
        super("freecam", "Freecam", "Камера денеден бөлінеді: еркін ұшып қарайсың, дене орнында тұрады");
        INSTANCE = this;
    }

    @Override
    public boolean persistEnabled() { return false; }

    /** Мixin сұрайды: true болса, ойыншы денесі қозғалмайды. */
    public static boolean active() {
        Freecam f = INSTANCE;
        return f != null && f.enabled && f.cam != null;
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        if (mc.player == null || mc.world == null) { setEnabled(false); return; }
        Vec3d eye = mc.player.getEyePos();
        cx = eye.x; cy = eye.y; cz = eye.z;
        cam = new ArmorStandEntity(mc.world, cx, cy, cz);
        cam.setInvisible(true);
        cam.setNoGravity(true);
        place(mc.player.getYaw(), mc.player.getPitch());
        mc.setCameraEntity(cam);
        lastNanos = System.nanoTime();
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.player != null) mc.setCameraEntity(mc.player);
        cam = null;
    }

    @Override
    public void reset() {
        if (enabled) setEnabled(false);
    }

    /** Камера энтитисін логикалық көз позициясына қояды (көз биіктігін есептеп). */
    private void place(float yaw, float pitch) {
        double eyeH = cam.getEyeY() - cam.getY();
        cam.refreshPositionAndAngles(cx, cy - eyeH, cz, yaw, pitch);
    }

    /** Кадр сайын (HUD callback) және тик сайын шақырылады: тегіс қозғалыс. */
    public static void frame() {
        Freecam f = INSTANCE;
        if (f != null && f.enabled && f.cam != null) f.update();
    }

    private void update() {
        MinecraftClient mc = Util.mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) {
            lastNanos = System.nanoTime();
            if (p != null) place(p.getYaw(), p.getPitch());
            return;
        }
        long now = System.nanoTime();
        double dt = Math.min(0.1, (now - lastNanos) / 1_000_000_000.0);
        lastNanos = now;

        Vec3d look = p.getRotationVec(1.0f);
        double yr = Math.toRadians(p.getYaw());
        Vec3d right = new Vec3d(-Math.cos(yr), 0, -Math.sin(yr));

        double fwd = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        double str = (mc.options.rightKey.isPressed() ? 1 : 0) - (mc.options.leftKey.isPressed() ? 1 : 0);
        double up = (mc.options.jumpKey.isPressed() ? 1 : 0) - (mc.options.sneakKey.isPressed() ? 1 : 0);

        Vec3d move = look.multiply(fwd).add(right.multiply(str)).add(0, up, 0);
        if (move.lengthSquared() > 1e-6) {
            double sp = speed.num() * (mc.options.sprintKey.isPressed() ? 2.5 : 1.0);
            move = move.normalize().multiply(sp * dt);
            cx += move.x; cy += move.y; cz += move.z;
        }
        place(p.getYaw(), p.getPitch());
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // денемен ұру/салу өшірулі
        mc.options.attackKey.setPressed(false);
        mc.options.useKey.setPressed(false);
        update();
    }
}
