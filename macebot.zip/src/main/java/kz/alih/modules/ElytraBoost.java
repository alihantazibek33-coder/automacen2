package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** ElytraBoost: элитрамен ұшқанда W басып тұрсаң, фейерверксіз қарау бағытымен жылдамдайды. */
public class ElytraBoost extends Module {
    private final Setting accel = num("Үдеу", 0.06, 0.01, 0.3, 0.01);
    private final Setting max = num("Макс. жылдамдық (блок/тик)", 2.0, 0.5, 5.0, 0.25);
    private final Setting needW = bool("Тек W басқанда", true);

    public ElytraBoost() {
        super("elytraboost", "ElytraBoost", "Элитрамен ұшқанда фейерверксіз жылдамдатады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!p.isGliding()) return;
        if (needW.on() && !mc.options.forwardKey.isPressed()) return;
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d v = p.getVelocity().add(look.multiply(accel.num()));
        double m = max.num();
        if (v.lengthSquared() > m * m) v = v.normalize().multiply(m);
        p.setVelocity(v);
    }
}
