package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** АвтоКарт: лукпен жерге атсаң, жебе қонған жерге рельс пен TNT вагонетка қояды. */
public class AutoCart extends Module {
    private final Setting ignite = bool("Флинтпен өртеу", false);

    private static final class Task {
        final BlockPos rail;
        int stage, age;
        Task(BlockPos rail) { this.rail = rail; }
    }

    private final Map<Integer, Vec3d> last = new HashMap<>();
    private final Map<Integer, Integer> stable = new HashMap<>();
    private final Set<Integer> done = new HashSet<>();
    private final Deque<Task> tasks = new ArrayDeque<>();

    public AutoCart() {
        super("autocart", "АвтоКарт", "Жебе қонған жерге рельс пен TNT вагонетка қояды");
    }

    @Override
    public void reset() { onDisable(); }

    @Override
    protected void onDisable() {
        last.clear();
        stable.clear();
        done.clear();
        tasks.clear();
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        scanArrows(mc, p);
        Task t = tasks.peekFirst();
        if (t == null) return;
        t.age++;

        switch (t.stage) {
            case 0 -> {
                int rail = Util.findHotbar(p, s -> s.isIn(ItemTags.RAILS));
                if (rail < 0) { Util.msg("Хотбарда рельс жоқ"); tasks.pollFirst(); return; }
                Util.select(p, rail);
                BlockPos sup = t.rail.down();
                Util.aimAt(p, Vec3d.ofCenter(sup).add(0, 0.5, 0));
                Util.place(mc, p, sup, Direction.UP);
                t.stage = 1;
                t.age = 0;
            }
            case 1 -> {
                if (mc.world.getBlockState(t.rail).isIn(BlockTags.RAILS)) {
                    int cart = Util.findHotbar(p, s -> s.isOf(Items.TNT_MINECART));
                    if (cart < 0) { Util.msg("Хотбарда TNT вагонетка жоқ"); tasks.pollFirst(); return; }
                    Util.select(p, cart);
                    Vec3d c = Vec3d.ofCenter(t.rail);
                    Util.aimAt(p, c);
                    mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                            new BlockHitResult(c.add(0, 0.4, 0), Direction.UP, t.rail, false));
                    p.swingHand(Hand.MAIN_HAND);
                    t.stage = 2;
                    t.age = 0;
                } else if (t.age > 8) {
                    tasks.pollFirst();
                }
            }
            default -> {
                if (ignite.on() && t.age < 6) {
                    int flint = Util.findHotbar(p, s -> s.isOf(Items.FLINT_AND_STEEL));
                    Box box = new Box(t.rail).expand(0.6);
                    for (Entity e : mc.world.getEntities()) {
                        if (e.getType() == EntityType.TNT_MINECART && box.intersects(e.getBoundingBox()) && flint >= 0) {
                            Util.select(p, flint);
                            mc.interactionManager.interactEntity(p, e, Hand.MAIN_HAND);
                            tasks.pollFirst();
                            return;
                        }
                    }
                    return;
                }
                tasks.pollFirst();
            }
        }
    }

    private void scanArrows(MinecraftClient mc, ClientPlayerEntity p) {
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof PersistentProjectileEntity ar)) continue;
            Entity owner = ar.getOwner();
            if (owner == null || !owner.getUuid().equals(p.getUuid())) continue;
            int id = e.getId();
            if (done.contains(id)) continue;

            Vec3d pos = new Vec3d(e.getX(), e.getY(), e.getZ());
            Vec3d old = last.put(id, pos);
            if (old != null && old.squaredDistanceTo(pos) < 1.0E-6) {
                int n = stable.merge(id, 1, Integer::sum);
                if (n >= 2) {
                    done.add(id);
                    BlockPos spot = findSpot(mc, p, e.getBlockPos());
                    if (spot != null && !Util.ignoredNear(mc, Vec3d.ofCenter(spot), 9)) tasks.addLast(new Task(spot));
                }
            } else {
                stable.put(id, 0);
            }
        }
        if (done.size() > 200) { done.clear(); last.clear(); stable.clear(); }
    }

    /** Рельс қоюға болатын (үстінде бос, астында қатты блок) орынды табады. */
    private BlockPos findSpot(MinecraftClient mc, ClientPlayerEntity p, BlockPos bp) {
        BlockPos[] cand = { bp, bp.up(), bp.down() };
        for (BlockPos c : cand) {
            BlockPos sup = c.down();
            boolean free = mc.world.getBlockState(c).isAir() || mc.world.getBlockState(c).isReplaceable();
            if (free && mc.world.getBlockState(sup).isSolidBlock(mc.world, sup)
                    && p.getEyePos().distanceTo(Vec3d.ofCenter(c)) <= 4.5) {
                return c;
            }
        }
        return null;
    }
}
