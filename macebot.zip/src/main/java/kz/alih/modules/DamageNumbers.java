package kz.alih.modules;

import kz.alih.HudUtil;
import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Зақым сандары: энтити HP-ы азайса, үстінде қызыл сан ұшып шығады (емделсе — жасыл). */
public class DamageNumbers extends Module {
    public static DamageNumbers INSTANCE;

    private final Setting range = num("Қашықтық (блок)", 32, 8, 96, 8);
    private final Setting heals = bool("Емделуді көрсету", true);

    private static final class Num {
        Vec3d pos;
        String text;
        int rgb;
        long born;
        double dx;
    }

    private final Map<Integer, Float> last = new HashMap<>();
    private final List<Num> nums = new ArrayList<>();

    public DamageNumbers() {
        super("damagenumbers", "ЗақымСандары", "Соққыдан кейін нысана үстінде зақым саны ұшып шығады");
        INSTANCE = this;
    }

    @Override
    public void reset() { last.clear(); nums.clear(); }

    @Override
    protected void onDisable() { last.clear(); nums.clear(); }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        double r2 = range.num() * range.num();
        Set<Integer> present = new HashSet<>();
        long now = System.currentTimeMillis();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == p) continue;
            if (le.squaredDistanceTo(p) > r2) continue;
            present.add(le.getId());
            float hp = le.getHealth() + le.getAbsorptionAmount();
            Float old = last.put(le.getId(), hp);
            if (old == null) continue;
            float diff = old - hp;
            boolean dmg = diff >= 0.5f;
            boolean heal = heals.on() && diff <= -0.5f;
            if ((!dmg && !heal) || nums.size() > 40) continue;
            Num n = new Num();
            double jitter = ((le.getId() * 31 + now) % 100) / 100.0 - 0.5;
            n.pos = le.getPos().add(0, le.getHeight() + 0.25, 0);
            n.dx = jitter * 0.8;
            n.born = now;
            n.rgb = dmg ? 0xFF4040 : 0x50FF50;
            float v = Math.abs(diff);
            String s = (v >= 10 || v == Math.floor(v)) ? String.valueOf((int) v) : String.format(java.util.Locale.ROOT, "%.1f", v);
            n.text = (dmg ? "-" : "+") + s;
            nums.add(n);
        }
        last.keySet().retainAll(present);
        nums.removeIf(n -> now - n.born > 1300);
    }

    public static void render(DrawContext ctx) {
        DamageNumbers d = INSTANCE;
        if (d == null || !d.enabled || d.nums.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        d.draw(ctx, mc, mc.player);
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p) {
        HudUtil.Cam cam = HudUtil.cam(mc, p);
        long now = System.currentTimeMillis();
        for (Num n : nums) {
            double age = (now - n.born) / 1000.0;                // 0 .. 1.3 сек
            Vec3d at = n.pos.add(n.dx * age, age * 0.9, 0);
            double[] sp = cam.project(at);
            if (sp == null) continue;
            int alpha = (int) (255 * Math.min(1.0, (1.3 - age) / 0.5));
            String t = n.text;
            ctx.drawText(mc.textRenderer, t, (int) sp[0] - mc.textRenderer.getWidth(t) / 2, (int) sp[1],
                    HudUtil.withAlpha(n.rgb, Math.max(30, alpha)), true);
        }
    }
}
