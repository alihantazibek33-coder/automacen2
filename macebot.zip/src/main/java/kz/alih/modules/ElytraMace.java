package kz.alih.modules;

import kz.alih.Mine;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

/** АвтоЭлитраМейс: элитра + фейерверкпен көтеріліп, түсіп келе жатып броняға ауысып, мейспен ұрады. */
public class ElytraMace extends Module {
    /** Shift + ПКМ арқылы белгіленген нысана. */
    public static UUID lockedId;
    public static ElytraMace INSTANCE;

    private enum Phase { TAKEOFF, CLIMB, APPROACH, STRIKE, LAND }

    private static final double REACH = 3.0;
    private static final double PREP_DIST = 9.0;
    private static final double SEARCH_RADIUS = 96.0;
    private static final double WEMBU_HEIGHT = 5.0;

    private final Setting height = num("Биіктік", 20, 10, 100, 5);
    private final Setting wembu = bool("Wembu (нысана төбесінен +5)", false);
    private final Setting shield = bool("Щитті балтамен бұзу", true);
    private final Setting predict = bool("Нысананы болжау", true);
    private final Setting queue = bool("Келесі нысанаға өту", true);
    private final Setting keepHit = bool("Жерде ұра беру", true);
    private final Setting heal = bool("Автоматты тотем/гаппл", true);
    private final Setting healHp = num("HP шегі", 10, 2, 20, 1);

    private UUID targetId;

    /** Қазіргі нысана (НысанаКарточка үшін); өшіп тұрса null. */
    public static UUID currentTarget() {
        return INSTANCE != null && INSTANCE.enabled ? INSTANCE.targetId : null;
    }
    private Phase phase = Phase.TAKEOFF;
    private double startY;
    private int ticks, fireworkCd, phaseTicks, swapCd, hitCd, lostTicks, lastHitTick, eatTicks, healCd;
    private boolean afterAxe, hazard;
    private Vec3d prevT;
    private Vec3d tVel = Vec3d.ZERO;

    public ElytraMace() {
        INSTANCE = this;
        super("elytramace", "АвтоЭлитраМейс", "Элитра+фейерверкпен көтеріліп, түсіп броняға ауысып мейспен ұрады");
    }

    @Override
    public boolean persistEnabled() { return false; }

    private static boolean isElytra(ItemStack s) { return s.isOf(Items.ELYTRA); }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { setEnabled(false); return; }

        Entity best = null;
        if (lockedId != null) {
            best = Util.entityById(mc, lockedId);
            if (best == null || !best.isAlive()) {
                Util.msg("Белгіленген нысана жақын жерде жоқ (.alih clear — тазалау)");
                setEnabled(false);
                return;
            }
        } else {
            double bd = SEARCH_RADIUS;
            for (Entity o : mc.world.getEntities()) {
                if (!Util.validTarget(p, o, true)) continue;
                double d = o.distanceTo(p);
                if (d < bd) { bd = d; best = o; }
            }
            if (best == null) { Util.msg("Жақын жерде нысана (моб/игрок) жоқ"); setEnabled(false); return; }
        }

        boolean elytra = isElytra(p.getEquippedStack(EquipmentSlot.CHEST)) || Util.findHotbar(p, ElytraMace::isElytra) >= 0;
        if (!elytra) { Util.msg("Хотбарда элитра жоқ"); setEnabled(false); return; }
        if (Util.findHotbar(p, s -> s.isOf(Items.MACE)) < 0) { Util.msg("Хотбарда мейс жоқ"); setEnabled(false); return; }
        if (Util.findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET)) < 0) { Util.msg("Хотбарда фейерверк жоқ"); setEnabled(false); return; }

        targetId = best.getUuid();
        afterAxe = false;
        ticks = 0;
        fireworkCd = 0;
        swapCd = 0;
        hitCd = 0;
        eatTicks = 0;
        healCd = 0;
        lostTicks = 0;
        prevT = null;
        tVel = Vec3d.ZERO;
        setPhase(Phase.TAKEOFF);
        Util.msg("АвтоЭлитраМейс → нысана: " + best.getName().getString());
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        mc.options.jumpKey.setPressed(false);
        mc.options.forwardKey.setPressed(false);
        mc.options.useKey.setPressed(false);
        eatTicks = 0;
    }

    private void setPhase(Phase ph) {
        phase = ph;
        phaseTicks = 0;
        if (ph == Phase.STRIKE) lastHitTick = ticks;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        phaseTicks++;
        if (fireworkCd > 0) fireworkCd--;
        if (swapCd > 0) swapCd--;
        if (hitCd > 0) hitCd--;

        // HP азайса: тотем сол қолға, не алтын алма жейді (жерде тұрғанда немесе қонып жатқанда)
        if (heal.on() && mc.currentScreen == null) {
            healTotem(mc, p);
            boolean canEat = p.isOnGround() || phase == Phase.LAND;
            if (!canEat && eatTicks > 0) { eatTicks = 0; mc.options.useKey.setPressed(false); }
            if (canEat && healEat(mc, p)) {
                mc.options.forwardKey.setPressed(false);
                if (phase == Phase.LAND && !p.isOnGround()) land(mc, p);
                return;
            }
        }

        Entity e = Util.entityById(mc, targetId);
        if (e == null) {
            // нысана көрінбейді (алыс/жасырынды) → абайлап қонады, көрінгенде бірден жалғастырады
            if (phase != Phase.LAND) {
                setPhase(Phase.LAND);
                lostTicks = 0;
                Util.msg("Нысана жоғалды — абайлап қонады, көрінгенде жалғастырады");
            }
            lostTicks++;
            if (lostTicks > 1200 && queue.on() && switchTarget(mc, p)) { setPhase(Phase.TAKEOFF); return; }
            if (lostTicks > 6000) { Util.msg("Нысана ұзақ көрінбеді, өшірілді"); setEnabled(false); return; }
            land(mc, p);
            return;
        }
        if (!(e instanceof LivingEntity t) || !t.isAlive()) {
            if (e.getUuid().equals(lockedId)) lockedId = null;
            if (queue.on() && switchTarget(mc, p)) { setPhase(Phase.TAKEOFF); return; }
            Util.msg("Нысана өлді, басқа нысана жоқ — өшірілді");
            setEnabled(false);
            return;
        }
        if (phase == Phase.LAND) {
            Util.msg("Нысана қайта көрінді — шабуыл");
            setPhase(Phase.TAKEOFF);
        }
        track(t);

        switch (phase) {
            case TAKEOFF -> takeoff(mc, p);
            case CLIMB -> climb(mc, p, t);
            case APPROACH -> approach(mc, p, t);
            case STRIKE -> strike(mc, p, t);
            case LAND -> { }
        }
    }

    // ================================================================ нысана қозғалысы мен кезек

    private void track(LivingEntity t) {
        Vec3d c = t.getPos();
        if (prevT != null) {
            Vec3d d = c.subtract(prevT);
            if (d.lengthSquared() < 16) tVel = tVel.multiply(0.5).add(d.multiply(0.5));
        }
        prevT = c;
    }

    /** Нысананың қозғалысына қарай алдын-ала нысаналау нүктесі. */
    private Vec3d aimPoint(ClientPlayerEntity p, LivingEntity t) {
        Vec3d c = Util.center(t);
        if (!predict.on()) return c;
        double dist = p.getEyePos().distanceTo(c);
        double spd = Math.max(0.6, p.getVelocity().length());
        double lead = Math.min(8.0, dist / spd);
        double vy = t.isOnGround() ? 0 : tVel.y * 0.5;
        return c.add(tVel.x * lead, vy * lead, tVel.z * lead);
    }

    private boolean switchTarget(MinecraftClient mc, ClientPlayerEntity p) {
        Entity best = null;
        double bd = SEARCH_RADIUS;
        for (Entity o : mc.world.getEntities()) {
            if (o.getUuid().equals(targetId) || !Util.validTarget(p, o, true)) continue;
            double d = o.distanceTo(p);
            if (d < bd) { bd = d; best = o; }
        }
        if (best == null) return false;
        targetId = best.getUuid();
        prevT = null;
        tVel = Vec3d.ZERO;
        lostTicks = 0;
        afterAxe = false;
        Util.msg("Келесі нысана → " + best.getName().getString());
        return true;
    }

    // ================================================================ емдеу

    private static boolean isGapple(ItemStack s) {
        return s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.GOLDEN_APPLE);
    }

    /** HP аз болса, тотемді сол қолға салады. */
    private void healTotem(MinecraftClient mc, ClientPlayerEntity p) {
        if (healCd > 0) { healCd--; return; }
        if (p.getHealth() + p.getAbsorptionAmount() > healHp.num() + 4) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int screenSlot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, screenSlot, 40, SlotActionType.SWAP, p);
                healCd = 4;
                return;
            }
        }
    }

    /** HP шектен төмен болса, алтын алма жейді. true = әлі жеп жатыр. */
    private boolean healEat(MinecraftClient mc, ClientPlayerEntity p) {
        double eff = p.getHealth() + p.getAbsorptionAmount();
        if (eatTicks == 0 && (eff > healHp.num() || p.getAbsorptionAmount() >= 4)) return false;
        int slot = Util.grab(mc, p, ElytraMace::isGapple);
        if (slot < 0) { eatTicks = 0; return false; }
        Util.select(p, slot);
        mc.options.useKey.setPressed(true);
        eatTicks++;
        if (eatTicks > 50 || (eatTicks > 4 && !p.isUsingItem())) {
            eatTicks = 0;
            mc.options.useKey.setPressed(false);
        }
        return true;
    }

    // ================================================================ абайлап қону

    private int groundDist(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos b = p.getBlockPos();
        for (int i = 1; i <= 80; i++) {
            BlockPos q = b.down(i);
            if (Mine.lava(mc, q)) { hazard = true; return i; }
            if (!Mine.passable(mc, q)) { hazard = false; return i; }
        }
        hazard = true;       // төменде жер жоқ
        return 80;
    }

    private boolean obstacleAhead(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d dir = Vec3d.fromPolar(0f, p.getYaw());
        for (int i = 3; i <= 15; i += 3) {
            BlockPos q = BlockPos.ofFloored(p.getX() + dir.x * i, p.getY(), p.getZ() + dir.z * i);
            if (!Mine.passable(mc, q) || !Mine.passable(mc, q.up())) return true;
        }
        return false;
    }

    private void land(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.forwardKey.setPressed(false);
        if (p.isOnGround()) { mc.options.jumpKey.setPressed(false); return; }

        // броня киіп алған болса, элитраны қайта киеді
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) {
            int slot = Util.findHotbar(p, ElytraMace::isElytra);
            if (slot >= 0 && swapCd == 0) swapChest(mc, p, slot);
            mc.options.jumpKey.setPressed(false);
            return;
        }
        if (!p.isGliding()) {
            mc.options.jumpKey.setPressed(ticks % 2 == 0 && p.getVelocity().y < -0.05);   // ауада элитраны ашады
            return;
        }
        mc.options.jumpKey.setPressed(false);

        int gh = groundDist(mc, p);
        float pitch;
        if (gh > 30) pitch = 20f;
        else if (gh > 10) pitch = 5f;
        else if (gh > 3) pitch = -20f;
        else pitch = -35f;                          // жерге жақын — жылдамдықты сөндіреді
        Util.smoothPitch(p, pitch);

        // лава/бос жер төменде не қабырға алда болса — бұрылады
        if (hazard || obstacleAhead(mc, p)) Util.smoothYaw(p, p.getYaw() + 50f);
    }

    private void takeoff(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.forwardKey.setPressed(false);
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) {
            if (swapCd == 0) {
                int slot = Util.findHotbar(p, ElytraMace::isElytra);
                if (slot < 0) { Util.msg("Элитра табылмады, өшірілді"); setEnabled(false); return; }
                swapChest(mc, p, slot);
            }
            return;
        }
        if (p.isGliding()) {
            mc.options.jumpKey.setPressed(false);
            startY = p.getY();
            setPhase(Phase.CLIMB);
            return;
        }
        if (p.isOnGround()) {
            mc.options.jumpKey.setPressed(true);
        } else if (p.getVelocity().y < -0.05) {
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
        } else {
            mc.options.jumpKey.setPressed(false);
        }
    }

    private void climb(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!p.isGliding()) { setPhase(Phase.TAKEOFF); return; }
        Util.smoothPitch(p, -80f);

        double targetTop = t.getY() + t.getHeight();
        double goalY = wembu.on() ? targetTop + WEMBU_HEIGHT : Math.max(startY, targetTop) + height.num();

        int fw = Util.findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET));
        if (p.getY() >= goalY || fw < 0 || phaseTicks > 200) {
            setPhase(Phase.APPROACH);
            return;
        }
        if (fireworkCd == 0) {
            Util.select(p, fw);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            fireworkCd = 14;
        }
    }

    private void approach(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) { setPhase(Phase.TAKEOFF); return; }
        if (!p.isGliding()) {
            if (p.isOnGround()) { setPhase(Phase.TAKEOFF); return; }
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
        } else {
            mc.options.jumpKey.setPressed(false);
        }

        int mace = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        if (mace >= 0) Util.select(p, mace);

        boolean ready;
        if (wembu.on()) {
            Vec3d ap = aimPoint(p, t);
            Util.aimAt(p, ap.x, t.getY() + t.getHeight() + WEMBU_HEIGHT, ap.z);
            ready = Math.hypot(t.getX() - p.getX(), t.getZ() - p.getZ()) <= 3.5;
        } else {
            Util.aimAt(p, aimPoint(p, t));
            ready = Util.boxDist(p.getEyePos(), t.getBoundingBox()) <= PREP_DIST;
        }

        if (ready) {
            int chest = Util.findHotbar(p, s -> !isElytra(s) && p.getPreferredEquipmentSlot(s) == EquipmentSlot.CHEST);
            if (chest >= 0) swapChest(mc, p, chest);
            setPhase(Phase.STRIKE);
            strike(mc, p, t);                       // жетсе дәл сол тикте ұрады
        }
    }

    private void strike(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        mc.options.jumpKey.setPressed(false);
        Util.aimAt(p, aimPoint(p, t));
        double hd = Math.hypot(t.getX() - p.getX(), t.getZ() - p.getZ());
        mc.options.forwardKey.setPressed(hd > 1.2);

        int mace = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        int axe = Util.findHotbar(p, s -> s.isIn(ItemTags.AXES));
        double dist = Util.boxDist(p.getEyePos(), t.getBoundingBox());

        if (dist <= REACH + 0.2) {
            if (hitCd > 0) return;
            if (afterAxe) {
                if (mace >= 0) Util.select(p, mace);
                Util.attack(mc, p, t);
                afterAxe = false;
                afterHit();
                return;
            }
            if (shield.on() && t.isBlocking() && axe >= 0) {
                Util.select(p, axe);
                Util.attack(mc, p, t);
                afterAxe = true;
                hitCd = 1;
                return;
            }
            if (mace >= 0) Util.select(p, mace);
            Util.attack(mc, p, t);                  // кулдаун толуын күтпейді — мүмкін болса бірден ұрады
            afterHit();
            return;
        }
        if (p.isOnGround() && phaseTicks > 3 && (!keepHit.on() || dist > 5 || ticks - lastHitTick > 30)) {
            setPhase(Phase.TAKEOFF);                // қашып кетті — қайта көтеріліп ұрады
        } else if (dist > 40 || (phaseTicks > 200 && ticks - lastHitTick > 200)) {
            Util.msg("Нысанаға жете алмады, өшірілді");
            setEnabled(false);
        }
    }

    private void afterHit() {
        hitCd = 2;
        lastHitTick = ticks;
        if (!keepHit.on()) setPhase(Phase.TAKEOFF);
    }

    /** Кеудеше слотын (6) хотбар слотымен ауыстырады. */
    private void swapChest(MinecraftClient mc, ClientPlayerEntity p, int hotbarSlot) {
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, 6, hotbarSlot, SlotActionType.SWAP, p);
        swapCd = 3;
    }
}
