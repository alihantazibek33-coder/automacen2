package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/** СундукСтилер: сундукты ашқанда ішіндегінің бәрін өзі алады. */
public class ChestStealer extends Module {
    private final Setting delay = num("Кідіріс (тик)", 1, 0, 10, 1);
    private int wait;

    public ChestStealer() {
        super("cheststealer", "СундукСтилер", "Сундук ашылғанда ішіндегі заттарды автоматты алады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!(mc.currentScreen instanceof GenericContainerScreen gs)) { wait = 0; return; }
        if (wait > 0) { wait--; return; }
        GenericContainerScreenHandler h = gs.getScreenHandler();
        Inventory inv = h.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            if (!inv.getStack(i).isEmpty()) {
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                wait = (int) delay.num();
                return;
            }
        }
    }
}
