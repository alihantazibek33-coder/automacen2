package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Скаффолд: аяғыңның астына блок қойып отырады (көпір салу). Блокты инвентарьдан өзі алады. */
public class Scaffold extends Module {
    private int prevSlot = -1;

    public Scaffold() {
        super("scaffold", "Скаффолд", "Аяғыңның астына автоматты блок қойып, көпір салады");
    }

    @Override
    public void reset() { prevSlot = -1; }

    @Override
    protected void onDisable() { prevSlot = -1; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (prevSlot >= 0) {
            Util.select(p, prevSlot);
            prevSlot = -1;
        }
        if (mc.currentScreen != null || p.isSneaking()) return;

        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ());
        BlockState st = mc.world.getBlockState(below);
        if (!(st.isAir() || st.isReplaceable())) return;

        Direction[] dirs = { Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST };
        for (Direction d : dirs) {
            BlockPos n = below.offset(d);
            if (!mc.world.getBlockState(n).isSolidBlock(mc.world, n)) continue;
            int blk = Util.grab(mc, p, s -> Util.isBuildBlock(mc.world, s));
            if (blk < 0) return;
            int cur = Util.selected(p);
            if (cur != blk) prevSlot = cur;
            Util.select(p, blk);
            Util.place(mc, p, n, d.getOpposite());
            return;
        }
    }
}
