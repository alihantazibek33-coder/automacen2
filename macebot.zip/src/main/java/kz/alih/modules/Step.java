package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

/** Степ: блоктарға секірместен көтеріледі. */
public class Step extends Module {
    private final Setting height = num("Биіктік (блок)", 1.0, 1.0, 2.5, 0.5);

    public Step() {
        super("step", "Степ", "Блоктарға секірместен шығады");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
            if (a != null) a.setBaseValue(0.6);
        }
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        EntityAttributeInstance a = p.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(height.num());
    }
}
