package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** АвтоСпринт: алға жүргенде өзі жүгіреді. */
public class AutoSprint extends Module {
    private boolean ours;

    public AutoSprint() {
        super("autosprint", "АвтоСпринт", "Алға жүргенде автоматты жүгіреді");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null && ours) mc.options.sprintKey.setPressed(false);
        ours = false;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        boolean want = mc.options.forwardKey.isPressed() && !p.isSneaking();
        if (want) {
            mc.options.sprintKey.setPressed(true);
            ours = true;
        } else if (ours) {
            mc.options.sprintKey.setPressed(false);   // тек өзіміз басқанды ғана босатамыз
            ours = false;
        }
    }
}
