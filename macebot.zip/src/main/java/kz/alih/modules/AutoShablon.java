package kz.alih.modules;

import kz.alih.Builder;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоШаблон: қосып қойып, блок қойсаң — сол жерден бірден шағын құрылым (мұнара, қабырға, платформа,
 * пирамида, үй) салады. Жүріп салмайды, тек қолың жететін жерді қояды.
 */
public class AutoShablon extends Module {
    public static AutoShablon INSTANCE;

    private final Setting template = mode("Шаблон", 0, "Мұнара", "Қабырға", "Платформа", "Пирамида", "Үй");
    private final Setting size = num("Өлшем", 7, 3, 15, 1);
    private final Setting perTick = num("Блок/тик", 6, 1, 10, 1);

    private final Builder builder = new Builder();
    private int idle;

    public AutoShablon() {
        super("autoshablon", "АвтоШаблон", "Блок қойсаң, сол жерден шағын құрылым (мұнара/қабырға/үй...) бірден салады");
        INSTANCE = this;
        builder.walk = false;
        builder.breakBlocks = false;
    }

    @Override
    protected void onDisable() { builder.clear(); }

    @Override
    public void reset() { builder.clear(); }

    /** UseBlockCallback шақырады: пайдаланушы блок қойды. */
    public void trigger(Block block, BlockPos anchor, Direction facing) {
        if (!enabled || Util.placing || !builder.entries.isEmpty()) return;
        MinecraftClient mc = Util.mc();
        if (mc.player == null) return;

        int n = (int) size.num();
        int ax = anchor.getX(), ay = anchor.getY(), az = anchor.getZ();
        switch (template.mode()) {
            case 0 -> { // мұнара
                for (int y = 0; y < n; y++) builder.entries.add(new Builder.Entry(new BlockPos(ax, ay + y, az), block));
            }
            case 1 -> { // қабырға: қарап тұрған жағыңа қарай
                Direction side = facing.rotateYClockwise();
                int h = Math.max(3, n / 2);
                for (int i = -n / 2; i <= n / 2; i++) {
                    for (int y = 0; y < h; y++) {
                        builder.entries.add(new Builder.Entry(
                                new BlockPos(ax + side.getOffsetX() * i, ay + y, az + side.getOffsetZ() * i), block));
                    }
                }
            }
            case 2 -> { // платформа
                for (int x = -n / 2; x <= n / 2; x++)
                    for (int z = -n / 2; z <= n / 2; z++)
                        builder.entries.add(new Builder.Entry(new BlockPos(ax + x, ay, az + z), block));
            }
            case 3 -> { // пирамида
                int half = n / 2;
                for (int l = 0; l <= half; l++) {
                    int r = half - l;
                    for (int x = -r; x <= r; x++)
                        for (int z = -r; z <= r; z++)
                            builder.entries.add(new Builder.Entry(new BlockPos(ax + x, ay + l, az + z), block));
                }
            }
            default -> { // үй: еден, қабырғалар (есік орны бар), төбе
                int half = Math.max(2, n / 2);
                for (int x = -half; x <= half; x++) {
                    for (int z = -half; z <= half; z++) {
                        builder.entries.add(new Builder.Entry(new BlockPos(ax + x, ay, az + z), block));
                        builder.entries.add(new Builder.Entry(new BlockPos(ax + x, ay + 4, az + z), block));
                        boolean wall = Math.abs(x) == half || Math.abs(z) == half;
                        if (!wall) continue;
                        for (int y = 1; y <= 3; y++) {
                            boolean door = x == 0 && z == half && y <= 2;
                            if (!door) builder.entries.add(new Builder.Entry(new BlockPos(ax + x, ay + y, az + z), block));
                        }
                    }
                }
            }
        }
        final Vec3d pp = Util.pos(mc.player);
        builder.entries.sort((a, b) -> {
            int c = Integer.compare(a.pos.getY(), b.pos.getY());
            if (c != 0) return c;
            return Double.compare(Vec3d.ofCenter(a.pos).squaredDistanceTo(pp), Vec3d.ofCenter(b.pos).squaredDistanceTo(pp));
        });
        idle = 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (builder.entries.isEmpty() || mc.currentScreen != null) return;
        builder.perTick = (int) perTick.num();
        boolean done = builder.tick(mc, p);
        if (done) return;
        if (builder.lastPlaced == 0) {
            if (++idle > 40) {            // қолға жетпейтін немесе блогы жоқ қалғандарын тастайды
                builder.clear();
                Util.msg("Шаблон: қалғанына қол жетпейді немесе блок жетпейді");
            }
        } else {
            idle = 0;
        }
    }
}
