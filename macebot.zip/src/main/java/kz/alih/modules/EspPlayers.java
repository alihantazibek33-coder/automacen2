package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/**
 * ESPPlayers: игроктарды қабырға арқылы көрсетеді.
 *  - Tracers: прицелден / экран астынан / экран төбесінен игрокқа сызық;
 *  - Skeleton: денесінің қаңқасы (примерно: позаға және бұрышқа қарай жуықтап салынады, нақты анимация емес);
 *  - Chams: қабырға арқылы игрок силуэті жарқырап көрінеді (glow).
 * Tracers пен Skeleton экранға (HUD) салынады, қозғалыс тиктер арасында тегістеледі.
 */
public class EspPlayers extends Module {
    public static EspPlayers INSTANCE;

    private final Setting tracers = bool("Tracers (сызық)", true);
    private final Setting origin = mode("Сызық басы", 0, "Прицел", "Экран асты", "Экран төбесі");
    private final Setting point = mode("Сызық нүктесі", 0, "Аяқ", "Дене", "Бас");
    private final Setting skeleton = bool("Skeleton", true);
    private final Setting chams = bool("Chams (қабырға арқылы)", true);
    private final Setting range = num("Қашықтық (блок)", 128, 32, 256, 32);

    private final Set<Integer> glowed = new HashSet<>();

    public EspPlayers() {
        super("espplayers", "ESPPlayers", "Игроктарды қабырға арқылы көрсетеді: сызық, қаңқа, силуэт");
        INSTANCE = this;
    }

    private static boolean valid(ClientPlayerEntity self, PlayerEntity e) {
        return e != self && e.isAlive() && !e.isSpectator() && !Util.isIgnored(e);
    }

    // ================================================================ Chams (glow)

    @Override
    public void reset() { glowed.clear(); }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            for (PlayerEntity e : mc.world.getPlayers()) {
                if (glowed.contains(e.getId())) e.setGlowing(false);
            }
        }
        glowed.clear();
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        double r2 = range.num() * range.num();
        Set<Integer> present = new HashSet<>();
        for (PlayerEntity e : mc.world.getPlayers()) {
            present.add(e.getId());
            boolean want = chams.on() && valid(p, e) && e.squaredDistanceTo(p) <= r2;
            if (want) {
                e.setGlowing(true);
                glowed.add(e.getId());
            } else if (glowed.remove(e.getId())) {
                e.setGlowing(false);
            }
        }
        glowed.retainAll(present);
    }

    // ================================================================ HUD: tracers + skeleton

    public static void renderHud(DrawContext ctx) {
        EspPlayers x = INSTANCE;
        if (x == null || !x.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (!x.tracers.on() && !x.skeleton.on()) return;
        x.draw(ctx, mc, mc.player);
    }

    /** Камера координаталары (оң, жоғары, алға) мен экранға проекция. */
    private static final class Cam {
        Vec3d eye, r, u, f;
        double tanHalf, aspect;
        int w, h;

        double[] c(Vec3d p) {
            double dx = p.x - eye.x, dy = p.y - eye.y, dz = p.z - eye.z;
            return new double[] {
                    dx * r.x + dy * r.y + dz * r.z,
                    dx * u.x + dy * u.y + dz * u.z,
                    dx * f.x + dy * f.y + dz * f.z };
        }

        double sx(double[] c) { return ((c[0] / c[2]) / (tanHalf * aspect) * 0.5 + 0.5) * w; }
        double sy(double[] c) { return (0.5 - (c[1] / c[2]) / tanHalf * 0.5) * h; }
    }

    private static Vec3d safeVel(net.minecraft.entity.Entity e) {
        Vec3d v = Util.vel(e);
        return v.lengthSquared() > 25.0 ? Vec3d.ZERO : v;   // телепорт кезінде секіріп кетпесін
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p) {
        // соңғы тиктен бері өткен үлес: энтити позициясын тегістеу үшін
        double frac = Math.max(0.0, Math.min(1.0, (System.nanoTime() - Util.tickNanos) / 50_000_000.0));

        Cam cam = new Cam();
        cam.eye = p.getEyePos().subtract(safeVel(p).multiply(1.0 - frac));
        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        double cy = Math.cos(yr), sy = Math.sin(yr), cp = Math.cos(pr), sp = Math.sin(pr);
        cam.f = new Vec3d(-sy * cp, -sp, cy * cp);
        cam.r = new Vec3d(-cy, 0, -sy);
        cam.u = cam.r.crossProduct(cam.f);
        cam.w = mc.getWindow().getScaledWidth();
        cam.h = mc.getWindow().getScaledHeight();
        cam.tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        cam.aspect = (double) cam.w / cam.h;

        double ox, oy;
        switch (origin.mode()) {
            case 1 -> { ox = cam.w / 2.0; oy = cam.h; }
            case 2 -> { ox = cam.w / 2.0; oy = 0; }
            default -> { ox = cam.w / 2.0; oy = cam.h / 2.0; }
        }

        for (PlayerEntity e : mc.world.getPlayers()) {
            if (!valid(p, e)) continue;
            Vec3d feet = Util.pos(e).subtract(safeVel(e).multiply(1.0 - frac));
            double dist = feet.distanceTo(cam.eye);
            if (dist > range.num()) continue;
            int color = distColor(dist, range.num());

            if (tracers.on()) {
                double hgt = e.getHeight();
                Vec3d tp = switch (point.mode()) {
                    case 1 -> feet.add(0, hgt * 0.5, 0);
                    case 2 -> feet.add(0, hgt, 0);
                    default -> feet;
                };
                double[] c = cam.c(tp);
                double tx, ty;
                boolean onScreen = c[2] >= 0.1;
                if (onScreen) {
                    tx = cam.sx(c);
                    ty = cam.sy(c);
                } else {
                    // артымызда: бұрылу бағытына қарай экран шетіне сызады
                    double dx = c[0], dy = -c[1];
                    double len = Math.max(1e-6, Math.hypot(dx, dy));
                    double big = Math.max(cam.w, cam.h) * 2.0;
                    tx = cam.w / 2.0 + dx / len * big;
                    ty = cam.h / 2.0 + dy / len * big;
                }
                line2(ctx, ox, oy, tx, ty, cam.w, cam.h, color);
                if (onScreen && tx >= 2 && ty >= 2 && tx < cam.w - 4 && ty < cam.h - 4) {
                    ctx.fill((int) tx - 2, (int) ty - 2, (int) tx + 3, (int) ty + 3, color);
                }
            }
            if (skeleton.on()) drawSkeleton(ctx, cam, e, feet, 0xFFFFFFFF);
        }
    }

    /** Жақын — қызыл, орта — сары, алыс — жасыл. */
    private static int distColor(double d, double max) {
        double t = Math.min(1.0, d / max);
        int r = t < 0.5 ? 255 : (int) (255 * (1.0 - (t - 0.5) * 2.0));
        int g = t < 0.5 ? (int) (255 * t * 2.0) : 255;
        return 0xFF000000 | (r << 16) | (g << 8) | 70;
    }

    private void drawSkeleton(DrawContext ctx, Cam cam, PlayerEntity e, Vec3d feet, int color) {
        EntityPose pose = e.getPose();
        boolean upright = pose == EntityPose.STANDING || pose == EntityPose.CROUCHING;
        boolean sneak = pose == EntityPose.CROUCHING;

        Vec3d up, rt, fwd, base;
        double s;
        if (upright) {
            double by = Math.toRadians(e.getBodyYaw());
            fwd = new Vec3d(-Math.sin(by), 0, Math.cos(by));
            rt = new Vec3d(-Math.cos(by), 0, -Math.sin(by));
            up = new Vec3d(0, 1, 0);
            base = feet;
            s = e.getHeight() / 1.8;
        } else {
            // ұшу/жүзу/еміп жүру: дене қарау бағытымен жатады
            Vec3d look = e.getRotationVec(1.0f);
            up = look.normalize();
            Vec3d h = new Vec3d(-look.z, 0, look.x);
            rt = h.lengthSquared() < 1e-6 ? new Vec3d(1, 0, 0) : h.normalize();
            fwd = up.crossProduct(rt).normalize();
            base = feet.add(0, e.getHeight() * 0.5, 0).subtract(up.multiply(0.9));
            s = 1.0;
        }
        double lean = sneak ? 0.3 : 0.0;

        Vec3d pelvis = at(base, up, rt, fwd, s, 0.75, 0, 0);
        Vec3d neck = at(base, up, rt, fwd, s, 1.40, 0, lean);
        Vec3d head = at(base, up, rt, fwd, s, 1.68, 0, lean * 1.1);
        Vec3d shL = at(base, up, rt, fwd, s, 1.40, -0.30, lean);
        Vec3d shR = at(base, up, rt, fwd, s, 1.40, 0.30, lean);
        Vec3d handL = at(base, up, rt, fwd, s, 0.75, -0.32, lean * 0.6);
        Vec3d handR = at(base, up, rt, fwd, s, 0.75, 0.32, lean * 0.6);
        Vec3d hipL = at(base, up, rt, fwd, s, 0.75, -0.12, 0);
        Vec3d hipR = at(base, up, rt, fwd, s, 0.75, 0.12, 0);
        Vec3d footL = at(base, up, rt, fwd, s, 0.0, -0.12, 0);
        Vec3d footR = at(base, up, rt, fwd, s, 0.0, 0.12, 0);

        seg(ctx, cam, neck, pelvis, color);
        seg(ctx, cam, neck, head, color);
        seg(ctx, cam, shL, shR, color);
        seg(ctx, cam, shL, handL, color);
        seg(ctx, cam, shR, handR, color);
        seg(ctx, cam, hipL, hipR, color);
        seg(ctx, cam, hipL, footL, color);
        seg(ctx, cam, hipR, footR, color);
    }

    private static Vec3d at(Vec3d base, Vec3d up, Vec3d rt, Vec3d fwd, double s, double u, double r, double f) {
        return base.add(up.multiply(u * s)).add(rt.multiply(r)).add(fwd.multiply(f));
    }

    /** 3D кесіндіні камера алдындағы бөлігімен ғана экранға сызады. */
    private static void seg(DrawContext ctx, Cam cam, Vec3d a, Vec3d b, int color) {
        double near = 0.1;
        double[] ca = cam.c(a), cb = cam.c(b);
        if (ca[2] < near && cb[2] < near) return;
        if (ca[2] < near) {
            double t = (near - ca[2]) / (cb[2] - ca[2]);
            for (int i = 0; i < 3; i++) ca[i] += (cb[i] - ca[i]) * t;
            ca[2] = near;
        } else if (cb[2] < near) {
            double t = (near - cb[2]) / (ca[2] - cb[2]);
            for (int i = 0; i < 3; i++) cb[i] += (ca[i] - cb[i]) * t;
            cb[2] = near;
        }
        line2(ctx, cam.sx(ca), cam.sy(ca), cam.sx(cb), cam.sy(cb), cam.w, cam.h, color);
    }

    /**
     * Тегіс сызық: экранға қиылады (Liang–Barsky), содан кейін матрицамен бұрылған бір жолақ ретінде салынады
     * (баспалдақ-пиксель жоқ, FPS-ке жеңіл: сызыққа 2 fill ғана). Айналасында жұмсақ жиек бар.
     */
    private static void line2(DrawContext c, double x1, double y1, double x2, double y2, int w, int h, int col) {
        double dx = x2 - x1, dy = y2 - y1;
        double t0 = 0, t1 = 1;
        double[] pp = { -dx, dx, -dy, dy };
        double[] qq = { x1, (w - 1) - x1, y1, (h - 1) - y1 };
        for (int i = 0; i < 4; i++) {
            if (pp[i] == 0) {
                if (qq[i] < 0) return;
            } else {
                double t = qq[i] / pp[i];
                if (pp[i] < 0) {
                    if (t > t1) return;
                    if (t > t0) t0 = t;
                } else {
                    if (t < t0) return;
                    if (t < t1) t1 = t;
                }
            }
        }
        double ax = x1 + dx * t0, ay = y1 + dy * t0, bx = x1 + dx * t1, by = y1 + dy * t1;
        double len = Math.hypot(bx - ax, by - ay);
        if (len < 0.5) return;

        // ақ сызық (қаңқа) — қара жиекпен, түсті сызық (tracer) — өз түсінің жұмсақ жарқылымен
        int rgb = col & 0xFFFFFF;
        int under = rgb == 0xFFFFFF ? 0x90000000 : ((0x58 << 24) | rgb);

        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) ax, (float) ay);
        m.rotate((float) Math.atan2(by - ay, bx - ax));
        int l = (int) Math.ceil(len);
        c.fill(-1, -2, l + 1, 2, under);     // сыртқы жиек (қалыңдығы 4)
        c.fill(0, -1, l, 1, col);            // өзек (қалыңдығы 2)
        m.popMatrix();
    }
}
