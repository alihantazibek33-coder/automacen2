package kz.alih.modules;

import kz.alih.Builder;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоҚабат: блок қойсаң, сол блоктың айналасына дәл сондай блоктарды жайып қояды (1 қабат).
 * Жерге қойсаң — жер бетіне жазық алаң (3×3, 5×5...), қабырғаға қойсаң — тік қабат.
 */
public class AutoLayer extends Module {
    public static AutoLayer INSTANCE;

    private final Setting size = num("Өлшем", 3, 3, 11, 2);
    private final Setting shape = mode("Пішін", 0, "Шаршы", "Дөңгелек", "Ромб");
    private final Setting perTick = num("Блок/тик", 6, 1, 10, 1);

    private final Builder builder = new Builder();
    private int idle;

    public AutoLayer() {
        super("autolayer", "АвтоҚабат", "Блок қойсаң, айналасына дәл сол блокты жайып (3×3, 5×5...) қояды");
        INSTANCE = this;
        builder.walk = false;
        builder.breakBlocks = false;
    }

    @Override
    protected void onDisable() { builder.clear(); }

    @Override
    public void reset() { builder.clear(); }

    /** UseBlockCallback шақырады: пайдаланушы блок қойды. anchor — қойылған блоктың орны, side — басылған бет. */
    public void trigger(Block block, BlockPos anchor, Direction side) {
        if (!enabled || Util.placing || !builder.entries.isEmpty()) return;
        if (Util.mc().player == null) return;

        int half = (int) size.num() / 2;
        for (int a = -half; a <= half; a++) {
            for (int b = -half; b <= half; b++) {
                if (a == 0 && b == 0) continue;                       // ортасын өзің қойдың
                boolean ok = switch (shape.mode()) {
                    case 1 -> a * a + b * b <= half * half + 1;
                    case 2 -> Math.abs(a) + Math.abs(b) <= half;
                    default -> true;
                };
                if (!ok) continue;
                // қабат басылған бетке перпендикуляр жазықтықта жатады
                BlockPos pos = switch (side.getAxis()) {
                    case Y -> anchor.add(a, 0, b);                     // жерге/төбеге → көлденең алаң
                    case X -> anchor.add(0, a, b);                     // қабырға (шығыс-батыс) → тік қабат
                    default -> anchor.add(a, b, 0);                    // қабырға (солтүстік-оңтүстік) → тік қабат
                };
                builder.entries.add(new Builder.Entry(pos, block));
            }
        }
        // ортадан шетке қарай жайылады (әр блок алдыңғысына сүйенеді)
        final Vec3d c = Vec3d.ofCenter(anchor);
        builder.entries.sort((x, y) -> Double.compare(Vec3d.ofCenter(x.pos).squaredDistanceTo(c), Vec3d.ofCenter(y.pos).squaredDistanceTo(c)));
        idle = 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (builder.entries.isEmpty() || mc.currentScreen != null) return;
        builder.perTick = (int) perTick.num();
        boolean done = builder.tick(mc, p);
        if (done) return;
        if (builder.lastPlaced == 0) {
            if (++idle > 40) {              // қолға жетпейтін немесе блогы жоқ қалғандарын тастайды
                builder.clear();
                Util.msg("АвтоҚабат: қалғанына қол жетпейді немесе блок жетпейді");
            }
        } else {
            idle = 0;
        }
    }
}
