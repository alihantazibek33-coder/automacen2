package kz.alih;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** АвтоМайн аймағы: .alih minepos 1 / 2 командасымен қойылған екі бұрыш. */
public final class MineRegion {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("alihclient-minepos.txt");
    public static BlockPos p1, p2;

    private MineRegion() {}

    public static boolean complete() { return p1 != null && p2 != null; }

    public static int minX() { return Math.min(p1.getX(), p2.getX()); }
    public static int maxX() { return Math.max(p1.getX(), p2.getX()); }
    public static int minY() { return Math.min(p1.getY(), p2.getY()); }
    public static int maxY() { return Math.max(p1.getY(), p2.getY()); }
    public static int minZ() { return Math.min(p1.getZ(), p2.getZ()); }
    public static int maxZ() { return Math.max(p1.getZ(), p2.getZ()); }

    public static boolean contains(BlockPos p) {
        return complete() && p.getX() >= minX() && p.getX() <= maxX() && p.getY() >= minY() && p.getY() <= maxY()
                && p.getZ() >= minZ() && p.getZ() <= maxZ();
    }

    public static long volume() {
        return complete() ? (long) (maxX() - minX() + 1) * (maxY() - minY() + 1) * (maxZ() - minZ() + 1) : 0;
    }

    public static void set(int idx, BlockPos pos) {
        if (idx == 1) p1 = pos; else p2 = pos;
        save();
    }

    public static void clear() {
        p1 = null;
        p2 = null;
        save();
    }

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            String[] a = Files.readString(FILE).trim().split("\\s+");
            if (a.length >= 3 && !a[0].equals("-")) p1 = new BlockPos(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2]));
            if (a.length >= 6 && !a[3].equals("-")) p2 = new BlockPos(Integer.parseInt(a[3]), Integer.parseInt(a[4]), Integer.parseInt(a[5]));
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    private static void save() {
        String s1 = p1 == null ? "- - -" : p1.getX() + " " + p1.getY() + " " + p1.getZ();
        String s2 = p2 == null ? "- - -" : p2.getX() + " " + p2.getY() + " " + p2.getZ();
        try {
            Files.writeString(FILE, s1 + " " + s2);
        } catch (IOException ignored) {
        }
    }
}
