package kz.alih;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Крафт көмекшісі: инвентарь (2x2) немесе ашық верстак (3x3) торына ингредиенттерді өзі қояды,
 * нәтижені shift-click арқылы алады. Рецепт — тор үлгісі (бос ұяшық = пробел).
 */
public final class Crafter {
    public static final class Recipe {
        final String[] rows;
        final Map<Character, Predicate<ItemStack>> map;
        final Predicate<ItemStack> out;
        final int w, h;

        Recipe(String[] rows, Map<Character, Predicate<ItemStack>> map, Predicate<ItemStack> out) {
            this.rows = rows;
            this.map = map;
            this.out = out;
            int mw = 0;
            for (String r : rows) mw = Math.max(mw, r.length());
            this.w = mw;
            this.h = rows.length;
        }

        public boolean needsTable() { return w > 2 || h > 2; }

        /** Рецепттегі таяқша ұяшықтарының саны ('S'). */
        public int stickCells() {
            int n = 0;
            for (String row : rows) for (char c : row.toCharArray()) if (c == 'S') n++;
            return n;
        }
    }

    public enum Status { RUNNING, DONE, FAILED }

    private enum K { CLICK, WAIT, AWAIT, CLEAN }

    private record Act(K k, int slot, int button, SlotActionType type, int n) {}

    private final ArrayDeque<Act> q = new ArrayDeque<>();
    private Recipe recipe;
    private int waitT, awaitT;
    private String error = "";

    public String error() { return error; }

    public boolean busy() { return !q.isEmpty(); }

    // ================================================================ рецепттер

    private static Predicate<ItemStack> is(net.minecraft.item.Item it) { return s -> s.isOf(it); }

    private static final Predicate<ItemStack> LOG = s -> s.isIn(ItemTags.LOGS);
    private static final Predicate<ItemStack> PLANK = s -> s.isIn(ItemTags.PLANKS);
    private static final Predicate<ItemStack> STICK = is(Items.STICK);
    public static final Predicate<ItemStack> COBBLE =
            s -> s.isOf(Items.COBBLESTONE) || s.isOf(Items.COBBLED_DEEPSLATE) || s.isOf(Items.BLACKSTONE);

    private static Recipe r(Predicate<ItemStack> out, String[] rows, Object... kv) {
        Map<Character, Predicate<ItemStack>> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            @SuppressWarnings("unchecked")
            Predicate<ItemStack> p = (Predicate<ItemStack>) kv[i + 1];
            m.put((Character) kv[i], p);
        }
        return new Recipe(rows, m, out);
    }

    public static final Recipe PLANKS = r(PLANK, new String[] { "L" }, 'L', LOG);
    public static final Recipe STICKS = r(STICK, new String[] { "P", "P" }, 'P', PLANK);
    public static final Recipe TABLE = r(is(Items.CRAFTING_TABLE), new String[] { "PP", "PP" }, 'P', PLANK);

    public static final Recipe WOOD_PICK = r(is(Items.WOODEN_PICKAXE), new String[] { "PPP", " S ", " S " }, 'P', PLANK, 'S', STICK);
    public static final Recipe STONE_PICK = r(is(Items.STONE_PICKAXE), new String[] { "CCC", " S ", " S " }, 'C', COBBLE, 'S', STICK);
    public static final Recipe STONE_AXE = r(is(Items.STONE_AXE), new String[] { "CC", "CS", " S" }, 'C', COBBLE, 'S', STICK);
    public static final Recipe FURNACE = r(is(Items.FURNACE), new String[] { "CCC", "C C", "CCC" }, 'C', COBBLE);

    public static final Recipe IRON_PICK = r(is(Items.IRON_PICKAXE), new String[] { "III", " S ", " S " }, 'I', is(Items.IRON_INGOT), 'S', STICK);

    public static final Recipe DIAMOND_PICK = r(is(Items.DIAMOND_PICKAXE), new String[] { "DDD", " S ", " S " }, 'D', is(Items.DIAMOND), 'S', STICK);
    public static final Recipe DIAMOND_SWORD = r(is(Items.DIAMOND_SWORD), new String[] { "D", "D", "S" }, 'D', is(Items.DIAMOND), 'S', STICK);
    public static final Recipe DIAMOND_AXE = r(is(Items.DIAMOND_AXE), new String[] { "DD", "DS", " S" }, 'D', is(Items.DIAMOND), 'S', STICK);
    public static final Recipe DIAMOND_HELMET = r(is(Items.DIAMOND_HELMET), new String[] { "DDD", "D D" }, 'D', is(Items.DIAMOND));
    public static final Recipe DIAMOND_CHEST = r(is(Items.DIAMOND_CHESTPLATE), new String[] { "D D", "DDD", "DDD" }, 'D', is(Items.DIAMOND));
    public static final Recipe DIAMOND_LEGS = r(is(Items.DIAMOND_LEGGINGS), new String[] { "DDD", "D D", "D D" }, 'D', is(Items.DIAMOND));
    public static final Recipe DIAMOND_BOOTS = r(is(Items.DIAMOND_BOOTS), new String[] { "D D", "D D" }, 'D', is(Items.DIAMOND));

    // ================================================================ жоспарлау

    /** Рецептті ең көбі maxN рет жасауды бастайды. false — ингредиент жетпейді / тор сәйкес емес (error() қараңыз). */
    public boolean start(MinecraftClient mc, ClientPlayerEntity p, Recipe r, int maxN) {
        q.clear();
        waitT = 0;
        awaitT = 0;
        recipe = r;
        ScreenHandler h = p.currentScreenHandler;
        boolean table = h instanceof CraftingScreenHandler;
        if (!table && h != p.playerScreenHandler) { error = "крафт торы жоқ"; return false; }
        int gw = table ? 3 : 2;
        if (r.w > gw || r.h > gw) { error = "верстак керек"; return false; }
        if (!h.getCursorStack().isEmpty()) { error = "курсорда зат тұр"; return false; }
        int invFrom = table ? 10 : 9, invTo = table ? 46 : 45;     // 10..45 / 9..44 (екіншілік қолсыз)

        List<int[]> cells = new ArrayList<>();                     // {нысана слот}
        List<Predicate<ItemStack>> preds = new ArrayList<>();
        for (int y = 0; y < r.rows.length; y++) {
            for (int x = 0; x < r.rows[y].length(); x++) {
                char ch = r.rows[y].charAt(x);
                if (ch == ' ') continue;
                cells.add(new int[] { 1 + y * gw + x });
                preds.add(r.map.get(ch));
            }
        }

        int[] src = null;
        int k = maxN;
        for (; k >= 1; k--) {
            src = plan(h, preds, invFrom, invTo, k);
            if (src != null) break;
        }
        if (src == null) { error = "ингредиент жетпейді"; return false; }

        for (int i = 0; i < cells.size(); i++) {
            int target = cells.get(i)[0];
            q.add(new Act(K.CLICK, src[i], 0, SlotActionType.PICKUP, 0));        // стекті көтеру
            for (int j = 0; j < k; j++) q.add(new Act(K.CLICK, target, 1, SlotActionType.PICKUP, 0));   // 1-ден қою
            q.add(new Act(K.CLICK, src[i], 0, SlotActionType.PICKUP, 0));        // қалғанын қайтару
        }
        q.add(new Act(K.AWAIT, 0, 0, null, 0));
        q.add(new Act(K.CLICK, 0, 0, SlotActionType.QUICK_MOVE, 0));
        q.add(new Act(K.WAIT, 0, 0, null, 3));
        q.add(new Act(K.CLEAN, gw * gw, 0, null, 0));
        error = "";
        return true;
    }

    /** Әр ұяшық үшін қайнар слот таңдайды (k дана жететін). Модель арқылы: бір стек қайта қолданылса да дұрыс. */
    private static int[] plan(ScreenHandler h, List<Predicate<ItemStack>> preds, int from, int to, int k) {
        int[] model = new int[to];
        for (int i = from; i < to; i++) model[i] = h.getSlot(i).getStack().getCount();
        int[] out = new int[preds.size()];
        for (int c = 0; c < preds.size(); c++) {
            int pick = -1;
            for (int i = from; i < to; i++) {
                ItemStack s = h.getSlot(i).getStack();
                if (s.isEmpty() || model[i] < k || !preds.get(c).test(s)) continue;
                pick = i;
                break;
            }
            if (pick < 0) return null;
            model[pick] -= k;
            out[c] = pick;
        }
        return out;
    }

    // ================================================================ орындау

    public Status tick(MinecraftClient mc, ClientPlayerEntity p) {
        if (q.isEmpty()) return Status.DONE;
        ScreenHandler h = p.currentScreenHandler;
        if (!(h instanceof CraftingScreenHandler) && h != p.playerScreenHandler) { error = "экран жабылды"; q.clear(); return Status.FAILED; }
        if (waitT > 0) { waitT--; return Status.RUNNING; }

        int clicks = 0;
        while (!q.isEmpty() && clicks < 4) {
            Act a = q.peek();
            switch (a.k()) {
                case CLICK -> {
                    mc.interactionManager.clickSlot(h.syncId, a.slot(), a.button(), a.type(), p);
                    q.poll();
                    clicks++;
                }
                case WAIT -> {
                    q.poll();
                    waitT = a.n();
                    return Status.RUNNING;
                }
                case AWAIT -> {
                    ItemStack res = h.getSlot(0).getStack();
                    if (!res.isEmpty() && recipe.out.test(res)) {
                        q.poll();
                        awaitT = 0;
                    } else {
                        if (++awaitT > 40) { error = "нәтиже шықпады"; q.clear(); return Status.FAILED; }
                        return Status.RUNNING;
                    }
                }
                case CLEAN -> {
                    q.poll();
                    for (int s = 1; s <= a.slot(); s++) {
                        if (!h.getSlot(s).getStack().isEmpty()) {
                            mc.interactionManager.clickSlot(h.syncId, s, 0, SlotActionType.QUICK_MOVE, p);
                        }
                    }
                    return Status.RUNNING;
                }
            }
        }
        return q.isEmpty() ? Status.DONE : Status.RUNNING;
    }
}
