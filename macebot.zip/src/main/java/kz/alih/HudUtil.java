package kz.alih;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/** HUD үшін ортақ: 3D нүктені экранға проекциялау. */
public final class HudUtil {
    private HudUtil() {}

    public static final class Cam {
        public Vec3d eye, r, u, f;
        public double tanHalf, aspect;
        public int w, h;

        /** {x, y, тереңдік} немесе камераның артында болса null. */
        public double[] project(Vec3d p) {
            double dx = p.x - eye.x, dy = p.y - eye.y, dz = p.z - eye.z;
            double cx = dx * r.x + dy * r.y + dz * r.z;
            double cy = dx * u.x + dy * u.y + dz * u.z;
            double cz = dx * f.x + dy * f.y + dz * f.z;
            if (cz < 0.1) return null;
            double sx = ((cx / cz) / (tanHalf * aspect) * 0.5 + 0.5) * w;
            double sy = (0.5 - (cy / cz) / tanHalf * 0.5) * h;
            return new double[] { sx, sy, cz };
        }
    }

    /** Соңғы тиктен бері өткен үлес (0..1). */
    public static double frac() {
        return Math.max(0.0, Math.min(1.0, (System.nanoTime() - Util.tickNanos) / 50_000_000.0));
    }

    /** Энтити позициясын тегістеу үшін ығысу. */
    public static Vec3d smoothOffset(Entity e) {
        Vec3d v = Util.vel(e);
        if (v.lengthSquared() > 25.0) v = Vec3d.ZERO;
        return v.multiply(-(1.0 - frac()));
    }

    public static Cam cam(MinecraftClient mc, ClientPlayerEntity p) {
        Cam cam = new Cam();
        cam.eye = p.getEyePos().add(smoothOffset(p));
        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        double cy = Math.cos(yr), sy = Math.sin(yr), cp = Math.cos(pr), sp = Math.sin(pr);
        cam.f = new Vec3d(-sy * cp, -sp, cy * cp);
        cam.r = new Vec3d(-cy, 0, -sy);
        cam.u = cam.r.crossProduct(cam.f);
        cam.w = mc.getWindow().getScaledWidth();
        cam.h = mc.getWindow().getScaledHeight();
        cam.tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        cam.aspect = (double) cam.w / cam.h;
        return cam;
    }

    /** Реңк (0..1) → ARGB (толық қанықтылық). */
    public static int hsv(double h, double s, double v) {
        h = h - Math.floor(h);
        double hh = h * 6.0;
        int i = (int) hh;
        double f = hh - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0xFFFFFF);
    }
}
