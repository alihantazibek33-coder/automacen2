package kz.alih;

public final class Setting {
    public enum Type { BOOL, NUM, MODE }

    public final String name;
    public final Type type;
    public boolean b;
    public double v, min, max, step;
    public String[] modes;
    public int m;

    private Setting(String name, Type type) {
        this.name = name;
        this.type = type;
    }

    public static Setting bool(String name, boolean def) {
        Setting s = new Setting(name, Type.BOOL);
        s.b = def;
        return s;
    }

    public static Setting num(String name, double def, double min, double max, double step) {
        Setting s = new Setting(name, Type.NUM);
        s.v = def; s.min = min; s.max = max; s.step = step;
        return s;
    }

    public static Setting mode(String name, int def, String... modes) {
        Setting s = new Setting(name, Type.MODE);
        s.m = def; s.modes = modes;
        return s;
    }

    public boolean on() { return b; }
    public double num() { return v; }
    public int mode() { return m; }

    public void inc() { v = Math.min(max, round(v + step)); }
    public void dec() { v = Math.max(min, round(v - step)); }
    public void cycle() { if (type == Type.MODE) m = (m + 1) % modes.length; }
    public void flip() { b = !b; }

    private static double round(double x) { return Math.round(x * 100.0) / 100.0; }

    public String display() {
        return switch (type) {
            case BOOL -> b ? "ON" : "OFF";
            case NUM -> (v == Math.floor(v)) ? String.valueOf((long) v) : String.valueOf(v);
            case MODE -> modes[m];
        };
    }
}
