package kz.alih.gui;

import kz.alih.AlihClient;
import kz.alih.Config;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Nebula мәзірі: жұлдызды аспан, қозғалатын тұман, жарқыраған жиек, жұмсақ анимациялар
 * (ашылу/жабылу, қосу/өшіру, hover, слайдер, рябь, жылтыр бөлшектер).
 */
public class MenuScreen extends Screen {
    private static final int W = 470;
    private static final int ROW = 20;
    private static final int SROW = 21;

    private static final String[] TABS = { "Бой", "PvP+", "Қозғалыс", "Визуал", "Утилита", "UHC" };

    // ---- түстер (nebula палитрасы)
    private static final int PURPLE = 0xA855F7;
    private static final int CYAN = 0x38D8FF;
    private static final int PINK = 0xF472B6;
    private static final int BLUE = 0x5B6CFF;
    private static final int OFF_TRACK = 0xFF2A2440;
    private static final int TEXT = 0xFFEDE9FF;
    private static final int DIM = 0xFF9189B8;
    private static final int DARK = 0xFF5E5780;

    // ---- күй
    private int tab;
    private Module selected;
    private Module binding;
    private int setPage, listPage;
    private boolean wasLeft, wasRight, first = true;
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];

    // ---- анимация күйі
    private final long t0 = System.nanoTime();
    private long last = System.nanoTime();
    private float dt, time;
    private float openT, closeT;
    private boolean closing;
    private float listT, setT;
    private float tabX = -1;
    private final Map<Module, float[]> ST = new IdentityHashMap<>();
    private final Map<Setting, float[]> SS = new IdentityHashMap<>();
    private Setting dragging;
    private int dragX1, dragX2;

    private static final class Ripple { float x, y, age; int rgb; }
    private final List<Ripple> ripples = new ArrayList<>();

    // жұлдыздар мен бөлшектер
    private static final int NS = 110, NP = 34;
    private final float[] stX = new float[NS], stY = new float[NS], stPh = new float[NS], stSz = new float[NS];
    private final float[] pX = new float[NP], pY = new float[NP], pSp = new float[NP], pPh = new float[NP];
    private float shootT = 3f, shX, shY, shVX, shVY, shLife;

    private DrawContext c;
    private TextRenderer tr;
    private float curAlpha = 1f;

    public MenuScreen() {
        super(Text.literal("AlihClient"));
        Random r = new Random(7);
        for (int i = 0; i < NS; i++) {
            stX[i] = r.nextFloat(); stY[i] = r.nextFloat();
            stPh[i] = r.nextFloat() * 6.28f; stSz[i] = r.nextFloat() < 0.12f ? 2 : 1;
        }
        for (int i = 0; i < NP; i++) {
            pX[i] = r.nextFloat(); pY[i] = r.nextFloat();
            pSp[i] = 0.02f + r.nextFloat() * 0.05f; pPh[i] = r.nextFloat() * 6.28f;
        }
        selected = modulesOf(0).isEmpty() ? AlihClient.MODULES.get(0) : modulesOf(0).get(0);
    }

    private static int tabOf(Module m) {
        return switch (m.id) {
            case "autocrystal", "autoanchor", "autocart", "shieldbreak", "autototem", "autoarmor", "autopearl" -> 1;
            case "scaffold", "autosprint", "step", "speed", "fly", "ghostteleport", "nofall", "antiafk", "autoblock", "jesus", "spider", "noslow", "elytraboost" -> 2;
            case "fullbright", "esp", "zoom", "antiinvis", "xray", "chathide", "espplayers", "freecam", "waypoints", "deathmarker", "hud", "targethud", "damagenumbers" -> 3;
            case "cheststealer", "automark", "autobase", "autobuild", "autoshablon", "fpsboost", "automine", "humanize", "autospawner", "autofish", "fastplace", "fastbreak", "invsorter", "autoalmazka", "autocane", "drill", "autolayer" -> 4;
            case "autoweb", "autoheadweb", "headwebplate", "autodrain", "stunslam" -> 5;
            default -> 0;
        };
    }

    private static List<Module> modulesOf(int t) {
        List<Module> list = new ArrayList<>();
        for (Module m : AlihClient.MODULES) if (tabOf(m) == t) list.add(m);
        return list;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return false; }          // ESC-ті өзіміз өңдейміз (жабылу анимациясы үшін)

    // ================================================================ көмекшілер

    private float[] st(Module m) { return ST.computeIfAbsent(m, k -> new float[] { 0, k.enabled ? 1 : 0, 0, 0 }); }

    private float[] ss(Setting s) {
        return SS.computeIfAbsent(s, k -> new float[] {
                0, k.type == Setting.Type.BOOL ? (k.b ? 1 : 0) : (k.max > k.min ? (float) ((k.v - k.min) / (k.max - k.min)) : 0) });
    }

    private static float ease(float cur, float target, float dt, float speed) {
        return cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
    }

    private static float outCubic(float t) { t = Math.max(0, Math.min(1, t)); float u = 1 - t; return 1 - u * u * u; }

    private static int lerpC(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, aa = a >>> 24;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** Аралық реңк: PURPLE ↔ CYAN, уақыт пен орынға байланысты тербеледі. */
    private int accent(float phase) {
        float w = (float) (Math.sin(time * 0.9 + phase) * 0.5 + 0.5);
        return 0xFF000000 | (lerpC(0xFF000000 | PURPLE, 0xFF000000 | CYAN, w) & 0xFFFFFF);
    }

    /** Түсті ағымдағы мөлдірлікке (ашылу/жабылу/қатар анимациясы) көбейтеді. */
    private int A(int argb) {
        int a = (int) ((argb >>> 24) * curAlpha);
        return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF);
    }

    private void fill(int x1, int y1, int x2, int y2, int col) {
        if (x2 <= x1 || y2 <= y1) return;
        c.fill(x1, y1, x2, y2, A(col));
    }

    /** Дөңгелектелген төртбұрыш. */
    private void rr(int x1, int y1, int x2, int y2, int r, int col) {
        if (x2 - x1 < 2 * r || y2 - y1 < 2 * r) { fill(x1, y1, x2, y2, col); return; }
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int ins = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            fill(x1 + ins, y1 + i, x2 - ins, y1 + i + 1, col);
            fill(x1 + ins, y2 - i - 1, x2 - ins, y2 - i, col);
        }
        fill(x1, y1 + r, x2, y2 - r, col);
    }

    private void disc(int cx, int cy, int R, int rgb, int a) {
        if (R < 1) return;
        for (int dy = -R; dy <= R; dy += 2) {
            int hw = (int) Math.sqrt((double) R * R - (double) dy * dy);
            fill(cx - hw, cy + dy, cx + hw, cy + dy + 2, (a << 24) | rgb);
        }
    }

    /** Жұмсақ жарқыл (шоғырланған дискілер). */
    private void glow(int cx, int cy, int R, int rgb, int aPer) {
        for (int i = 0; i < 6; i++) disc(cx, cy, (int) (R * (1 - i * 0.16)), rgb, aPer);
    }

    private void text(String s, int x, int y, int col) {
        int a = (int) ((col >>> 24) * curAlpha);
        if (a < 12) return;
        c.drawText(tr, s, x, y, (a << 24) | (col & 0xFFFFFF), true);
    }

    private void textC(String s, int cx, int y, int col) { text(s, cx - tr.getWidth(s) / 2, y, col); }

    private void gtext(String s, int x, int y, float phase) {
        int px = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(ch, px, y, accent(phase + i * 0.35f));
            px += tr.getWidth(ch);
        }
    }

    private void hline(int x1, int x2, int y, float phase, int a) {
        for (int x = x1; x < x2; x += 4) {
            fill(x, y, Math.min(x2, x + 4), y + 1, (a << 24) | (accent(phase + x * 0.012f) & 0xFFFFFF));
        }
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
    }

    private void ripple(float x, float y, int rgb) {
        Ripple r = new Ripple();
        r.x = x; r.y = y; r.rgb = rgb;
        ripples.add(r);
    }

    private void toggleSwitch(int x, int y, float t, boolean hover) {
        int w = 26, h = 12;
        if (t > 0.05f) glow(x + w / 2, y + h / 2, 17, accent(x * 0.02f) & 0xFFFFFF, (int) (7 * t));
        rr(x, y, x + w, y + h, 5, lerpC(OFF_TRACK, 0xFF000000 | (accent(x * 0.02f) & 0xFFFFFF), t));
        int kx = (int) (x + 1 + (w - h) * t);
        rr(kx, y + 1, kx + h - 2, y + h - 1, 4, lerpC(0xFFB9B2D6, 0xFFFFFFFF, hover ? 1f : t));
    }

    // ================================================================ фон: тұман, жұлдыздар

    private void drawBackdrop(int mx, int my, float a) {
        curAlpha = a;
        c.fillGradient(0, 0, width, height, A(0xC4050212), A(0xD60F0522));

        // қозғалатын тұман дақтары
        float t = time;
        glow((int) (width * 0.22 + Math.sin(t * 0.21) * 60), (int) (height * 0.30 + Math.cos(t * 0.17) * 40), 190, PURPLE, 6);
        glow((int) (width * 0.78 + Math.cos(t * 0.19) * 70), (int) (height * 0.70 + Math.sin(t * 0.23) * 45), 210, CYAN, 4);
        glow((int) (width * 0.55 + Math.sin(t * 0.13) * 90), (int) (height * 0.20 + Math.cos(t * 0.29) * 30), 150, PINK, 4);
        glow((int) (width * 0.35 + Math.cos(t * 0.11) * 80), (int) (height * 0.85 + Math.sin(t * 0.15) * 25), 170, BLUE, 5);

        // жұлдыздар (тышқанға қарай жеңіл параллакс)
        float px = (mx - width / 2f) * 0.012f, py = (my - height / 2f) * 0.012f;
        for (int i = 0; i < NS; i++) {
            float tw = (float) (Math.sin(t * (1.2 + stSz[i] * 0.4) + stPh[i]) * 0.5 + 0.5);
            int x = (int) (stX[i] * width + px * stSz[i] * 3), y = (int) (stY[i] * height + py * stSz[i] * 3);
            int sz = (int) stSz[i];
            int col = lerpC(0xFF8E86C8, 0xFFFFFFFF, tw);
            fill(x, y, x + sz, y + sz, (int) (60 + 150 * tw) << 24 | (col & 0xFFFFFF));
            if (sz == 2 && tw > 0.7f) {                               // жарқыраған жұлдыз: айқас сәуле
                fill(x - 2, y, x + 4, y + 1, 0x70FFFFFF);
                fill(x, y - 2, x + 1, y + 4, 0x70FFFFFF);
            }
        }

        // ұшатын жұлдыз
        shootT -= dt;
        if (shootT <= 0) {
            shootT = 4f + (float) Math.random() * 6f;
            shX = (float) Math.random() * width * 0.8f; shY = (float) Math.random() * height * 0.4f;
            shVX = 260 + (float) Math.random() * 120; shVY = 120 + (float) Math.random() * 80;
            shLife = 1f;
        }
        if (shLife > 0) {
            shLife -= dt * 1.1f;
            shX += shVX * dt; shY += shVY * dt;
            for (int i = 0; i < 14; i++) {
                int x = (int) (shX - shVX * i * 0.006f), y = (int) (shY - shVY * i * 0.006f);
                int al = (int) (200 * Math.max(0, shLife) * (1 - i / 14f));
                fill(x, y, x + 2, y + 1, (al << 24) | 0xFFFFFF);
            }
        }
    }

    // ================================================================ негізгі рендер

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        this.c = ctx;
        MinecraftClient mc = MinecraftClient.getInstance();
        tr = mc.textRenderer;
        long win = mc.getWindow().getHandle();

        long now = System.nanoTime();
        dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        time = (now - t0) / 1e9f;

        // ---- ашылу / жабылу
        if (!closing) openT = Math.min(1f, openT + dt / 0.42f);
        else { closeT += dt / 0.28f; if (closeT >= 1f) { mc.setScreen(null); return; } }
        float e = closing ? 1f - outCubic(closeT) : outCubic(openT);
        boolean live = !closing && openT >= 0.95f;

        // ---- тышқан/пернетақта (GLFW арқылы)
        boolean left = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean rightB = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = left && !wasLeft && !first && live;
        boolean clickR = rightB && !wasRight && !first && live;
        wasLeft = left;
        wasRight = rightB;
        if (!left && dragging != null) { Config.save(); dragging = null; }

        for (int k = 32; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean down = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (down && !prevKey[k] && !first) {
                if (binding != null) {
                    binding.key = (k == GLFW.GLFW_KEY_ESCAPE) ? Util.UNSET : k;
                    binding = null;
                    Config.save();
                } else if ((k == GLFW.GLFW_KEY_ESCAPE || k == AlihClient.menuKey) && !closing) {
                    closing = true;
                    closeT = 0f;
                }
            }
            prevKey[k] = down;
        }
        first = false;

        // ---- фон (толық экран)
        drawBackdrop(mx, my, e);

        // ---- панель өлшемі
        int H = Math.min(272, height - 16);
        int x0 = (width - W) / 2, y0 = (height - H) / 2;
        int x1 = x0 + W, y1 = y0 + H;

        var m = c.getMatrices();
        float scale = 0.9f + 0.1f * e;
        m.pushMatrix();
        m.translate(width / 2f, height / 2f);
        m.scale(scale, scale);
        m.translate(-width / 2f, -height / 2f);
        curAlpha = e;

        // сыртқы жарқыл
        for (int g = 9; g >= 1; g--) {
            rr(x0 - g, y0 - g, x1 + g, y1 + g, 4 + g, ((int) (9 - g * 0.8) << 24) | (accent(g * 0.1f) & 0xFFFFFF));
        }
        // панель денесі
        rr(x0, y0, x1, y1, 5, 0xF00A0618);
        c.fillGradient(x0 + 2, y0 + 2, x1 - 2, y1 - 2, A(0xE41A0C38), A(0xEE070413));
        // панельдің ішіндегі жұмсақ тұман
        glow((int) (x0 + 110 + Math.sin(time * 0.4) * 18), (int) (y0 + 100 + Math.cos(time * 0.3) * 10), 62, PURPLE, 6);
        glow((int) (x1 - 100 + Math.cos(time * 0.35) * 18), (int) (y1 - 70 + Math.sin(time * 0.45) * 10), 58, CYAN, 5);

        // жылтыр бөлшектер
        for (int i = 0; i < NP; i++) {
            pY[i] -= pSp[i] * dt;
            if (pY[i] < 0) { pY[i] = 1; }
            float tw = (float) (Math.sin(time * 1.6 + pPh[i]) * 0.5 + 0.5);
            int px = x0 + 4 + (int) (pX[i] * (W - 8) + Math.sin(time * 0.5 + pPh[i]) * 4);
            int py = y0 + 4 + (int) (pY[i] * (H - 8));
            fill(px, py, px + 1, py + 1, ((int) (40 + 130 * tw) << 24) | (i % 2 == 0 ? 0xE9D5FF : 0xBAF0FF));
        }

        // жиек (жылжымалы градиент)
        for (int x = x0 + 4; x < x1 - 4; x += 3) {
            int col = accent(x * 0.015f) & 0xFFFFFF;
            fill(x, y0, x + 3, y0 + 1, 0xFF000000 | col);
            fill(x, y1 - 1, x + 3, y1, 0xFF000000 | (accent(x * 0.015f + 2.2f) & 0xFFFFFF));
        }
        for (int y = y0 + 4; y < y1 - 4; y += 3) {
            fill(x0, y, x0 + 1, y + 3, 0xFF000000 | (accent(y * 0.02f + 1f) & 0xFFFFFF));
            fill(x1 - 1, y, x1, y + 3, 0xFF000000 | (accent(y * 0.02f + 3f) & 0xFFFFFF));
        }

        drawHeader(x0, y0, mx, my, clickL);
        drawTabs(x0, y0, mx, my, clickL);

        listT += dt;
        setT += dt;
        drawList(x0, y0, H, mx, my, clickL, clickR);
        drawSettings(x0, y0, H, mx, my, clickL, clickR, left);

        // рябь эффектілері
        curAlpha = e;
        for (int i = ripples.size() - 1; i >= 0; i--) {
            Ripple r = ripples.get(i);
            r.age += dt * 2.2f;
            if (r.age >= 1f) { ripples.remove(i); continue; }
            int rad = (int) (4 + 22 * outCubic(r.age));
            disc((int) r.x, (int) r.y, rad, r.rgb, (int) (22 * (1 - r.age)));
        }

        textC("Ауыстырғыш — қосу/өшіру  •  Қатар — баптау  •  ПКМ — кері/тазалау  •  ESC / " + Util.keyName(AlihClient.menuKey) + " — жабу",
                x0 + W / 2, y1 - 11, DARK);

        m.popMatrix();
    }

    // ================================================================ тақырып

    private void drawHeader(int x0, int y0, int mx, int my, boolean clickL) {
        // айналатын жарқырауық
        int sx = x0 + 17, sy = y0 + 14;
        glow(sx, sy, 15, accent(0f) & 0xFFFFFF, 8);
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(sx, sy);
        m.rotate(time * 0.8f);
        int sc = A(0xFFFFFFFF);
        c.fill(-6, -1, 7, 1, sc);
        c.fill(-1, -6, 1, 7, sc);
        m.rotate(0.785f);
        int sc2 = A(0x90C4B5FD);
        c.fill(-4, 0, 5, 1, sc2);
        c.fill(0, -4, 1, 5, sc2);
        m.popMatrix();

        // аталуы
        var mm = c.getMatrices();
        mm.pushMatrix();
        mm.translate(x0 + 32, y0 + 6);
        mm.scale(1.25f, 1.25f);
        gtext("AlihClient", 0, 0, 0f);
        mm.popMatrix();
        text("NEBULA", x0 + 32 + (int) (tr.getWidth("AlihClient") * 1.25f) + 6, y0 + 9, 0xFF7C72B0);

        // белсенді функциялар санауышы
        int on = 0;
        for (Module mod : AlihClient.MODULES) if (mod.enabled) on++;
        String cnt = on + " / " + AlihClient.MODULES.size() + " қосулы";
        int cw = tr.getWidth(cnt) + 14;
        int cx = x0 + W - 34 - cw;
        rr(cx, y0 + 6, cx + cw, y0 + 21, 5, 0x38A855F7);
        textC(cnt, cx + cw / 2, y0 + 10, 0xFFD9CCFF);

        // жабу батырмасы
        int bx = x0 + W - 24, by = y0 + 6;
        boolean hv = in(mx, my, bx, by, bx + 16, by + 15) && openT >= 0.95f;
        closeHover = ease(closeHover, hv ? 1 : 0, dt, 14);
        if (closeHover > 0.02f) glow(bx + 8, by + 7, 13, 0xFF4D6D, (int) (10 * closeHover));
        rr(bx, by, bx + 16, by + 15, 5, lerpC(0x28FFFFFF, 0xA0FF4D6D, closeHover));
        textC("x", bx + 8, by + 4, lerpC(DIM, 0xFFFFFFFF, closeHover));
        if (hv && clickL && !closing) { closing = true; closeT = 0f; }

        hline(x0 + 6, x0 + W - 6, y0 + 26, 0f, 150);
    }

    private float closeHover;

    // ================================================================ табтар

    private void drawTabs(int x0, int y0, int mx, int my, boolean clickL) {
        int ty = y0 + 30, tw = (W - 12) / TABS.length, th = 18;
        float target = x0 + 6 + tab * tw;
        if (tabX < 0) tabX = target;
        tabX = ease(tabX, target, dt, 14);

        for (int i = 0; i < TABS.length; i++) {
            int tx = x0 + 6 + i * tw;
            boolean hv = in(mx, my, tx, ty, tx + tw, ty + th) && openT >= 0.95f;
            boolean on = i == tab;
            int cntOn = 0;
            for (Module mod : modulesOf(i)) if (mod.enabled) cntOn++;
            int col = on ? 0xFFFFFFFF : (hv ? 0xFFD3CBF5 : DIM);
            textC(TABS[i], tx + tw / 2 - (cntOn > 0 ? 3 : 0), ty + 5, col);
            if (cntOn > 0) {
                int dx = tx + tw / 2 + tr.getWidth(TABS[i]) / 2 + 2;
                glow(dx + 1, ty + 7, 6, CYAN, 8);
                fill(dx, ty + 6, dx + 3, ty + 9, 0xFF000000 | CYAN);
            }
            if (hv && clickL && !on) {
                tab = i;
                listPage = 0;
                List<Module> l = modulesOf(i);
                if (!l.isEmpty()) { selected = l.get(0); setPage = 0; }
                listT = 0f;
                setT = 0f;
            }
        }
        // жылжымалы асты сызық (жарқылымен)
        int ux = (int) tabX + 8, uw = tw - 16;
        for (int g = 4; g >= 1; g--) fill(ux - g, ty + th - 1, ux + uw + g, ty + th + g, ((12 - g * 2) << 24) | (accent(0.5f) & 0xFFFFFF));
        for (int x = ux; x < ux + uw; x += 3) fill(x, ty + th - 1, Math.min(ux + uw, x + 3), ty + th + 1, 0xFF000000 | (accent(x * 0.03f) & 0xFFFFFF));
    }

    // ================================================================ сол жақ: функциялар тізімі

    private void drawList(int x0, int y0, int H, int mx, int my, boolean clickL, boolean clickR) {
        List<Module> list = modulesOf(tab);
        int lx = x0 + 8, ly = y0 + 54, lw = 176;
        int rowsFit = Math.max(1, (H - 54 - 28) / ROW);
        int pages = Math.max(1, (list.size() + rowsFit - 1) / rowsFit);
        if (listPage >= pages) listPage = pages - 1;
        float base = curAlpha;

        for (int i = 0; i < rowsFit; i++) {
            int mi = listPage * rowsFit + i;
            if (mi >= list.size()) break;
            Module mod = list.get(mi);
            float[] a = st(mod);

            // кіру анимациясы (кезекпен сырғиды)
            float ap = outCubic(listT * 3.2f - i * 0.1f);
            int xo = (int) ((1 - ap) * -18);
            curAlpha = base * ap;
            int rx = lx + xo, ry = ly + i * ROW;

            boolean hover = in(mx, my, rx, ry, rx + lw, ry + ROW - 3) && openT >= 0.95f;
            boolean sel = mod == selected;
            a[0] = ease(a[0], hover ? 1 : 0, dt, 14);
            a[1] = ease(a[1], mod.enabled ? 1 : 0, dt, 11);
            a[2] = ease(a[2], 0, dt, 3.5f);
            a[3] = ease(a[3], sel ? 1 : 0, dt, 12);

            int acc = accent(i * 0.4f);
            // фон
            if (a[1] > 0.02f) glow(rx + lw / 2, ry + 8, 46, acc & 0xFFFFFF, (int) (2 * a[1] + 1));
            rr(rx, ry, rx + lw, ry + ROW - 3, 4, lerpC(0xFF150F2B, 0xFF241A48, Math.max(a[0] * 0.8f, a[3])));
            if (a[2] > 0.02f) rr(rx, ry, rx + lw, ry + ROW - 3, 4, ((int) (70 * a[2]) << 24) | (acc & 0xFFFFFF));
            // сол жақ индикатор
            int barH = (int) ((ROW - 3) * Math.max(a[1], a[3] * 0.5f));
            if (barH > 0) {
                int by = ry + (ROW - 3 - barH) / 2;
                fill(rx, by, rx + 2, by + barH, 0xFF000000 | (acc & 0xFFFFFF));
                fill(rx + 2, by, rx + 3, by + barH, 0x40000000 | (acc & 0xFFFFFF));
            }
            // аты
            int nameCol = lerpC(lerpC(DIM, TEXT, Math.max(a[0], a[3])), 0xFF000000 | (acc & 0xFFFFFF), a[1] * 0.85f);
            text(tr.trimToWidth(mod.name, lw - 78), rx + 9 + (int) (a[0] * 2), ry + 5, nameCol);

            // бинд тегі
            int swx = rx + lw - 33, swy = ry + 3;
            if (mod.key != Util.UNSET) {
                String kn = tr.trimToWidth(Util.keyName(mod.key), 34);
                int kw = tr.getWidth(kn) + 6;
                rr(swx - kw - 4, ry + 3, swx - 4, ry + 14, 3, 0x40A855F7);
                text(kn, swx - kw - 1, ry + 5, 0xFFC9B8FF);
            }
            // қосқыш
            boolean hp = in(mx, my, swx - 3, ry, rx + lw, ry + ROW - 3) && openT >= 0.95f;
            toggleSwitch(swx, swy, a[1], hp);

            if (hover && (clickL || clickR)) {
                if (clickR || hp) {
                    mod.toggle();
                    a[2] = 1f;
                    ripple(swx + 13, swy + 6, acc & 0xFFFFFF);
                } else {
                    selected = mod;
                    setPage = 0;
                    setT = 0f;
                    ripple(mx, my, acc & 0xFFFFFF);
                }
            }
        }
        curAlpha = base;

        if (pages > 1) {
            int ny = ly + rowsFit * ROW + 1;
            pager(lx, ny, lw, listPage, pages, mx, my, clickL, true);
        }
    }

    private void pager(int x, int y, int w, int page, int pages, int mx, int my, boolean clickL, boolean list) {
        boolean hl = in(mx, my, x, y, x + 34, y + 14), hr = in(mx, my, x + w - 34, y, x + w, y + 14);
        rr(x, y, x + 34, y + 14, 4, hl ? 0xFF2D2254 : 0xFF1A1236);
        rr(x + w - 34, y, x + w, y + 14, 4, hr ? 0xFF2D2254 : 0xFF1A1236);
        textC("<", x + 17, y + 3, hl ? TEXT : DIM);
        textC(">", x + w - 17, y + 3, hr ? TEXT : DIM);
        textC((page + 1) + " / " + pages, x + w / 2, y + 3, DIM);
        if (clickL && hl && page > 0) { if (list) { listPage--; listT = 0f; } else { setPage--; setT = 0f; } }
        if (clickL && hr && page < pages - 1) { if (list) { listPage++; listT = 0f; } else { setPage++; setT = 0f; } }
    }

    // ================================================================ оң жақ: баптаулар

    private void drawSettings(int x0, int y0, int H, int mx, int my, boolean clickL, boolean clickR, boolean leftHeld) {
        int rx = x0 + 192, rw = W - 200, ry0 = y0 + 54, innerH = H - 54 - 28;
        Module mod = selected;
        float[] a = st(mod);
        float base = curAlpha;

        // панель фоны
        rr(rx, ry0, rx + rw, ry0 + innerH, 5, 0x9010091F);
        for (int y = ry0 + 4; y < ry0 + innerH - 4; y += 3) {
            fill(rx, y, rx + 1, y + 3, 0xB0000000 | (accent(y * 0.02f + a[1] * 3) & 0xFFFFFF));
        }

        // тақырып
        float ap0 = outCubic(setT * 4f);
        curAlpha = base * ap0;
        int hx = rx + 10 + (int) ((1 - ap0) * 10);
        gtext(tr.trimToWidth(mod.name, rw - 80), hx, ry0 + 6, 0.8f);
        text(tr.trimToWidth(mod.desc, rw - 20), hx, ry0 + 19, DIM);
        // күй белгісі
        String stt = mod.enabled ? "ON" : "OFF";
        int sw = tr.getWidth(stt) + 12;
        int sx = rx + rw - sw - 8;
        if (mod.enabled) glow(sx + sw / 2, ry0 + 11, 16, 0x4ADE80, 6);
        rr(sx, ry0 + 5, sx + sw, ry0 + 18, 5, mod.enabled ? 0xFF1F6B45 : 0xFF2A2440);
        textC(stt, sx + sw / 2, ry0 + 8, mod.enabled ? 0xFFB6FFD4 : DIM);
        curAlpha = base;

        int bottomY = ry0 + innerH - 20;
        int sy0 = ry0 + 33;
        int perPage = Math.max(1, (bottomY - 3 - sy0) / SROW);
        int sPages = Math.max(1, (mod.settings.size() + perPage - 1) / perPage);
        if (setPage >= sPages) setPage = sPages - 1;

        for (int i = 0; i < perPage; i++) {
            int idx = setPage * perPage + i;
            if (idx >= mod.settings.size()) break;
            Setting s = mod.settings.get(idx);
            float[] sa = ss(s);

            float ap = outCubic(setT * 3.4f - i * 0.1f);
            curAlpha = base * ap;
            int xo = (int) ((1 - ap) * 14);
            int sx1 = rx + 7 + xo, sx2 = rx + rw - 7 + xo, sy = sy0 + i * SROW;

            boolean hover = in(mx, my, sx1, sy, sx2, sy + SROW - 3) && openT >= 0.95f;
            sa[0] = ease(sa[0], hover ? 1 : 0, dt, 14);
            rr(sx1, sy, sx2, sy + SROW - 3, 4, lerpC(0xFF171030, 0xFF241A48, sa[0]));
            text(tr.trimToWidth(s.name, (sx2 - sx1) / 2 - 8), sx1 + 7, sy + 5, lerpC(DIM, TEXT, sa[0]));

            if (s.type == Setting.Type.BOOL) {
                sa[1] = ease(sa[1], s.b ? 1 : 0, dt, 12);
                int px = sx2 - 34, py = sy + 3;
                toggleSwitch(px, py, sa[1], hover);
                if (clickL && hover) { s.flip(); Config.save(); ripple(px + 13, py + 6, accent(i) & 0xFFFFFF); }
            } else if (s.type == Setting.Type.NUM) {
                String v = s.display();
                int vw = tr.getWidth(v);
                int tx1 = sx1 + (sx2 - sx1) / 2 - 4, tx2 = sx2 - vw - 14;
                float frac = s.max > s.min ? (float) ((s.v - s.min) / (s.max - s.min)) : 0f;
                sa[1] = ease(sa[1], frac, dt, 16);
                int ty = sy + (SROW - 3) / 2 - 2;
                rr(tx1, ty, tx2, ty + 4, 2, 0xFF2A2145);
                int fx = tx1 + (int) ((tx2 - tx1) * sa[1]);
                if (fx - tx1 > 2) {
                    for (int x = tx1; x < fx; x += 2) fill(x, ty, Math.min(fx, x + 2), ty + 4, 0xFF000000 | (accent(x * 0.025f) & 0xFFFFFF));
                }
                glow(fx, ty + 2, 9, accent(fx * 0.025f) & 0xFFFFFF, hover || dragging == s ? 9 : 5);
                rr(fx - 3, ty - 2, fx + 3, ty + 6, 3, 0xFFFFFFFF);
                text(v, sx2 - vw - 7, sy + 5, TEXT);

                boolean onTrack = in(mx, my, tx1 - 4, sy, tx2 + 4, sy + SROW - 3) && openT >= 0.95f;
                if (clickL && onTrack) { dragging = s; dragX1 = tx1; dragX2 = tx2; }
            } else {
                // режим: ‹ мән ›
                String v = s.display();
                int vw = tr.getWidth(v) + 20;
                int px2 = sx2 - 6, px1 = px2 - vw;
                rr(px1, sy + 2, px2, sy + SROW - 5, 4, lerpC(0xFF2B1F55, 0xFF3C2C78, sa[0]));
                textC(v, (px1 + px2) / 2, sy + 5, 0xFFE2D8FF);
                text("<", px1 + 4, sy + 5, DIM);
                text(">", px2 - 4 - tr.getWidth(">"), sy + 5, DIM);
                if (hover && (clickL || clickR)) {
                    if (clickR) s.m = Math.floorMod(s.m - 1, s.modes.length); else s.cycle();
                    Config.save();
                    ripple((px1 + px2) / 2f, sy + 9, PURPLE);
                }
            }
        }
        curAlpha = base;

        // слайдерді сүйреу
        if (dragging != null && leftHeld && dragX2 > dragX1) {
            double f = Math.max(0, Math.min(1, (mx - dragX1) / (double) (dragX2 - dragX1)));
            double raw = dragging.min + f * (dragging.max - dragging.min);
            double stp = dragging.step > 0 ? dragging.step : 1;
            double v = dragging.min + Math.round((raw - dragging.min) / stp) * stp;
            dragging.v = Math.round(Math.max(dragging.min, Math.min(dragging.max, v)) * 100.0) / 100.0;
        }

        // бинд қатары
        int bindW = sPages > 1 ? rw - 14 - 74 : rw - 14;
        int bx = rx + 7;
        boolean hb = in(mx, my, bx, bottomY, bx + bindW, bottomY + SROW - 3) && openT >= 0.95f;
        boolean waiting = binding == mod;
        float pulse = waiting ? (float) (Math.sin(time * 7) * 0.5 + 0.5) : 0;
        rr(bx, bottomY, bx + bindW, bottomY + SROW - 3, 4, lerpC(hb ? 0xFF2D2254 : 0xFF171030, 0xFF4B2E8F, pulse));
        text("Бинд", bx + 7, bottomY + 5, hb ? TEXT : DIM);
        String bn = waiting ? "кнопка бас..." : Util.keyName(mod.key);
        text(bn, bx + bindW - 7 - tr.getWidth(bn), bottomY + 5, waiting ? 0xFFFFFFFF : 0xFFC9B8FF);
        if (hb && clickL) binding = mod;
        if (hb && clickR) { mod.key = Util.UNSET; Config.save(); }

        if (sPages > 1) pager(rx + rw - 7 - 68, bottomY, 68, setPage, sPages, mx, my, clickL, false);
    }
}
