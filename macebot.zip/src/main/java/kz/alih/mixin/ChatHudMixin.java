package kz.alih.mixin;

import kz.alih.modules.ChatHide;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    // параметрсіз: render қол таңбасы нұсқаға байланысты өзгерсе де жұмыс істейді; табылмаса ойын құламайды (require = 0)
    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$hideChat(CallbackInfo ci) {
        if (ChatHide.shouldHide()) ci.cancel();
    }
}
